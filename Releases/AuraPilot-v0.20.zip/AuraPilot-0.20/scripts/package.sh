#!/bin/bash
# 打包脚本：产出 AuraPilot-v<版本>.zip
#
# 关键约定（踩过的坑）：
#   压缩包内顶层目录带版本号，例如 AuraPilot-0.8/
#   —— 这样解压后桌面上的文件夹名就能一眼区分新旧，
#      也不会再出现「AuraPilot 2」「AuraPilot-0.6」这种副本，
#      让人误以为有两个工程。
#
# 用法：scripts/package.sh            # 版本号从 VERSION 文件首行的 **vX.Y** 取
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION=$(grep -oE 'v[0-9]+\.[0-9]+' VERSION | head -1 | tr -d v)
[ -n "$VERSION" ] || { echo "VERSION 文件里没找到 vX.Y"; exit 1; }

OUT_DIR="${OUT_DIR:-$(cd .. && pwd)}"
STAGE=$(mktemp -d)
TOP="AuraPilot-$VERSION"

mkdir -p "$STAGE/$TOP"

echo "==> 打包 $TOP"

# 用 tar 管道复制（macOS / Linux 都自带 tar，不依赖 rsync 版本）
tar -cf - \
  --exclude='.build' \
  --exclude='.swiftpm' \
  --exclude='*.xcodeproj' \
  --exclude='Package.resolved' \
  --exclude='.DS_Store' \
  --exclude='build' \
  . | tar -xf - -C "$STAGE/$TOP"

# 包里放一份版本提示，解压后第一眼就能看到
cat > "$STAGE/$TOP/解压后先看我.txt" <<TXT
这个包的版本是 v$VERSION
目录名 AuraPilot-$VERSION 里的 $VERSION 就是版本号，不用猜。

确认方式（三条里任意一条对上就是新包）：
  1. 文件夹名：AuraPilot-$VERSION
  2. cat VERSION   顶部写着 v$VERSION
  3. 跑任何 aura-probe 命令，第一行打印 aura-probe v$VERSION

先清旧目录再解压（用 macOS 自带的 ditto，参数少、不会踩 unzip 的坑）：
  rm -rf ~/Desktop/AuraPilot-0.* ~/Desktop/AuraPilot ~/Desktop/"AuraPilot 2"
  ditto -x -k ~/Downloads/AuraPilot-v$VERSION.zip ~/Desktop

  备选：unzip -o ~/Downloads/AuraPilot-v$VERSION.zip -d ~/Desktop
        ↑ 写成一整行即可。终端窗口窄时 "-d ~/Desktop" 可能折到下一行显示，
          那是屏幕自动折行，命令本身没错，照跑就行。
          只有真的在 ~ 和 /Desktop 之间敲了空格才会失败（filename not matched）。

跑起来（App，推荐）：
  cd ~/Desktop/AuraPilot-$VERSION
  FOREGROUND=1 ./scripts/build-app.sh
  # 编译 + 自动结束旧实例 + 前台打印日志；⌃C 结束
  # 状态栏点 ✨ 打开弹层，再点「主界面」开主窗口

只跑命令行探针：
  cd AuraPilot-$VERSION/Core && swift build -c release
  .build/release/aura-probe schedule     # 看自动开关灯当前判定

v$VERSION 重点：
  启动第一行打印 "===== AuraPilot v$VERSION (build …) 启动 ====="，编译前有源码指纹校验。
  改颜色/模式/预设时终端打印「📤 下发 … #RRGGBB」与「✅ 事务完成」——
  灯不变化时先看这两行，再决定是继续调还是贴日志。
  灯效模式里只有固件声明支持的模式可点；N-KEY（0x19B6）实测通常只有「静态」真正生效，
  呼吸/色彩循环点了不变是固件未实现，不是 App 故障（软件逐帧做动画会回到狂闪）。
  白天自动开关把灯熄灭时，灯效页顶部会出现橙色横幅，点「立即点亮」即可手动控制。
TXT

ZIP="$OUT_DIR/AuraPilot-v$VERSION.zip"
rm -f "$ZIP"
(cd "$STAGE" && zip -rq "$ZIP" "$TOP")
rm -rf "$STAGE"

echo "==> $ZIP"
ls -lh "$ZIP" | awk '{print "    大小", $5}'
if command -v shasum >/dev/null; then
  echo "    sha256 $(shasum -a 256 "$ZIP" | awk '{print $1}')"
else
  echo "    sha256 $(sha256sum "$ZIP" | awk '{print $1}')"
fi
