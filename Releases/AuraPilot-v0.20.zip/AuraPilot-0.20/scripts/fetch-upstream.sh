#!/usr/bin/env bash
# 拉取上游 G-Helper 源码，仅作协议对照与端点核对，不参与编译。
# 用法： ./scripts/fetch-upstream.sh [目标目录]
set -euo pipefail

DEST="${1:-vendor/g-helper}"

if [ -d "$DEST/.git" ]; then
  echo "已存在，执行更新：$DEST"
  git -C "$DEST" pull --ff-only
else
  mkdir -p "$(dirname "$DEST")"
  git clone --depth 1 https://github.com/seerge/g-helper.git "$DEST"
fi

# rogauracore / macRogAuraCore：内置键盘 HID 协议的事实来源
MACDEST="${2:-vendor/macRogAuraCore}"
if [ -d "$MACDEST/.git" ]; then
  echo "已存在，执行更新：$MACDEST"
  git -C "$MACDEST" pull --ff-only
else
  git clone --depth 1 https://github.com/black-dragon74/macRogAuraCore.git "$MACDEST"
fi

echo
echo "重点参考文件："
echo "  $DEST/app/AsusACPI.cs              ACPI-WMI 端点与 DeviceSet/DeviceGet"
echo "  $DEST/app/Peripherals/Keyboard/    外设 HID 协议实现"
echo "  $DEST/app/AnimeMatrix/             AniMe Matrix USB 通信"
echo "  $MACDEST/macRogAuraCore/main.c     内置键盘 17 字节 feature report 协议"
echo
echo "注意：本项目只引用协议常量与行为描述，未拷贝其代码；如需复用代码请先确认上游许可证（G-Helper MIT，macRogAuraCore BSD-3）。"
