#!/bin/bash
# 不依赖 XcodeGen / Xcode 工程，直接把 App 编译并组装成 .app
#
# 用法：
#   ./scripts/build-app.sh            # 编译 + 组装 build/AuraPilot.app + 打开
#   NO_OPEN=1 ./scripts/build-app.sh  # 只编译组装，不自动打开
#   FOREGROUND=1 ./scripts/build-app.sh  # 前台运行，日志直接打在终端（排错用）
#
# 为什么需要它：机器上装不上 Homebrew，也就装不上 xcodegen，
# 但 swift 工具链（Xcode 或 Command Line Tools 自带）已经够编译 App。
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION=$(grep -oE 'v[0-9]+\.[0-9]+' VERSION | head -1 | tr -d v)
[ -n "$VERSION" ] || { echo "VERSION 文件里没找到 vX.Y"; exit 1; }
BUILD_NUMBER=$(echo "$VERSION" | awk -F. '{print $2}')

# 源码指纹校验：VERSION 文件会被残留旧目录"伪装"，真正证明版本的是代码里的标记。
# 注：终端窗口窄时 "-d ~/Desktop" 折到下一行只是屏幕折行、命令没错；
# 但残留旧目录仍可能让编译产物顶着新版本号跑旧逻辑，所以编译前查代码标记。
FINGERPRINTS=(
  "Core/Sources/AuraCore/Schedule/AutoLighting.swift:ManualOverridePolicy"
  "Core/Sources/AuraCore/Transport/HIDTransport.swift:primaryDevice"
  "Core/Sources/AuraCore/Protocol/FrameRenderer.swift:spec.modeCodes[frame.mode.protocolKey] != nil"
  "App/AppDelegate.swift:buildVersion"
)
for entry in "${FINGERPRINTS[@]}"; do
  file="${entry%%:*}"
  token="${entry##*:}"
  if ! grep -qF "$token" "$file" 2>/dev/null; then
    echo "❌ 源码指纹校验失败：$file 里找不到 $token"
    echo ""
    echo "   你现在编译的不是 v${VERSION} 的源码（多半是解压没成功，cd 进了残留旧目录）。"
    echo "   重新解压："
    echo "     rm -rf ~/Desktop/AuraPilot-${VERSION}"
    echo "     ditto -x -k ~/Downloads/AuraPilot-v${VERSION}.zip ~/Desktop"
    echo "   或： unzip -o ~/Downloads/AuraPilot-v${VERSION}.zip -d ~/Desktop"
    exit 1
  fi
done
echo "==> 源码指纹校验通过（v${VERSION}）"

echo "==> 编译 AuraPilot v${VERSION} (release)"
swift build -c release --product AuraPilot --disable-sandbox

APP="build/AuraPilot.app"
BIN="$(swift build -c release --product AuraPilot --disable-sandbox --show-bin-path)/AuraPilot"

echo "==> 组装 $APP"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN" "$APP/Contents/MacOS/AuraPilot"

# Info.plist 里的 $(VARIABLE) 是 Xcode 变量，这里手工替换掉
sed -e "s|\$(EXECUTABLE_NAME)|AuraPilot|g" \
    -e "s|\$(PRODUCT_BUNDLE_IDENTIFIER)|com.aurapilot.mac|g" \
    -e "s|\$(PRODUCT_NAME)|AuraPilot|g" \
    -e "s|\$(MARKETING_VERSION)|$VERSION.0|g" \
    -e "s|\$(CURRENT_PROJECT_VERSION)|$BUILD_NUMBER|g" \
    -e "s|\$(MACOSX_DEPLOYMENT_TARGET)|13.0|g" \
    Bundle/Info.plist > "$APP/Contents/Info.plist"

# 本地临时签名（HID 访问不需要额外权限，ad-hoc 就够跑）
codesign --force --sign - "$APP" >/dev/null 2>&1 || echo "    （ad-hoc 签名跳过，不影响本地运行）"

echo "==> 完成：$(pwd)/$APP"
if [ "${NO_OPEN:-0}" != "1" ]; then
    # 状态栏 App 是常驻进程：旧实例不退出会一直占着 N-KEY 的 HID 接口，
    # 新进程 IOHIDManagerOpen 就会失败、直接退回演示模式。
    echo "==> 结束旧实例（释放 HID 接口）"
    killall AuraPilot 2>/dev/null || true
    sleep 0.5
    if [ "${FOREGROUND:-0}" = "1" ]; then
        echo "==> 前台运行（⌃C 结束，日志直接打在终端）"
        exec "$APP/Contents/MacOS/AuraPilot"
    fi
    echo "==> 启动（菜单栏会出现图标，没有 Dock 图标）"
    open "$APP"
fi
