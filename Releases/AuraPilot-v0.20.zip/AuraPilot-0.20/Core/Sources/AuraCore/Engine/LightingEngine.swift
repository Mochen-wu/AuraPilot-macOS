import Foundation

/// 时间轴 → 每帧颜色。
///
/// 引擎只负责"算"，不负责"发"：好处是没有硬件也能跑、可以做单元测试、
/// 也可以同时喂给 UI 预览和多个传输层。
public final class LightingEngine {
    public var state: LightingState
    public var framesPerSecond: Double

    private var clockOrigin: TimeInterval

    public init(state: LightingState = LightingState(), framesPerSecond: Double = 30) {
        self.state = state
        self.framesPerSecond = framesPerSecond
        self.clockOrigin = Date().timeIntervalSinceReferenceDate
    }

    public var frameInterval: TimeInterval {
        1.0 / max(1.0, framesPerSecond)
    }

    public func restartClock(at time: TimeInterval = Date().timeIntervalSinceReferenceDate) {
        clockOrigin = time
    }

    public func elapsed(at time: TimeInterval = Date().timeIntervalSinceReferenceDate) -> TimeInterval {
        max(0, time - clockOrigin)
    }

    /// 某个灯区在某时刻的相位偏移，让多个灯区不同步，观感更像整机灯效
    public static func phase(for zone: AuraZone) -> Double {
        switch zone {
        case .keyboard: return 0.0
        case .lightBar: return 0.37
        case .logo: return 0.74
        }
    }

    public func frame(for zone: AuraZone, at time: TimeInterval) -> ZoneFrame {
        let zoneState = state[zone]
        let elapsed = elapsed(at: time)
        let active = state.isOn && zoneState.isEnabled && zoneState.mode != .off

        guard active else {
            return ZoneFrame(
                zone: zone,
                mode: .off,
                primary: .off,
                secondary: .off,
                brightness: 0,
                speed: zoneState.speed,
                elapsed: elapsed
            )
        }

        let color = Effects.color(
            mode: zoneState.mode,
            primary: zoneState.primary,
            secondary: zoneState.secondary,
            speed: zoneState.speed,
            phase: LightingEngine.phase(for: zone),
            time: elapsed
        )

        return ZoneFrame(
            zone: zone,
            mode: zoneState.mode,
            primary: color,
            secondary: zoneState.secondary,
            brightness: zoneState.brightness,
            speed: zoneState.speed,
            elapsed: elapsed
        )
    }

    public func frames(at time: TimeInterval = Date().timeIntervalSinceReferenceDate) -> [ZoneFrame] {
        var result: [ZoneFrame] = []
        result.reserveCapacity(AuraZone.allCases.count)
        for zone in AuraZone.allCases {
            result.append(frame(for: zone, at: time))
        }
        return result
    }

    /// 任何动画中的灯区都需要持续刷新
    public var needsContinuousUpdates: Bool {
        guard state.isOn else { return false }
        for zone in AuraZone.allCases {
            let zoneState = state[zone]
            if zoneState.isEnabled, zoneState.mode.isAnimated {
                return true
            }
        }
        return false
    }
}

/// 下发前的帧规整。
///
/// 为什么要这一步：rogauracore 这类设备**固件自带**呼吸/循环灯效（modeCodes 里有
/// 0x01/0x02），只要把「模式码 + 基色 + 速度」写一次，固件自己会跑动画。
/// 但 `LightingEngine` 默认按 30fps 逐帧算颜色，动画帧每帧字节都变；而 HID 通道
/// 每次提交都要 SET + APPLY，APPLY 之后接口会从 USB 掉线重枚举 —— 连着每帧重打
/// 就是「明明点了静态，灯却狂闪不停」。
///
/// 所以固件自带灯效的设备：把动画帧的主色固定为基色，dedupeKey 逐帧相同，
/// 整个事务只在配置变化时发一次；动画交给设备跑。
public enum FramePolicy {
    public static func normalize(_ frame: ZoneFrame,
                                 baseColor: RGBColor,
                                 hardwareEffects: Bool) -> ZoneFrame {
        guard hardwareEffects, frame.mode.isAnimated else { return frame }
        var result = frame
        result.primary = baseColor
        return result
    }
}

