import Foundation

/// 灯效计算。全部是纯函数，给定 (模式, 颜色, 速度, 相位, 时间) 就能算出颜色，
/// 因此可以脱离硬件单测，也能在 UI 里做实时预览。
///
/// 亮度不在这里乘：`ZoneFrame.brightness` 会单独交给设备/预览层处理，避免双重衰减。
public enum Effects {

    public static func color(
        mode: AuraMode,
        primary: RGBColor,
        secondary: RGBColor,
        speed: Double,
        phase: Double,
        time: Double
    ) -> RGBColor {
        let s = speed.clamped01
        switch mode {
        case .off:
            return .off

        case .solid:
            return primary

        case .breathe:
            let frequency = 0.12 + 0.5 * s
            let wave = 0.5 + 0.5 * sin(2 * .pi * frequency * time + phase * 2 * .pi)
            let eased = wave * wave * (3 - 2 * wave) // smoothstep，呼吸更自然
            return primary.scaled(0.12 + 0.88 * eased)

        case .cycle:
            let rate = 0.03 + 0.22 * s
            let hue = primary.hue + time * rate
            return RGBColor(
                hue: hue,
                saturation: max(primary.saturation, 0.72),
                brightness: max(primary.value, 0.55)
            )

        case .rainbow:
            let rate = 0.06 + 0.28 * s
            let hue = phase + time * rate
            return RGBColor(hue: hue, saturation: 1.0, brightness: 1.0)

        case .star:
            // 每个灯区在自己的时间槽里随机点亮，然后衰减
            let slotLength = 0.55 - 0.35 * s
            let slot = floor(time / max(slotLength, 0.1))
            let local = (time / max(slotLength, 0.1)) - slot
            let seed = UInt64(bitPattern: Int64(slot)) &+ UInt64(phase * 1000)
            let threshold = hash01(seed &* 17 &+ 3)
            guard threshold > 0.45 else {
                return primary.scaled(0.22)
            }
            let decay = pow(max(0, 1 - local), 2.2)
            return secondary.scaled(0.25 + 0.75 * decay)

        case .rain:
            // 一段亮度波在灯区上流过
            let rate = 0.22 + 0.9 * s
            let position = (time * rate + phase).fract
            let head = pow(position, 6)
            let tail = pow(max(0, position - 0.18), 1.6)
            let intensity = max(head, tail * 0.7) * 0.9 + 0.06
            return secondary.mixed(with: primary, amount: 0.35).scaled(intensity)

        case .highlight:
            // 高光扫过：窄亮带 + 底色
            let rate = 0.3 + 0.8 * s
            let position = (time * rate + phase).fract
            let distance = min(abs(position - 0.5), 1 - abs(position - 0.5))
            let band = max(0, 1 - distance / 0.18)
            let smooth = band * band * (3 - 2 * band)
            return primary.mixed(with: secondary, amount: smooth).scaled(0.35 + 0.65 * smooth)

        case .laser:
            let rate = 0.5 + 1.6 * s
            let position = (time * rate + phase).fract
            let distance = min(position, 1 - position)
            let beam = pow(max(0, 1 - distance / 0.07), 2)
            return secondary.scaled(0.1 + 0.9 * beam).mixed(with: primary, amount: 0.25)

        case .ripple:
            let rate = 0.25 + 0.55 * s
            let position = (time * rate + phase).fract
            let first = pow(max(0, 1 - abs(position - 0.3) / 0.22), 2)
            let second = pow(max(0, 1 - abs(position - 0.75) / 0.22), 2)
            let intensity = min(1, first + second * 0.8)
            return primary.mixed(with: secondary, amount: intensity).scaled(0.15 + 0.85 * intensity)
        }
    }

    /// 确定性伪随机（同一 seed 永远同一结果），保证灯效可复现、可测试。
    static func hash01(_ seed: UInt64) -> Double {
        var x = seed &* 6364136223846793005 &+ 1442695040888963407
        x ^= x >> 33
        x = x &* 0xff51afd7ed558ccd
        x ^= x >> 29
        return Double(x % 100_000) / 100_000.0
    }
}
