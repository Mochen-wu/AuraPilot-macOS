import Foundation

public struct LogEntry: Identifiable, Hashable, Sendable {
    public enum Level: String, Sendable {
        case info, warning, error
    }

    public let id = UUID()
    public var date: Date
    public var level: Level
    public var message: String

    public init(level: Level = .info, message: String, date: Date = Date()) {
        self.level = level
        self.message = message
        self.date = date
    }
}

/// 有上限的环形日志，避免长时间运行吃内存
public final class LogBuffer {
    private var storage: [LogEntry] = []
    private let capacity: Int

    public init(capacity: Int = 300) {
        self.capacity = capacity
    }

    public func append(_ entry: LogEntry) {
        storage.append(entry)
        if storage.count > capacity {
            storage.removeFirst(storage.count - capacity)
        }
    }

    public func append(_ message: String, level: LogEntry.Level = .info) {
        append(LogEntry(level: level, message: message))
    }

    public var entries: [LogEntry] { storage }

    public func clear() { storage.removeAll() }
}
