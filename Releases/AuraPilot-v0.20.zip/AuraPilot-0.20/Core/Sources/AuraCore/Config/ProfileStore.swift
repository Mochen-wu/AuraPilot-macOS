import Foundation

/// 界面外观策略：跟随系统 / 强制浅色 / 强制深色
public enum AppAppearance: String, Codable, CaseIterable, Hashable, Sendable {
    case system
    case light
    case dark

    public var displayName: String {
        switch self {
        case .system: return "跟随系统"
        case .light: return "浅色"
        case .dark: return "深色"
        }
    }
}

/// 界面主题（浅色日常色的配色族；深色模式使用同主题的深色变体）
public enum AppThemeID: String, Codable, CaseIterable, Hashable, Sendable {
    case pink       // 樱花粉（默认）
    case lightPink  // 浅粉·奶油
    case white      // 极简白
    case blue       // 天青蓝
    case rainbow    // 五彩缤纷

    public var displayName: String {
        switch self {
        case .pink: return "樱花粉"
        case .lightPink: return "浅粉"
        case .white: return "极简白"
        case .blue: return "天青蓝"
        case .rainbow: return "五彩缤纷"
        }
    }
}

public struct AppSettings: Codable, Hashable, Sendable {
    /// 状态栏显示 CPU 温度
    public var showTemperatureInMenuBar: Bool
    /// 引擎帧率，30 足够，60 更顺但更耗电
    public var engineFPS: Double
    /// 状态栏/快捷面板里的一键配色
    public var quickColors: [RGBColor]
    public var launchAtLogin: Bool
    public var bridge: BridgeConfig
    /// 强制使用演示设备（没有 ASUS 硬件时开发用）
    public var forceSimulatedDevice: Bool
    /// 电池供电时暂停动画，省电
    public var pauseAnimationOnBattery: Bool
    /// 系统睡眠时关闭灯光（HID 键盘上由本 App 充当"固件"角色）
    public var turnOffOnSleep: Bool
    /// 系统唤醒后恢复灯光
    public var restoreOnWake: Bool
    /// 界面外观：跟随系统 / 浅色 / 深色
    public var appearance: AppAppearance
    /// 界面主题配色
    public var themeID: AppThemeID
    /// 按时间 / 深色模式自动开关灯光
    public var autoLighting: AutoLightingConfig
    /// 用户手动指定的 HID 接口（`HIDDeviceDescriptor.id`，形如 `0B05-19B6-338690048`）。
    /// nil = 自动挑选（按用途页 / 报告长度打分）。插着多只 ROG 键盘时用它锁定目标。
    public var preferredDeviceID: String?

    public init(
        showTemperatureInMenuBar: Bool = true,
        engineFPS: Double = 30,
        quickColors: [RGBColor] = [.sakura, .rose, .magenta, .peach, .lilac, .ice, .mint, .gold],
        launchAtLogin: Bool = false,
        bridge: BridgeConfig = .disabled,
        forceSimulatedDevice: Bool = false,
        pauseAnimationOnBattery: Bool = false,
        turnOffOnSleep: Bool = true,
        restoreOnWake: Bool = true,
        appearance: AppAppearance = .system,
        themeID: AppThemeID = .pink,
        autoLighting: AutoLightingConfig = AutoLightingConfig(),
        preferredDeviceID: String? = nil
    ) {
        self.showTemperatureInMenuBar = showTemperatureInMenuBar
        self.engineFPS = engineFPS
        self.quickColors = quickColors
        self.launchAtLogin = launchAtLogin
        self.bridge = bridge
        self.forceSimulatedDevice = forceSimulatedDevice
        self.pauseAnimationOnBattery = pauseAnimationOnBattery
        self.turnOffOnSleep = turnOffOnSleep
        self.restoreOnWake = restoreOnWake
        self.appearance = appearance
        self.themeID = themeID
        self.autoLighting = autoLighting
        self.preferredDeviceID = preferredDeviceID
    }

    private enum CodingKeys: String, CodingKey {
        case showTemperatureInMenuBar, engineFPS, quickColors, launchAtLogin
        case bridge, forceSimulatedDevice, pauseAnimationOnBattery
        case turnOffOnSleep, restoreOnWake, appearance, themeID, autoLighting
        case preferredDeviceID
    }

    // 新增字段时给默认值，保证旧配置能平滑升级
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        showTemperatureInMenuBar = try container.decodeIfPresent(Bool.self, forKey: .showTemperatureInMenuBar) ?? true
        engineFPS = try container.decodeIfPresent(Double.self, forKey: .engineFPS) ?? 30
        quickColors = try container.decodeIfPresent([RGBColor].self, forKey: .quickColors) ?? [.sakura, .rose, .magenta, .peach, .lilac, .ice, .mint, .gold]
        launchAtLogin = try container.decodeIfPresent(Bool.self, forKey: .launchAtLogin) ?? false
        bridge = try container.decodeIfPresent(BridgeConfig.self, forKey: .bridge) ?? .disabled
        forceSimulatedDevice = try container.decodeIfPresent(Bool.self, forKey: .forceSimulatedDevice) ?? false
        pauseAnimationOnBattery = try container.decodeIfPresent(Bool.self, forKey: .pauseAnimationOnBattery) ?? false
        turnOffOnSleep = try container.decodeIfPresent(Bool.self, forKey: .turnOffOnSleep) ?? true
        restoreOnWake = try container.decodeIfPresent(Bool.self, forKey: .restoreOnWake) ?? true
        appearance = try container.decodeIfPresent(AppAppearance.self, forKey: .appearance) ?? .system
        themeID = try container.decodeIfPresent(AppThemeID.self, forKey: .themeID) ?? .pink
        autoLighting = try container.decodeIfPresent(AutoLightingConfig.self, forKey: .autoLighting) ?? AutoLightingConfig()
        preferredDeviceID = try container.decodeIfPresent(String.self, forKey: .preferredDeviceID)
    }
}

public struct StoredConfig: Codable, Sendable {
    public var version: Int
    public var state: LightingState
    public var presets: [Preset]
    public var settings: AppSettings

    public init(version: Int = 1, state: LightingState = LightingState(), presets: [Preset] = StoredConfig.builtInPresets, settings: AppSettings = AppSettings()) {
        self.version = version
        self.state = state
        self.presets = presets
        self.settings = settings
    }

    private enum CodingKeys: String, CodingKey {
        case version, state, presets, settings
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        version = try container.decodeIfPresent(Int.self, forKey: .version) ?? 1
        state = try container.decodeIfPresent(LightingState.self, forKey: .state) ?? LightingState()
        presets = try container.decodeIfPresent([Preset].self, forKey: .presets) ?? StoredConfig.builtInPresets
        settings = try container.decodeIfPresent(AppSettings.self, forKey: .settings) ?? AppSettings()
    }

    public static var builtInPresets: [Preset] {
        [
            Preset(
                name: "玫瑰晨曦",
                state: LightingState(
                    zones: [
                        .keyboard: ZoneState(mode: .solid, primary: RGBColor(hex: "#FF7FA8")!, secondary: .lilac, brightness: 0.65),
                        .lightBar: ZoneState(mode: .breathe, primary: RGBColor(hex: "#FF4D7D")!, secondary: .magenta, brightness: 0.8, speed: 0.4),
                        .logo: ZoneState(mode: .solid, primary: RGBColor(hex: "#E23D9B")!, secondary: .rose, brightness: 0.75)
                    ]
                ),
                isBuiltIn: true
            ),
            Preset(
                name: "极光漫游",
                state: LightingState(
                    zones: [
                        .keyboard: ZoneState(mode: .rainbow, primary: .lilac, secondary: .ice, brightness: 0.6, speed: 0.35),
                        .lightBar: ZoneState(mode: .cycle, primary: .ice, secondary: .mint, brightness: 0.85, speed: 0.3),
                        .logo: ZoneState(mode: .breathe, primary: .lilac, secondary: .ice, brightness: 0.7, speed: 0.25)
                    ]
                ),
                isBuiltIn: true
            ),
            Preset(
                name: "深夜写作",
                state: LightingState(
                    zones: [
                        .keyboard: ZoneState(mode: .solid, primary: RGBColor(hex: "#FFB3C7")!, secondary: .rose, brightness: 0.28),
                        .lightBar: ZoneState(mode: .off, primary: .off, secondary: .off, brightness: 0),
                        .logo: ZoneState(mode: .solid, primary: RGBColor(hex: "#8A5A6B")!, secondary: .rose, brightness: 0.2)
                    ]
                ),
                isBuiltIn: true
            ),
            Preset(
                name: "草莓汽水",
                state: LightingState(
                    zones: [
                        .keyboard: ZoneState(mode: .highlight, primary: RGBColor(hex: "#FF5C8A")!, secondary: RGBColor(hex: "#FFD166")!, brightness: 0.7, speed: 0.5),
                        .lightBar: ZoneState(mode: .ripple, primary: RGBColor(hex: "#FF8FB1")!, secondary: RGBColor(hex: "#7BE8C3")!, brightness: 0.8, speed: 0.45),
                        .logo: ZoneState(mode: .solid, primary: RGBColor(hex: "#FF5C8A")!, secondary: .gold, brightness: 0.8)
                    ]
                ),
                isBuiltIn: true
            ),
            Preset(
                name: "星光低语",
                state: LightingState(
                    zones: [
                        .keyboard: ZoneState(mode: .star, primary: RGBColor(hex: "#4A2540")!, secondary: RGBColor(hex: "#FFC2D6")!, brightness: 0.55, speed: 0.3),
                        .lightBar: ZoneState(mode: .rain, primary: RGBColor(hex: "#3A1E33")!, secondary: RGBColor(hex: "#FF9CC2")!, brightness: 0.7, speed: 0.4),
                        .logo: ZoneState(mode: .breathe, primary: RGBColor(hex: "#FF9CC2")!, secondary: .lilac, brightness: 0.5, speed: 0.2)
                    ]
                ),
                isBuiltIn: true
            )
        ]
    }
}

/// JSON 配置读写。路径：~/Library/Application Support/AuraPilot/config.json
public final class ConfigStore {
    public let directory: URL
    public let fileURL: URL

    public init(directory: URL? = nil) {
        let base = directory ?? {
            let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
                ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
            return support.appendingPathComponent("AuraPilot", isDirectory: true)
        }()
        self.directory = base
        self.fileURL = base.appendingPathComponent("config.json")
    }

    public func load() -> StoredConfig {
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        guard let data = try? Data(contentsOf: fileURL) else {
            return StoredConfig()
        }
        do {
            return try JSONDecoder().decode(StoredConfig.self, from: data)
        } catch {
            // 配置损坏时保留现场，不让 App 起不来
            let backup = fileURL.deletingLastPathComponent()
                .appendingPathComponent("config.corrupt-\(Int(Date().timeIntervalSince1970)).json")
            try? FileManager.default.moveItem(at: fileURL, to: backup)
            return StoredConfig()
        }
    }

    public func save(_ config: StoredConfig) {
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(config)
            try data.write(to: fileURL, options: .atomic)
        } catch {
            // 落盘失败不应打断灯效
            NSLog("[AuraPilot] 保存配置失败: \(error.localizedDescription)")
        }
    }
}
