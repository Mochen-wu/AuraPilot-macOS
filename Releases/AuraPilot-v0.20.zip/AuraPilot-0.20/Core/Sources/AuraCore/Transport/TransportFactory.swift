import Foundation

/// 传输层选择策略。把"用什么硬件通道"这件事集中到一处，
/// 上层控制器完全不需要知道 HID / 桥接 / 演示的区别。
public enum TransportFactory {

    public struct Result {
        public var transport: AuraTransport
        public var device: DeviceInfo
        /// 尝试过程中的失败原因，UI 诊断面板直接展示
        public var attempts: [String]
    }

    public static func make(
        settings: AppSettings,
        profiles: [ProtocolProfile] = ProtocolLibrary.loadAll()
    ) -> Result {
        var attempts: [String] = []
        if let pinned = settings.preferredDeviceID {
            attempts.append("已按用户选择锁定接口：\(pinned)")
        }

        // 每个协议包的探测结果打到 stdout，排查"为什么选中/没选中某个包"
        for profile in profiles {
            print("[AuraPilot][Factory] 协议包 \(profile.id) PID=\(profile.productIDs.map { String(format: "0x%04X", $0) }.joined(separator: ",")) channel=\(profile.frames.values.map { "\($0.channel.kind)" }.joined(separator: ","))")
        }

        if settings.forceSimulatedDevice {
            let simulated = SimulatedTransport()
            attempts.append("已按设置强制使用演示设备")
            return Result(transport: simulated, device: (try? simulated.probe()) ?? .none, attempts: attempts)
        }

        // 1. 原生 HID（唯一能在 macOS 上真正下发灯光的通道）
        for profile in profiles where profile.frames.values.contains(where: { spec in
            spec.channel.kind == .hidFeature || spec.channel.kind == .hidOutput
        }) {
            let transport = HIDTransport(profile: profile,
                                         preferredDeviceID: settings.preferredDeviceID)
            do {
                let device = try transport.probe()
                attempts.append("HID 命中：\(device.name)（\(profile.id)）")
                print("[AuraPilot][Factory] ✅ HID 命中：\(device.name)（\(profile.id)）")
                return Result(transport: transport, device: device, attempts: attempts)
            } catch {
                transport.close()
                attempts.append("HID \(profile.id)：\(error.localizedDescription)")
                print("[AuraPilot][Factory] ❌ HID \(profile.id)：\(error.localizedDescription)")
            }
        }

        // 2. 远程桥（由另一台机器代理 ACPI-WMI）
        if settings.bridge.isEnabled {
            let profile = ProtocolLibrary.wmiLaptopZones()
            let transport = RemoteBridgeTransport(profile: profile, config: settings.bridge)
            do {
                let device = try transport.probe()
                attempts.append("桥接命中：\(device.name)")
                return Result(transport: transport, device: device, attempts: attempts)
            } catch {
                transport.close()
                attempts.append("桥接：\(error.localizedDescription)")
            }
        }

        // 3. 演示
        let simulated = SimulatedTransport()
        attempts.append("未发现可用硬件，回退演示模式")
        print("[AuraPilot][Factory] 探测尝试记录：\n    " + attempts.joined(separator: "\n    "))
        return Result(transport: simulated, device: (try? simulated.probe()) ?? .none, attempts: attempts)
    }
}
