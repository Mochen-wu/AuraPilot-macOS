import Foundation

/// 引擎算出来的一帧，交给传输层去编码下发。
/// 传输层不关心时间轴、缓动、渐变；它只负责把"这一刻该是什么样"变成字节。
public struct ZoneFrame: Hashable, Sendable {
    public var zone: AuraZone
    public var mode: AuraMode
    public var primary: RGBColor
    public var secondary: RGBColor
    /// 0...1
    public var brightness: Double
    /// 0...1
    public var speed: Double
    /// 动画时间轴（秒），协议包可用于相位
    public var elapsed: Double

    public init(
        zone: AuraZone,
        mode: AuraMode,
        primary: RGBColor,
        secondary: RGBColor,
        brightness: Double,
        speed: Double,
        elapsed: Double
    ) {
        self.zone = zone
        self.mode = mode
        self.primary = primary
        self.secondary = secondary
        self.brightness = brightness
        self.speed = speed
        self.elapsed = elapsed
    }

    /// 量化后用于去重：静态模式下避免每帧重复写 HID
    public var dedupeKey: String {
        let (r, g, b) = primary.bytes
        let (r2, g2, b2) = secondary.bytes
        let bri = Int((brightness * 255).rounded())
        let spd = Int((speed * 255).rounded())
        return "\(zone.rawValue)|\(mode.rawValue)|\(r),\(g),\(b)|\(r2),\(g2),\(b2)|\(bri)|\(spd)"
    }
}

public enum AuraError: LocalizedError, CustomStringConvertible {
    case deviceNotFound(String)
    case unsupported(String)
    case zoneNotSupported(AuraZone)
    case transportClosed
    case hidFailure(code: Int32, context: String)
    case protocolError(String)
    case bridgeFailure(String)

    public var errorDescription: String? { description }

    public var description: String {
        switch self {
        case .deviceNotFound(let what):
            return "未找到设备：\(what)"
        case .unsupported(let reason):
            return "不支持：\(reason)"
        case .zoneNotSupported(let zone):
            return "设备不支持该灯区：\(zone.displayName)"
        case .transportClosed:
            return "传输通道已关闭"
        case .hidFailure(let code, let context):
            return "HID 操作失败（\(context)），IOReturn=0x\(String(code, radix: 16))"
        case .protocolError(let reason):
            return "协议包错误：\(reason)"
        case .bridgeFailure(let reason):
            return "桥接失败：\(reason)"
        }
    }
}

public protocol AuraTransport: AnyObject {
    var kind: TransportKind { get }
    /// 打开设备并返回描述信息；失败要抛出可读原因
    func probe() throws -> DeviceInfo
    func apply(_ frame: ZoneFrame) throws
    /// 一次事务下发多个灯区。
    ///
    /// 为什么不能简单循环 `apply`：rogauracore 这类固件是"写缓冲区 → SET → APPLY"，
    /// 每帧都 APPLY 会让**后一个灯区覆盖前一个**（键盘帧被 Logo 帧顶掉）。
    /// HID 传输层会覆盖成「亮度 → 各灯区灯效 → SET → APPLY」，只提交一次。
    func applyBatch(_ frames: [ZoneFrame]) throws
    /// 直接把某灯区关掉（设备可能有独立的 off 指令）
    func setOff(zone: AuraZone) throws
    func close()

    var logHandler: ((String) -> Void)? { get set }
}

public extension AuraTransport {
    /// 默认实现：逐帧下发（演示 / 桥接等通道没有"批量提交"概念）
    func applyBatch(_ frames: [ZoneFrame]) throws {
        for frame in frames { try apply(frame) }
    }

    func setOff(zone: AuraZone) throws {
        try apply(
            ZoneFrame(
                zone: zone,
                mode: .off,
                primary: .off,
                secondary: .off,
                brightness: 0,
                speed: 0,
                elapsed: 0
            )
        )
    }
}
