import Foundation

/// 演示传输层：不动硬件，只记录最后一次收到的帧。
/// 用途有三：没有 ASUS 硬件时的开发预览、UI 联调、自动化测试。
public final class SimulatedTransport: AuraTransport {
    public let kind: TransportKind = .simulated
    public var logHandler: ((String) -> Void)?

    public private(set) var lastFrames: [AuraZone: ZoneFrame] = [:]
    public private(set) var writeCount: Int = 0
    private var isClosed = false

    /// 模拟设备发热/转速，让 UI 有东西看
    private let startTime = Date()

    public init() {}

    public func probe() throws -> DeviceInfo {
        DeviceInfo(
            id: "simulated-device",
            name: "AuraPilot 演示设备",
            vendor: "AuraPilot",
            serial: "SIM-0001",
            kind: .simulated,
            capabilities: .simulated,
            note: "未检测到可用硬件，当前为演示模式（不会点亮任何灯）"
        )
    }

    public func apply(_ frame: ZoneFrame) throws {
        guard !isClosed else { throw AuraError.transportClosed }
        lastFrames[frame.zone] = frame
        writeCount += 1
    }

    public func close() {
        isClosed = true
    }
}

/// 演示用传感器：平滑随机游走，和真实数据无关，但看上去自然。
public final class SimulatedSensorHub: SensorHub {
    public let name = "演示数据"
    public var isAvailable: Bool { true }

    private var cpu: Double = 52
    private var gpu: Double = 47
    private var fan: Double = 2400
    private var tick: UInt64 = 0

    public init() {}

    public func read() -> SensorSnapshot {
        tick += 1
        cpu = (cpu + Double.random(in: -1.2...1.4)).clamped(to: 38...88)
        gpu = (gpu + Double.random(in: -1.0...1.2)).clamped(to: 34...82)
        fan = (fan + Double.random(in: -90...100)).clamped(to: 0...5200)
        return SensorSnapshot(
            cpuTemperature: (cpu * 10).rounded() / 10,
            gpuTemperature: (gpu * 10).rounded() / 10,
            fans: [
                FanReading(index: 0, name: "CPU Fan", rpm: Int(fan)),
                FanReading(index: 1, name: "GPU Fan", rpm: Int(fan * 0.92))
            ],
            source: name,
            probedKeys: ["SIM"],
            timestamp: Date()
        )
    }
}
