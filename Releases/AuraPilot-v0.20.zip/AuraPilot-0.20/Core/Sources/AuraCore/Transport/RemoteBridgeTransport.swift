import Foundation

/// 远程桥配置。
///
/// 背景：macOS 无法访问 ASUS ACPI-WMI，所以"同一台 ASUS 笔记本的键盘/灯条/Logo 灯"
/// 只能由另一台能跑 Windows/Linux 的机器代理。桥 agent 只需实现两个 HTTP 接口：
///
///   GET  /v1/aura/info   -> {"id","name","vendor","zones":["keyboard","lightBar"],"note"}
///   POST /v1/aura/frame  <- {"deviceID":1048662,"params":[180,1,255,122,168,128]}
///
/// 协议包里的 `asusDeviceSet` 通道会被渲染成 params 数组后发送。
public struct BridgeConfig: Codable, Hashable, Sendable {
    public var isEnabled: Bool
    public var baseURL: String
    public var token: String?
    public var timeout: Double

    public init(isEnabled: Bool = false, baseURL: String = "http://127.0.0.1:8712", token: String? = nil, timeout: Double = 2.0) {
        self.isEnabled = isEnabled
        self.baseURL = baseURL
        self.token = token
        self.timeout = timeout
    }

    public static let disabled = BridgeConfig(isEnabled: false)
}

public final class RemoteBridgeTransport: AuraTransport {
    public let kind: TransportKind = .remoteBridge
    public var logHandler: ((String) -> Void)?

    private let profile: ProtocolProfile
    private let config: BridgeConfig
    private let session: URLSession
    private var info: DeviceInfo?

    public init(profile: ProtocolProfile, config: BridgeConfig) {
        self.profile = profile
        self.config = config
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = config.timeout
        session = URLSession(configuration: configuration)
    }

    private struct BridgeInfo: Decodable {
        var id: String
        var name: String
        var vendor: String?
        var zones: [String]?
        var note: String?
    }

    private struct FrameRequest: Encodable {
        var deviceID: UInt32
        var params: [UInt8]
        var zone: String
        var mode: String
    }

    private func makeRequest(path: String, method: String) -> URLRequest? {
        guard let url = URL(string: config.baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + path) else {
            return nil
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = config.token, !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        return request
    }

    public func probe() throws -> DeviceInfo {
        guard config.isEnabled else {
            throw AuraError.unsupported("远程桥未启用")
        }
        guard let request = makeRequest(path: "/v1/aura/info", method: "GET") else {
            throw AuraError.bridgeFailure("地址无效：\(config.baseURL)")
        }

        var result: Result<BridgeInfo, Error> = .failure(AuraError.bridgeFailure("无响应"))
        let semaphore = DispatchSemaphore(value: 0)
        session.dataTask(with: request) { data, _, error in
            if let error {
                result = .failure(error)
            } else if let data, let decoded = try? JSONDecoder().decode(BridgeInfo.self, from: data) {
                result = .success(decoded)
            } else {
                result = .failure(AuraError.bridgeFailure("返回内容无法解析"))
            }
            semaphore.signal()
        }.resume()

        guard semaphore.wait(timeout: .now() + config.timeout) == .success else {
            throw AuraError.bridgeFailure("连接超时：\(config.baseURL)")
        }

        switch result {
        case .success(let bridgeInfo):
            let zones = bridgeInfo.zones?.compactMap(AuraZone.init(rawValue:)) ?? profile.zones
            var capabilities = profile.capabilities
            capabilities.zones = Set(zones)
            let device = DeviceInfo(
                id: bridgeInfo.id,
                name: bridgeInfo.name,
                vendor: bridgeInfo.vendor ?? "ASUSTeK COMPUTER INC.",
                serial: nil,
                kind: .remoteBridge,
                capabilities: capabilities,
                note: bridgeInfo.note ?? "由远程 agent 代理 ACPI-WMI"
            )
            info = device
            return device
        case .failure(let error):
            throw AuraError.bridgeFailure(error.localizedDescription)
        }
    }

    public func apply(_ frame: ZoneFrame) throws {
        guard config.isEnabled, info != nil else { throw AuraError.transportClosed }
        guard let spec = profile.frame(for: frame.zone) else {
            throw AuraError.zoneNotSupported(frame.zone)
        }
        guard spec.channel.kind == .asusDeviceSet else {
            throw AuraError.unsupported("远程桥只处理 ACPI-WMI（asusDeviceSet）通道")
        }

        let params = try FrameRenderer.render(frame, spec: spec)
        let payload = FrameRequest(
            deviceID: spec.channel.deviceID,
            params: params,
            zone: frame.zone.rawValue,
            mode: frame.mode.protocolKey
        )

        guard let request = makeRequest(path: "/v1/aura/frame", method: "POST") else {
            throw AuraError.bridgeFailure("地址无效")
        }
        var urlRequest = request
        urlRequest.httpBody = try JSONEncoder().encode(payload)

        session.dataTask(with: urlRequest) { [weak self] _, _, error in
            if let error {
                self?.logHandler?("桥接下发失败：\(error.localizedDescription)")
            }
        }.resume()
    }

    public func close() {
        session.invalidateAndCancel()
        info = nil
    }
}
