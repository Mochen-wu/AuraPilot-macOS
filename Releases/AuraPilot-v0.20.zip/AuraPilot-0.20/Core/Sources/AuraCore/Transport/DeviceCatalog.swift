import Foundation

/// 一个"可以选"的 HID 接口。诊断页的设备下拉框就用它。
///
/// 为什么要让用户手选：一台机器上可能同时有内置键盘（N-KEY 0x19B6）和外接 ROG 键盘
/// （Falchion 0x1B04）。两者都能被枚举到，但外接那只有一个 11 字节的**键盘输入口**，
/// 灯效帧发过去不会报错、灯也不会动。自动打分能猜对，但插拔顺序、休眠重枚举之后
/// 偶尔会挑错，用户手选是最可靠的兜底。
public struct DeviceCandidate: Identifiable, Hashable, Sendable {
    /// 稳定标识，直接存进 `AppSettings.preferredDeviceID`
    public var id: String
    public var name: String
    public var vendorID: Int
    public var productID: Int
    public var usagePage: Int
    public var usage: Int
    public var maxFeatureReportSize: Int
    public var locationID: Int
    /// 命中的协议包（nil 表示没有协议包认领这个接口）
    public var profileID: String?
    public var profileName: String?
    /// 能不能真正控灯：命中协议包，且 feature 报告长度够发灯效帧
    public var canControl: Bool
    public var note: String?

    public var usbIdentifier: String {
        String(format: "0x%04X:0x%04X", vendorID, productID)
    }

    public var title: String {
        name.isEmpty ? usbIdentifier : "\(name) · \(usbIdentifier)"
    }

    public var subtitle: String {
        var parts = [
            String(format: "usage 0x%04X/0x%02X", usagePage, usage),
            "feature \(maxFeatureReportSize)B"
        ]
        if let profileName { parts.append(profileName) }
        return parts.joined(separator: " · ")
    }

    /// 下拉框里的一行文字，能控灯的加个标记
    public var menuTitle: String {
        (canControl ? "✅ " : "⛔️ ") + title
    }
}

/// 枚举当前机器上所有 ASUS HID 接口，并标注每个接口"能不能控灯"。
public enum DeviceCatalog {

    public static func list(profiles: [ProtocolProfile] = ProtocolLibrary.loadAll()) -> [DeviceCandidate] {
        let descriptors = HIDTransport.discover()

        return descriptors.map { descriptor -> DeviceCandidate in
            let profile = matchingProfile(for: descriptor, in: profiles)
            let minimum = profile?.minimumReportLength ?? 0
            let canControl = profile != nil
                && minimum > 0
                && descriptor.maxFeatureReportSize >= minimum
            var note: String?
            if profile == nil {
                note = "没有协议包匹配这个接口"
            } else if !canControl {
                note = "feature 报告只有 \(descriptor.maxFeatureReportSize)B，发不了灯效帧（多半是键盘输入口）"
            }
            return DeviceCandidate(
                id: descriptor.id,
                name: descriptor.product,
                vendorID: descriptor.vendorID,
                productID: descriptor.productID,
                usagePage: descriptor.usagePage,
                usage: descriptor.usage,
                maxFeatureReportSize: descriptor.maxFeatureReportSize,
                locationID: descriptor.locationID,
                profileID: profile?.id,
                profileName: profile?.displayName,
                canControl: canControl,
                note: note
            )
        }
        .sorted { lhs, rhs in
            if lhs.canControl != rhs.canControl { return lhs.canControl }
            return lhs.title < rhs.title
        }
    }

    /// 与 `TransportFactory` 相同的选择顺序：第一个"匹配 VID/PID 且带 HID 帧"的协议包
    static func matchingProfile(for descriptor: HIDDeviceDescriptor,
                               in profiles: [ProtocolProfile]) -> ProtocolProfile? {
        profiles.first { profile in
            guard profile.matches(vendorID: descriptor.vendorID, productID: descriptor.productID) else { return false }
            return profile.frames.values.contains { spec in
                spec.channel.kind == .hidFeature || spec.channel.kind == .hidOutput
            }
        }
    }
}
