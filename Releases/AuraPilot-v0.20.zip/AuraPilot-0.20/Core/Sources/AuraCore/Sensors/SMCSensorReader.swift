import Foundation
import IOKit

/// AppleSMC 读取器（只读）。
///
/// 这是 macOS 上读温度/风扇转速的公开可行路径：Intel Mac 上键位齐全；
/// Apple Silicon 上 AppleSMC 仍在，但很多传统键位（TC0P 等）不存在，
/// 所以这里用"多键探测 + 取最大值"的策略，并在诊断面板列出实际命中的键。
///
/// 风扇**写入**不做：需要 root、且 ASUS EC 在 macOS 下根本不可达，
/// 强行"支持曲线"只会变成假功能。
public final class SMCSensorReader {
    private var connection: io_connect_t = 0
    private var didOpen = false

    private static let kernelIndexSMC: UInt32 = 2
    private static let cmdReadKeyInfo: UInt8 = 9
    private static let cmdReadBytes: UInt8 = 5

    public private(set) var resolvedCPUKey: String?
    public private(set) var resolvedGPUKey: String?
    public private(set) var probeLog: [String] = []

    public init?() {
        let service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("AppleSMC"))
        guard service != 0 else { return nil }
        defer { _ = IOObjectRelease(service) }

        var conn: io_connect_t = 0
        guard IOServiceOpen(service, mach_task_self_, 0, &conn) == KERN_SUCCESS else { return nil }
        connection = conn
        didOpen = true

        // 必须至少能读到风扇数量或一个温度键，否则视为不可用
        if readKey("FNum") == nil && temperature(keys: ["TC0P", "Tp01", "Tp09"]) == nil {
            close()
            return nil
        }
    }

    deinit { close() }

    public func close() {
        if didOpen {
            _ = IOServiceClose(connection)
            didOpen = false
        }
    }

    // MARK: - 底层通信

    private struct SMCKeyData {
        struct Version {
            var major: UInt8 = 0
            var minor: UInt8 = 0
            var build: UInt8 = 0
            var reserved: UInt8 = 0
            var release: UInt16 = 0
        }
        struct PLimit {
            var version: UInt16 = 0
            var length: UInt16 = 0
            var cpuPLimit: UInt32 = 0
            var gpuPLimit: UInt32 = 0
            var memPLimit: UInt32 = 0
        }
        struct KeyInfo {
            var dataSize: UInt32 = 0
            var dataType: UInt32 = 0
            var dataAttributes: UInt8 = 0
        }

        var key: UInt32 = 0
        var vers = Version()
        var pLimitData = PLimit()
        var keyInfo = KeyInfo()
        var result: UInt8 = 0
        var status: UInt8 = 0
        var data8: UInt8 = 0
        var data32: UInt32 = 0
        var bytes: (UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                    UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                    UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                    UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8) =
            (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    }

    private func call(_ input: inout SMCKeyData) -> SMCKeyData? {
        guard didOpen else { return nil }
        var output = SMCKeyData()
        var outputSize = MemoryLayout<SMCKeyData>.stride
        let result = IOConnectCallStructMethod(
            connection,
            Self.kernelIndexSMC,
            &input,
            MemoryLayout<SMCKeyData>.stride,
            &output,
            &outputSize
        )
        guard result == KERN_SUCCESS, output.result == 0 else { return nil }
        return output
    }

    private static func fourCharCode(_ string: String) -> UInt32 {
        var result: UInt32 = 0
        for scalar in string.unicodeScalars.prefix(4) {
            result = (result << 8) | (scalar.value & 0xFF)
        }
        return result
    }

    private static func fourCharString(_ value: UInt32) -> String {
        let bytes: [UInt8] = [
            UInt8((value >> 24) & 0xFF),
            UInt8((value >> 16) & 0xFF),
            UInt8((value >> 8) & 0xFF),
            UInt8(value & 0xFF)
        ]
        return String(bytes: bytes, encoding: .ascii) ?? "????"
    }

    public struct SMCValue {
        public var dataType: String
        public var bytes: [UInt8]
    }

    public func readKey(_ key: String) -> SMCValue? {
        var info = SMCKeyData()
        info.key = Self.fourCharCode(key)
        info.data8 = Self.cmdReadKeyInfo
        guard let keyInfo = call(&info) else { return nil }

        let size = Int(keyInfo.keyInfo.dataSize)
        guard size > 0, size <= 32 else { return nil }

        var readRequest = SMCKeyData()
        readRequest.key = info.key
        readRequest.keyInfo.dataSize = keyInfo.keyInfo.dataSize
        readRequest.data8 = Self.cmdReadBytes
        guard let output = call(&readRequest) else { return nil }

        let bytes = withUnsafeBytes(of: output.bytes) { Array($0.prefix(size)) }
        return SMCValue(dataType: Self.fourCharString(keyInfo.keyInfo.dataType), bytes: bytes)
    }

    // MARK: - 解码

    static func decode(_ value: SMCValue) -> Double? {
        let bytes = value.bytes
        switch value.dataType {
        case "sp78", "sp87":
            guard bytes.count >= 2 else { return nil }
            let raw = Int16(bitPattern: UInt16(bytes[0]) << 8 | UInt16(bytes[1]))
            return Double(raw) / 256.0
        case "fpe2":
            guard bytes.count >= 2 else { return nil }
            return Double(UInt16(bytes[0]) << 8 | UInt16(bytes[1])) / 4.0
        case "flt ":
            guard bytes.count >= 4 else { return nil }
            let raw = UInt32(bytes[0]) << 24 | UInt32(bytes[1]) << 16 | UInt32(bytes[2]) << 8 | UInt32(bytes[3])
            return Double(Float(bitPattern: raw))
        case "ui8 ":
            return bytes.first.map { Double($0) }
        case "ui16":
            guard bytes.count >= 2 else { return nil }
            return Double(UInt16(bytes[0]) << 8 | UInt16(bytes[1]))
        case "ui32":
            guard bytes.count >= 4 else { return nil }
            let raw = UInt32(bytes[0]) << 24 | UInt32(bytes[1]) << 16 | UInt32(bytes[2]) << 8 | UInt32(bytes[3])
            return Double(raw)
        default:
            // 未知类型时按 2 字节定点猜一次，宁可失败也不返回垃圾值
            guard bytes.count == 2 else { return nil }
            let raw = UInt16(bytes[0]) << 8 | UInt16(bytes[1])
            guard raw < 0x8000 else { return nil }
            return Double(raw) / 4.0
        }
    }

    /// 依次尝试候选键，返回第一个合理读数（0...130℃）
    public func temperature(keys: [String]) -> Double? {
        for key in keys {
            guard let value = readKey(key), let decoded = Self.decode(value) else { continue }
            guard decoded >= 0, decoded <= 130 else { continue }
            probeLog.append("\(key)=\(String(format: "%.1f", decoded))℃ (\(value.dataType))")
            return (decoded * 10).rounded() / 10
        }
        return nil
    }

    /// 多核取最高温
    public func hottest(keys: [String]) -> (key: String, value: Double)? {
        var best: (key: String, value: Double)?
        for key in keys {
            guard let value = readKey(key), let decoded = Self.decode(value) else { continue }
            guard decoded > 0, decoded < 130 else { continue }
            if best == nil || decoded > best!.value {
                best = (key, decoded)
            }
        }
        if let best {
            probeLog.append("\(best.key)=\(String(format: "%.1f", best.value))℃")
            return (best.key, (best.value * 10).rounded() / 10)
        }
        return nil
    }

    /// 裁剪探测日志，避免长跑累积
    public func trimProbeLog(keep: Int) {
        if probeLog.count > keep {
            probeLog.removeFirst(probeLog.count - keep)
        }
    }

    public var fanCount: Int {
        guard let value = readKey("FNum"), let decoded = Self.decode(value) else { return 0 }
        return max(0, min(8, Int(decoded)))
    }

    public func fanRPM(index: Int) -> Int? {
        let key = "F\(index)Ac"
        guard let value = readKey(key), let decoded = Self.decode(value) else { return nil }
        guard decoded >= 0, decoded <= 20000 else { return nil }
        return Int(decoded.rounded())
    }
}
