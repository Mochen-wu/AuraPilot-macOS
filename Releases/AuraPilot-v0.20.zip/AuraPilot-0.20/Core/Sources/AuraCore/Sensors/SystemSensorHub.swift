import Foundation

public final class SystemSensorHub: SensorHub {
    public let name = "AppleSMC"
    private let smc: SMCSensorReader?
    private var cachedFanCount: Int?

    private static let cpuKeys = [
        "TC0P", "TC0D", "TC0E", "TC0F", "TC0H", "TC0J",
        "Tp01", "Tp05", "Tp09", "Tp0D", "Tp0H", "Tp0L",
        "Tp0P", "Tp0X", "Tp0b", "Tp0f", "Tp0j", "Tp0n"
    ]

    private static let gpuKeys = [
        "TG0P", "TG0D", "Tg0P", "Tg0D", "TCGC", "Tp0T"
    ]

    public init() {
        smc = SMCSensorReader()
    }

    public var isAvailable: Bool { smc != nil }

    public var diagnostics: [String] {
        guard let smc else { return ["AppleSMC 不可用"] }
        return Array(smc.probeLog.suffix(24))
    }

    public func read() -> SensorSnapshot {
        guard let smc else {
            return SensorSnapshot(source: "AppleSMC 不可用")
        }

        let cpu = smc.hottest(keys: Self.cpuKeys)
        let gpu = smc.hottest(keys: Self.gpuKeys)

        if cachedFanCount == nil {
            cachedFanCount = smc.fanCount
        }
        var fans: [FanReading] = []
        let count = cachedFanCount ?? 0
        for index in 0..<max(0, count) {
            guard let rpm = smc.fanRPM(index: index) else { continue }
            fans.append(FanReading(index: index, name: "Fan \(index + 1)", rpm: rpm))
        }

        // 探测日志只保留最近一批，防止无限增长
        smc.trimProbeLog(keep: 100)

        return SensorSnapshot(
            cpuTemperature: cpu?.value,
            gpuTemperature: gpu?.value,
            fans: fans,
            source: cpu == nil && gpu == nil ? "AppleSMC（未命中温度键）" : "AppleSMC",
            probedKeys: [cpu?.key, gpu?.key].compactMap { $0 },
            timestamp: Date()
        )
    }
}
