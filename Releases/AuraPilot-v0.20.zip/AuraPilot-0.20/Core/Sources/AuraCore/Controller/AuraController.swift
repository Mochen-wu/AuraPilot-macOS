import Foundation

/// 应用内核。负责：持有状态、驱动引擎定时器、下发帧、读传感器、持久化、广播快照。
///
/// 线程模型：
/// - 所有状态修改、硬件 IO、定时器都在私有串行队列 `queue` 上；
/// - 对外只通过 `snapshot`（加锁读取）和 `observe`（回调派发到主线程）暴露，UI 不需要关心线程。
public final class AuraController {
    public struct Snapshot: Sendable {
        public var state: LightingState
        public var device: DeviceInfo
        public var sensors: SensorSnapshot
        public var presets: [Preset]
        public var settings: AppSettings
        public var isRunning: Bool
        public var lastError: String?
        public var log: [LogEntry]
        public var attempts: [String]
        /// 自动开关灯光施加的亮度系数（1 = 不干预，0 = 自动熄灭）
        public var autoLevel: Double = 1
        /// 自动开关当前状态的一句话说明，界面直接展示
        public var autoNote: String?
        /// 用户刚手动调过灯效，自动开关暂时让位（此时按钮点了必定看得见效果）
        public var isManualOverride: Bool = false
        /// 自动开关重新接管的时刻
        public var manualOverrideUntil: Date?

        public var isSimulated: Bool { device.kind == .simulated }
        /// 是否因为"白天 / 浅色模式"被自动压暗
        public var isAutoDimmed: Bool { autoLevel < 0.999 }
    }

    // MARK: - 依赖

    private let queue = DispatchQueue(label: "com.aurapilot.controller", qos: .userInitiated)
    private let engine: LightingEngine
    /// 可替换：用户可以在诊断页手动换设备（插着多只 ROG 键盘时很必要）
    private var transport: AuraTransport
    private let sensors: SensorHub
    private let store: ConfigStore
    private let logBuffer = LogBuffer()

    // MARK: - 状态（仅 queue 上写）

    private var config: StoredConfig
    private var latestSensors = SensorSnapshot.empty
    private var isPaused = false
    /// 睡眠期间挂起输出。与 isPaused 不同：它由系统事件驱动，
    /// 且不改变用户配置，唤醒后按 restoreOnWake 恢复原状态。
    private var isSuspendedForSleep = false
    private var frameTimer: DispatchSourceTimer?
    private var sensorTimer: DispatchSourceTimer?
    private var lastSentKeys: [AuraZone: String] = [:]
    private var saveWorkItem: DispatchWorkItem?
    private var lastErrorMessage: String?

    /// 自动开关灯光（按时间 / 深色模式）施加的亮度系数，乘在用户设定的亮度上。
    /// 与 `isPaused` 的区别：它不改变用户配置，只在渲染时缩放，撤销后立刻恢复原亮度。
    private var autoLevel: Double = 1
    private var autoNote: String?
    /// 手动接管的到期时刻。有效期内自动开关不能把亮度压暗，
    /// 否则用户点颜色/模式/预设会被 autoLevel=0 整个吞掉。
    private var manualOverrideUntil: Date?

    /// 惰性清理过期接管（只在控制器队列上读写）
    private var isManualOverrideActive: Bool {
        guard let until = manualOverrideUntil else { return false }
        if Date() >= until {
            manualOverrideUntil = nil
            return false
        }
        return true
    }

    public private(set) var device: DeviceInfo
    public private(set) var attempts: [String]
    public private(set) var isRunning = false

    // MARK: - 观察者（加锁）

    private let lock = NSLock()
    private var observers: [UUID: (Snapshot) -> Void] = [:]
    private var latest: Snapshot

    // MARK: - 初始化

    public init(
        transport: AuraTransport,
        device: DeviceInfo,
        sensors: SensorHub,
        store: ConfigStore,
        attempts: [String] = []
    ) {
        self.transport = transport
        self.device = device
        self.sensors = sensors
        self.store = store
        self.attempts = attempts

        let loaded = store.load()
        self.config = loaded
        self.engine = LightingEngine(state: loaded.state, framesPerSecond: loaded.settings.engineFPS)
        self.latest = Snapshot(
            state: loaded.state,
            device: device,
            sensors: .empty,
            presets: loaded.presets,
            settings: loaded.settings,
            isRunning: false,
            lastError: nil,
            log: [],
            attempts: attempts
        )

        // 让 log() 能识别"已经在队列上"，避免无谓的异步跳转
        queue.setSpecific(key: queueKey, value: ())

        transport.logHandler = { [weak self] message in
            self?.log(message)
        }
    }

    /// 走完整探测流程创建实例
    public static func makeDefault(store: ConfigStore = ConfigStore()) -> AuraController {
        ProtocolLibrary.writeSampleIfNeeded()
        let settings = store.load().settings
        let result = TransportFactory.make(settings: settings)
        let systemHub = SystemSensorHub()
        let sensorHub: SensorHub = systemHub.isAvailable ? systemHub : UnavailableSensorHub()

        if !result.device.kind.isRealHardware {
            // 演示模式下用模拟传感器，避免"演示设备 + 真实温度"的错位观感
            return AuraController(
                transport: result.transport,
                device: result.device,
                sensors: SimulatedSensorHub(),
                store: store,
                attempts: result.attempts
            )
        }

        return AuraController(
            transport: result.transport,
            device: result.device,
            sensors: sensorHub,
            store: store,
            attempts: result.attempts
        )
    }

    // MARK: - 设备切换

    /// 换一只设备（或改回自动选择）。整个过程都在控制器队列上：
    /// 停定时器 → 关旧通道 → 重新探测 → 换通道 → 按当前配置重推灯光。
    ///
    /// 为什么要先停再探测：旧通道还在 tick 的话，它的一次 APPLY 会让接口掉线重枚举，
    /// 新探测拿到的句柄立刻失效。
    public func switchDevice(preferredDeviceID: String?, completion: ((DeviceInfo) -> Void)? = nil) {
        queue.async { [weak self] in
            guard let self else { return }
            let wasRunning = self.isRunning
            self.frameTimer?.cancel()
            self.frameTimer = nil
            self.sensorTimer?.cancel()
            self.sensorTimer = nil
            self.isRunning = false
            self.transport.close()

            var settings = self.config.settings
            settings.preferredDeviceID = preferredDeviceID
            let result = TransportFactory.make(settings: settings)
            self.transport = result.transport
            result.transport.logHandler = { [weak self] message in
                self?.log(message)
            }
            self.device = result.device
            self.attempts = result.attempts
            self.lastSentKeys.removeAll()
            self.lastErrorMessage = nil
            self.log("已切换设备：\(result.device.name)（\(result.device.kind.displayName)）")

            if wasRunning {
                self.isRunning = true
                self.engine.restartClock()
                self.pushAllFrames()
                self.startTimers()
            }
            self.publish()
            if let completion {
                DispatchQueue.main.async { completion(result.device) }
            }
        }
    }

    // MARK: - 生命周期

    public func start() {
        queue.async { [weak self] in
            guard let self, !self.isRunning else { return }
            self.isRunning = true
            self.engine.restartClock()
            self.lastSentKeys.removeAll()
            self.pushAllFrames()
            self.startTimers()
            self.log("引擎启动：\(self.device.name)（\(self.device.kind.displayName)）")
            self.publish()
        }
    }

    public func stop(turnOffLights: Bool = false) {
        queue.async { [weak self] in
            guard let self else { return }
            self.frameTimer?.cancel()
            self.sensorTimer?.cancel()
            self.frameTimer = nil
            self.sensorTimer = nil
            if turnOffLights {
                for zone in AuraZone.allCases where self.device.capabilities.supports(zone) {
                    try? self.transport.setOff(zone: zone)
                }
            }
            self.isRunning = false
            self.persistNow()
            self.log("引擎停止")
            self.publish()
        }
    }

    private func startTimers() {
        let frameSource = DispatchSource.makeTimerSource(queue: queue)
        let interval = engine.frameInterval
        frameSource.schedule(deadline: .now() + interval, repeating: interval, leeway: .milliseconds(4))
        frameSource.setEventHandler { [weak self] in
            self?.tick()
        }
        frameSource.resume()
        frameTimer = frameSource

        let sensorSource = DispatchSource.makeTimerSource(queue: queue)
        sensorSource.schedule(deadline: .now() + 1.0, repeating: 1.0, leeway: .milliseconds(200))
        sensorSource.setEventHandler { [weak self] in
            self?.pollSensors()
        }
        sensorSource.resume()
        sensorTimer = sensorSource
    }

    private func tick() {
        guard !isPaused, !isSuspendedForSleep else { return }
        let now = Date().timeIntervalSinceReferenceDate

        var batch: [ZoneFrame] = []
        for raw in engine.frames(at: now) {
            guard device.capabilities.supports(raw.zone) else { continue }
            var frame = raw
            // 固件自带灯效时动画交给固件：固定主色 → 每帧 dedupeKey 相同 → 只发一次。
            // 否则逐帧 APPLY 会让 HID 接口反复掉线重枚举，表现为"静态却狂闪"。
            frame = FramePolicy.normalize(
                frame,
                baseColor: config.state[frame.zone].primary,
                hardwareEffects: device.capabilities.hardwareEffects
            )
            // 自动开关只缩放亮度：0 就是"直接把亮度降到 0"，用户配置原样保留
            if autoLevel < 0.999 {
                frame.brightness = frame.brightness * autoLevel
            }
            if lastSentKeys[frame.zone] == frame.dedupeKey {
                continue
            }
            batch.append(frame)
        }
        guard !batch.isEmpty else { return }

        // 多灯区必须**一次事务**下发：固件缓冲区只有一份，逐帧 APPLY 会让
        // 后一个灯区覆盖前一个（键盘被灯条/Logo 顶掉）。
        for frame in batch {
            lastSentKeys[frame.zone] = frame.dedupeKey
        }
        do {
            try transport.applyBatch(batch)
            lastErrorMessage = nil
        } catch {
            handle(error)
            // 失败时不清 key：静态帧下一 tick 会重试一次，不会每帧刷屏
        }
    }

    private func pushAllFrames() {
        lastSentKeys.removeAll()
        tick()
    }

    private func pollSensors() {
        let snapshot = sensors.read()
        latestSensors = snapshot
        publish()
    }

    private func handle(_ error: Error) {
        let message = error.localizedDescription
        if message != lastErrorMessage {
            lastErrorMessage = message
            log(message, level: .error)
        }
    }

    // MARK: - 对外操作

    public func setGlobalOn(_ isOn: Bool) {
        mutate { $0.isOn = isOn }
    }

    public func toggleGlobal() {
        queue.async { [weak self] in
            guard let self else { return }
            self.config.state.isOn.toggle()
            self.commitState()
        }
    }

    public func setZoneEnabled(_ enabled: Bool, zone: AuraZone) {
        mutate { $0[zone].isEnabled = enabled }
    }

    public func setMode(_ mode: AuraMode, zone: AuraZone) {
        mutate { $0[zone].mode = mode }
    }

    public func setPrimary(_ color: RGBColor, zone: AuraZone) {
        mutate { $0[zone].primary = color }
    }

    public func setSecondary(_ color: RGBColor, zone: AuraZone) {
        mutate { $0[zone].secondary = color }
    }

    public func setBrightness(_ value: Double, zone: AuraZone) {
        mutate { $0[zone].brightness = value.clamped01 }
    }

    /// 整机共用亮度（rogauracore 的 0x5A 独立亮度报告只有一条，
    /// 没有按灯区之分）。改一次同步到所有灯区，UI 显示与硬件实际一致。
    public func setGlobalBrightness(_ value: Double) {
        mutate { state in
            let normalized = value.clamped01
            for zone in AuraZone.allCases {
                state[zone].brightness = normalized
            }
        }
    }

    public func setSpeed(_ value: Double, zone: AuraZone) {
        mutate { $0[zone].speed = value.clamped01 }
    }

    /// 状态栏"颜色切换"用：在所有灯区上轮换快捷色
    public func cycleQuickColor(zone: AuraZone? = nil) {
        queue.async { [weak self] in
            guard let self else { return }
            let colors = self.config.settings.quickColors
            guard !colors.isEmpty else { return }
            let target = zone ?? .keyboard
            let current = self.config.state[target].primary
            let index = colors.firstIndex(where: { $0.hexString == current.hexString }) ?? -1
            let next = colors[(index + 1) % colors.count]
            for zone in AuraZone.allCases where self.device.capabilities.supports(zone) {
                self.config.state[zone].primary = next
            }
            self.commitState()
        }
    }

    public func applyPreset(id: UUID) {
        queue.async { [weak self] in
            guard let self, let preset = self.config.presets.first(where: { $0.id == id }) else { return }
            var state = preset.state
            state.activePresetID = preset.id
            self.config.state = state
            self.commitState()
            self.log("应用预设：\(preset.name)")
        }
    }

    public func savePreset(named name: String, completion: ((Preset) -> Void)? = nil) {
        queue.async { [weak self] in
            guard let self else { return }
            var state = self.config.state
            state.activePresetID = nil
            let preset = Preset(name: name.isEmpty ? "未命名" : name, state: state)
            self.config.presets.append(preset)
            self.scheduleSave()
            self.log("保存预设：\(preset.name)")
            self.publish()
            if let completion {
                DispatchQueue.main.async { completion(preset) }
            }
        }
    }

    public func deletePreset(id: UUID) {
        queue.async { [weak self] in
            guard let self else { return }
            guard let index = self.config.presets.firstIndex(where: { $0.id == id && !$0.isBuiltIn }) else { return }
            self.config.presets.remove(at: index)
            self.scheduleSave()
            self.publish()
        }
    }

    public func updateSettings(_ change: @escaping (inout AppSettings) -> Void) {
        queue.async { [weak self] in
            guard let self else { return }
            change(&self.config.settings)
            self.engine.framesPerSecond = self.config.settings.engineFPS
            self.scheduleSave()
            self.publish()
        }
    }

    public func setPaused(_ paused: Bool) {
        queue.async { [weak self] in
            guard let self else { return }
            self.isPaused = paused
            self.log(paused ? "已暂停输出" : "已恢复输出")
        }
    }

    /// 自动开关灯光：由 App 层的调度器在「启动 / 唤醒 / 跨过时间边界 / 系统外观切换」时调用。
    ///
    /// 只缩放渲染时的亮度，不动 `state` 里的用户配置；`level = 0` 等价于
    /// 「直接把亮度降到 0」，把 `level` 调回 1 就立刻恢复原来的灯效。
    public func setAutoLevel(_ level: Double, note: String? = nil) {
        queue.async { [weak self] in
            guard let self else { return }
            // 手动接管期间：自动开关不能再把灯压暗，否则用户刚调的颜色/模式
            // 会被亮度 0 整个吞掉，看起来就是「所有按钮都没反应」。
            // 这里只更新文案、绝不重发帧（重发一次 APPLY 接口就掉线一次，肉眼会闪）。
            if self.isManualOverrideActive, level < 0.999 {
                let overrideNote = "手动控制中，自动开关暂让位"
                if self.autoNote != overrideNote {
                    self.autoNote = overrideNote
                    self.publish()
                }
                return
            }

            let target = level.clamped01
            let levelChanged = abs(target - self.autoLevel) > 0.001
            let noteChanged = note != self.autoNote
            guard levelChanged || noteChanged else { return }
            self.autoLevel = target
            self.autoNote = note
            // 只有亮度真的变了才重发帧。note 变化只是文案更新，
            // 若也走 removeAll + tick，SET/APPLY 会让 N-KEY 接口重枚举 → 闪一下。
            if levelChanged {
                self.lastSentKeys.removeAll()
                if self.isRunning {
                    self.tick()
                }
                if let note {
                    self.log("自动开关：\(note)")
                }
            }
            self.publish()
        }
    }

    /// 用户显式调了灯效：自动开关暂时让位到 `expiry`，并立刻解除自动压暗。
    /// 只有真的从「熄灭」恢复时才重发帧；后续连续点按钮只延长让位时间，不会闪。
    public func setManualOverride(until expiry: Date?, note: String? = nil) {
        queue.async { [weak self] in
            guard let self else { return }
            let wasDimmed = self.autoLevel < 0.999
            self.manualOverrideUntil = expiry
            self.autoLevel = 1
            self.autoNote = note
            if wasDimmed {
                self.lastSentKeys.removeAll()
                if self.isRunning {
                    self.tick()
                }
                if let note {
                    self.log(note)
                }
            }
            self.publish()
        }
    }

    /// 界面上的「恢复自动」：立刻把控制权交回自动开关。
    public func clearManualOverride() {
        queue.async { [weak self] in
            guard let self else { return }
            self.manualOverrideUntil = nil
            self.publish()
        }
    }

    /// 「立即点亮」：一步到位打开总开关、启用灯区、把 off 模式改回静态、
    /// 亮度过低时给一个可见值。一次 commit 只下发一帧，避免连着 APPLY 闪灯。
    public func turnOnNow(minimumBrightness: Double = 0.7) {
        queue.async { [weak self] in
            guard let self else { return }
            self.config.state.isOn = true
            for zone in AuraZone.allCases where self.device.capabilities.supports(zone) {
                self.config.state[zone].isEnabled = true
                if self.config.state[zone].mode == .off {
                    self.config.state[zone].mode = .solid
                }
                if self.config.state[zone].brightness < 0.15 {
                    self.config.state[zone].brightness = minimumBrightness.clamped01
                }
            }
            self.commitState()
            self.log("手动点亮：总开关已打开，灯区已启用")
        }
    }

    public func setAllOff() {
        mutate { state in
            for zone in AuraZone.allCases {
                state[zone].mode = .off
                state[zone].isEnabled = false
            }
        }
    }

    // MARK: - 系统电源事件（等价于 G-Helper TUFKeyboardPower 的"OS 负责"那部分）

    /// 系统即将睡眠：发关闭帧但**不改用户配置**。
    /// 对 HID 键盘（rogauracore 等），睡眠灭灯本来是固件/Windows 做的事，
    /// 在 macOS 上由本 App 充当这个角色；WMI 机型则由 EC 固件负责，无需干预。
    public func handleSystemSleep() {
        queue.async { [weak self] in
            guard let self, self.isRunning, !self.isSuspendedForSleep else { return }
            guard self.config.settings.turnOffOnSleep else {
                self.log("系统睡眠：按设置保持灯光")
                return
            }
            self.isSuspendedForSleep = true
            self.lastSentKeys.removeAll()
            for zone in AuraZone.allCases where self.device.capabilities.supports(zone) {
                try? self.transport.setOff(zone: zone)
            }
            self.log("系统睡眠：已关闭灯光（配置保持不变）")
            self.publish()
        }
    }

    /// 系统唤醒：恢复睡眠前的灯光状态
    public func handleSystemWake() {
        queue.async { [weak self] in
            guard let self, self.isRunning else { return }
            guard self.isSuspendedForSleep else { return }
            guard self.config.settings.restoreOnWake else {
                // 用户选择唤醒不恢复：解除挂起但等下一次显式操作
                self.isSuspendedForSleep = false
                self.lastSentKeys.removeAll()
                self.log("系统唤醒：按设置不自动恢复灯光")
                self.publish()
                return
            }
            self.isSuspendedForSleep = false
            self.engine.restartClock()
            self.lastSentKeys.removeAll()
            self.tick()
            self.log("系统唤醒：恢复灯光")
            self.publish()
        }
    }

    public func refreshSensors() {
        queue.async { [weak self] in
            self?.pollSensors()
        }
    }

    public func appendExternalLog(_ message: String) {
        log(message)
    }

    // MARK: - 内部

    private func mutate(_ change: @escaping (inout LightingState) -> Void) {
        queue.async { [weak self] in
            guard let self else { return }
            change(&self.config.state)
            self.commitState()
        }
    }

    private func commitState() {
        self.config.state.activePresetID = nil
        self.engine.state = self.config.state
        self.lastSentKeys.removeAll()
        self.pushAllFrames()
        self.scheduleSave()
        self.publish()
    }

    private func scheduleSave() {
        saveWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            self?.persistNow()
        }
        saveWorkItem = item
        queue.asyncAfter(deadline: .now() + 0.5, execute: item)
    }

    private func persistNow() {
        store.save(config)
    }

    // MARK: - 日志与快照

    private func log(_ message: String, level: LogEntry.Level = .info) {
        if DispatchQueue.getSpecific(key: queueKey) != nil {
            appendLog(message, level: level)
        } else {
            queue.async { [weak self] in
                self?.appendLog(message, level: level)
            }
        }
    }

    private let queueKey = DispatchSpecificKey<Void>()

    private func appendLog(_ message: String, level: LogEntry.Level) {
        // 同时镜像到 stdout，便于从终端/Xcode console 直接排查硬件链路
        print("[AuraPilot][Core][\(level)] \(message)")
        logBuffer.append(message, level: level)
    }

    private func makeSnapshot() -> Snapshot {
        let overrideActive = isManualOverrideActive
        return Snapshot(
            state: config.state,
            device: device,
            sensors: latestSensors,
            presets: config.presets,
            settings: config.settings,
            isRunning: isRunning,
            lastError: lastErrorMessage,
            log: logBuffer.entries,
            attempts: attempts,
            autoLevel: autoLevel,
            autoNote: autoNote,
            isManualOverride: overrideActive,
            manualOverrideUntil: overrideActive ? manualOverrideUntil : nil
        )
    }

    private func publish() {
        let snapshot = makeSnapshot()
        lock.lock()
        latest = snapshot
        let handlers = Array(observers.values)
        lock.unlock()

        guard !handlers.isEmpty else { return }
        DispatchQueue.main.async {
            for handler in handlers {
                handler(snapshot)
            }
        }
    }

    public var snapshot: Snapshot {
        lock.lock()
        defer { lock.unlock() }
        return latest
    }

    @discardableResult
    public func observe(_ handler: @escaping (Snapshot) -> Void) -> UUID {
        let token = UUID()
        lock.lock()
        observers[token] = handler
        let current = latest
        lock.unlock()
        DispatchQueue.main.async {
            handler(current)
        }
        return token
    }

    public func removeObserver(_ token: UUID) {
        lock.lock()
        observers[token] = nil
        lock.unlock()
    }
}
