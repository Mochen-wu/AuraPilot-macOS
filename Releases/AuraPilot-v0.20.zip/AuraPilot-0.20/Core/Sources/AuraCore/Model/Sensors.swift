import Foundation

public struct FanReading: Codable, Hashable, Sendable, Identifiable {
    public var index: Int
    public var name: String
    /// 转/分
    public var rpm: Int

    public var id: Int { index }

    public init(index: Int, name: String, rpm: Int) {
        self.index = index
        self.name = name
        self.rpm = rpm
    }
}

/// 一次传感器采样。缺测值用 nil，UI 显示"—"，绝不编造数字。
public struct SensorSnapshot: Codable, Hashable, Sendable {
    public var cpuTemperature: Double?
    public var gpuTemperature: Double?
    public var fans: [FanReading]
    /// 数据来源说明，例如 "AppleSMC" / "演示数据"
    public var source: String
    /// 采集过程中缺失的键，用于诊断面板
    public var probedKeys: [String]
    public var timestamp: Date

    public init(
        cpuTemperature: Double? = nil,
        gpuTemperature: Double? = nil,
        fans: [FanReading] = [],
        source: String = "未初始化",
        probedKeys: [String] = [],
        timestamp: Date = Date()
    ) {
        self.cpuTemperature = cpuTemperature
        self.gpuTemperature = gpuTemperature
        self.fans = fans
        self.source = source
        self.probedKeys = probedKeys
        self.timestamp = timestamp
    }

    public static let empty = SensorSnapshot()

    public var fanSummary: String {
        guard let first = fans.first else { return "—" }
        return "\(first.rpm)"
    }

    public var hasAnyReading: Bool {
        cpuTemperature != nil || gpuTemperature != nil || !fans.isEmpty
    }
}

/// 真实设备 + 本机拿不到传感器时的占位实现：全部返回 nil，绝不编造数字。
public final class UnavailableSensorHub: SensorHub {
    public let name = "不可用"
    public var isAvailable: Bool { false }
    public init() {}
    public func read() -> SensorSnapshot {
        SensorSnapshot(source: "macOS 未暴露传感器")
    }
}

/// 传感器数据源
public protocol SensorHub: AnyObject {
    var name: String { get }
    var isAvailable: Bool { get }
    func read() -> SensorSnapshot
}
