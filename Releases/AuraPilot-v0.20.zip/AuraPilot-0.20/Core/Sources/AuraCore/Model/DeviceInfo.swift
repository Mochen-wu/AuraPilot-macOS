import Foundation

/// 传输层种类。决定 UI 上如何解释"当前在跟谁说话"。
public enum TransportKind: String, Codable, Sendable {
    /// USB HID 设备（macOS 上唯一能真正下发灯光数据的原生通道）
    case hid
    /// 远程桥：由另一台机器上的 agent 代理 ACPI-WMI（Windows / Linux）
    case remoteBridge
    /// 演示模式：不动硬件，用于开发与预览
    case simulated

    public var displayName: String {
        switch self {
        case .hid: return "USB HID"
        case .remoteBridge: return "远程桥接"
        case .simulated: return "演示模式"
        }
    }

    public var isRealHardware: Bool { self != .simulated }
}

/// 设备能力描述。UI 据此隐藏/禁用不支持的控件，避免"点了没反应"。
public struct AuraCapabilities: Codable, Hashable, Sendable {
    public var zones: Set<AuraZone>
    /// 设备固件自带灯效（能一次下发模式码就不需要逐帧推）
    public var hardwareEffects: Bool
    public var brightnessControl: Bool
    public var speedControl: Bool
    /// 逐键/逐灯珠寻址
    public var perKey: Bool
    /// 需要 App 端按帧驱动
    public var softwareAnimation: Bool
    /// 支持的灯效模式（固件能力）
    public var modes: Set<AuraMode>
    /// 亮度档位数（0 表示连续可调），例如笔记本键盘通常是 4 档
    public var brightnessSteps: Int
    /// 速度档位数
    public var speedSteps: Int

    public init(
        zones: Set<AuraZone> = [],
        hardwareEffects: Bool = false,
        brightnessControl: Bool = false,
        speedControl: Bool = false,
        perKey: Bool = false,
        softwareAnimation: Bool = false,
        modes: Set<AuraMode> = [],
        brightnessSteps: Int = 0,
        speedSteps: Int = 0
    ) {
        self.zones = zones
        self.hardwareEffects = hardwareEffects
        self.brightnessControl = brightnessControl
        self.speedControl = speedControl
        self.perKey = perKey
        self.softwareAnimation = softwareAnimation
        self.modes = modes
        self.brightnessSteps = brightnessSteps
        self.speedSteps = speedSteps
    }

    public static let none = AuraCapabilities()

    public static let simulated: AuraCapabilities = {
        AuraCapabilities(
            zones: Set(AuraZone.allCases),
            hardwareEffects: true,
            brightnessControl: true,
            speedControl: true,
            perKey: true,
            softwareAnimation: true,
            modes: Set(AuraMode.allCases),
            brightnessSteps: 0,
            speedSteps: 0
        )
    }()

    public func supports(_ zone: AuraZone) -> Bool { zones.contains(zone) }
}

/// 探测到的设备
public struct DeviceInfo: Codable, Hashable, Sendable, Identifiable {
    public var id: String
    public var name: String
    public var vendor: String
    public var serial: String?
    public var kind: TransportKind
    public var capabilities: AuraCapabilities
    /// 额外说明，例如"协议包未经真机校准"
    public var note: String?

    public init(
        id: String,
        name: String,
        vendor: String = "ASUSTeK COMPUTER INC.",
        serial: String? = nil,
        kind: TransportKind,
        capabilities: AuraCapabilities,
        note: String? = nil
    ) {
        self.id = id
        self.name = name
        self.vendor = vendor
        self.serial = serial
        self.kind = kind
        self.capabilities = capabilities
        self.note = note
    }

    public static let none = DeviceInfo(
        id: "none",
        name: "未连接设备",
        kind: .simulated,
        capabilities: .none
    )
}
