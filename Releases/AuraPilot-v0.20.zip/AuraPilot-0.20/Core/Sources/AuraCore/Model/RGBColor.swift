import Foundation

/// 浮点 RGB 颜色（0...1），灯效计算全部走这个类型，出设备时再量化成 0...255。
/// 用 Double 而不是 UInt8 是为了让呼吸/渐变插值不出现台阶。
public struct RGBColor: Codable, Hashable, Sendable {
    public var red: Double
    public var green: Double
    public var blue: Double

    public init(red: Double, green: Double, blue: Double) {
        self.red = red.clamped01
        self.green = green.clamped01
        self.blue = blue.clamped01
    }

    public init(white: Double) {
        self.init(red: white, green: white, blue: white)
    }

    /// 支持 "#FF5C8A" / "FF5C8A" / "F58"
    public init?(hex: String) {
        var text = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("#") { text.removeFirst() }
        if text.count == 3 {
            text = text.map { "\($0)\($0)" }.joined()
        }
        guard text.count == 6, let value = UInt32(text, radix: 16) else { return nil }
        self.init(
            red: Double((value >> 16) & 0xFF) / 255.0,
            green: Double((value >> 8) & 0xFF) / 255.0,
            blue: Double(value & 0xFF) / 255.0
        )
    }

    public var hexString: String {
        let (r, g, b) = bytes
        return String(format: "#%02X%02X%02X", r, g, b)
    }

    /// 量化到设备字节
    public var bytes: (UInt8, UInt8, UInt8) {
        (UInt8((red * 255).rounded()), UInt8((green * 255).rounded()), UInt8((blue * 255).rounded()))
    }

    public var packedRGB: UInt32 {
        let (r, g, b) = bytes
        return (UInt32(r) << 16) | (UInt32(g) << 8) | UInt32(b)
    }

    // MARK: - HSB

    public init(hue: Double, saturation: Double, brightness: Double) {
        let h = (hue - floor(hue)) * 6.0
        let s = saturation.clamped01
        let v = brightness.clamped01
        let sector = floor(h)
        let f = h - sector
        let p = v * (1 - s)
        let q = v * (1 - s * f)
        let t = v * (1 - s * (1 - f))
        switch Int(sector) % 6 {
        case 0: (red, green, blue) = (v, t, p)
        case 1: (red, green, blue) = (q, v, p)
        case 2: (red, green, blue) = (p, v, t)
        case 3: (red, green, blue) = (p, q, v)
        case 4: (red, green, blue) = (t, p, v)
        default: (red, green, blue) = (v, p, q)
        }
    }

    public var hue: Double {
        let maxValue = max(red, green, blue)
        let minValue = min(red, green, blue)
        let delta = maxValue - minValue
        guard delta > 0.0001 else { return 0 }
        var h: Double
        if maxValue == red {
            h = ((green - blue) / delta).truncatingRemainder(dividingBy: 6)
        } else if maxValue == green {
            h = (blue - red) / delta + 2
        } else {
            h = (red - green) / delta + 4
        }
        h /= 6
        return h < 0 ? h + 1 : h
    }

    public var saturation: Double {
        let maxValue = max(red, green, blue)
        return maxValue <= 0.0001 ? 0 : (maxValue - min(red, green, blue)) / maxValue
    }

    public var value: Double { max(red, green, blue) }

    // MARK: - 运算

    public func scaled(_ factor: Double) -> RGBColor {
        RGBColor(red: red * factor, green: green * factor, blue: blue * factor)
    }

    public func mixed(with other: RGBColor, amount: Double) -> RGBColor {
        let t = amount.clamped01
        return RGBColor(
            red: red + (other.red - red) * t,
            green: green + (other.green - green) * t,
            blue: blue + (other.blue - blue) * t
        )
    }

    public static func lerp(_ from: RGBColor, _ to: RGBColor, _ t: Double) -> RGBColor {
        from.mixed(with: to, amount: t)
    }

    public func rotatedHue(by delta: Double) -> RGBColor {
        RGBColor(hue: hue + delta, saturation: saturation, brightness: value)
    }

    // MARK: - 预设色板

    public static let sakura = RGBColor(hex: "#FF7FA8")!
    public static let rose = RGBColor(hex: "#FF4D7D")!
    public static let magenta = RGBColor(hex: "#E23D9B")!
    public static let peach = RGBColor(hex: "#FFAB91")!
    public static let lilac = RGBColor(hex: "#B98CFF")!
    public static let ice = RGBColor(hex: "#7FD8FF")!
    public static let mint = RGBColor(hex: "#7BE8C3")!
    public static let gold = RGBColor(hex: "#FFD166")!
    public static let crimson = RGBColor(hex: "#E8354A")!
    public static let white = RGBColor(white: 1.0)
    public static let off = RGBColor(white: 0.0)

    public static let palette: [RGBColor] = [
        .rose, .sakura, .magenta, .peach, .lilac, .ice, .mint, .gold, .crimson, .white
    ]
}

extension Double {
    var clamped01: Double { Swift.min(1.0, Swift.max(0.0, self)) }

    func clamped(to range: ClosedRange<Double>) -> Double {
        Swift.min(range.upperBound, Swift.max(range.lowerBound, self))
    }
}

extension BinaryFloatingPoint {
    /// 类似 GLSL fract
    public var fract: Double {
        let value = Double(self)
        return value - floor(value)
    }
}
