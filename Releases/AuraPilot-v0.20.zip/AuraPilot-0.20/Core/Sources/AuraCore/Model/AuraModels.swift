import Foundation

/// 灯区。ASUS 笔记本机身上可独立控制的发光区域。
public enum AuraZone: String, Codable, CaseIterable, Sendable, Identifiable {
    case keyboard
    case lightBar
    case logo

    public var id: String { rawValue }

    public var displayName: String {
        switch self {
        case .keyboard: return "键盘背光"
        case .lightBar: return "灯条"
        case .logo: return "Logo 灯"
        }
    }

    public var shortName: String {
        switch self {
        case .keyboard: return "键盘"
        case .lightBar: return "灯条"
        case .logo: return "Logo"
        }
    }
}

/// 灯效模式。
///
/// rawValue 与 G-Helper `AsusACPI.AuraMode` / ASUS WMI 的 Aura 模式码保持一致，
/// 这样协议包（protocol JSON）可以直接复用社区里已经验证过的数值。
public enum AuraMode: Int, Codable, CaseIterable, Sendable, Identifiable {
    case off = -1
    case solid = 0
    case breathe = 1
    case cycle = 2
    case rainbow = 3
    case star = 4
    case rain = 5
    case highlight = 6
    case laser = 7
    case ripple = 8

    public var id: Int { rawValue }

    /// 用于协议包 JSON 的键名（不用 rawValue，便于人类编辑协议包）
    public var protocolKey: String {
        switch self {
        case .off: return "off"
        case .solid: return "solid"
        case .breathe: return "breathe"
        case .cycle: return "cycle"
        case .rainbow: return "rainbow"
        case .star: return "star"
        case .rain: return "rain"
        case .highlight: return "highlight"
        case .laser: return "laser"
        case .ripple: return "ripple"
        }
    }

    public var displayName: String {
        switch self {
        case .off: return "关闭"
        case .solid: return "静态"
        case .breathe: return "呼吸"
        case .cycle: return "色彩循环"
        case .rainbow: return "彩虹"
        case .star: return "星光"
        case .rain: return "流星雨"
        case .highlight: return "高光扫过"
        case .laser: return "激光"
        case .ripple: return "涟漪"
        }
    }

    /// 是否为逐帧动画（需要软件端持续推送）
    public var isAnimated: Bool { self != .off && self != .solid }

    /// 该模式是否需要第二个颜色
    public var usesSecondaryColor: Bool {
        switch self {
        case .star, .rain, .highlight, .laser, .ripple: return true
        default: return false
        }
    }

    public static var selectable: [AuraMode] { allCases.filter { $0 != .off } }
}

/// 单个灯区的状态
public struct ZoneState: Codable, Hashable, Sendable {
    public var isEnabled: Bool
    public var mode: AuraMode
    public var primary: RGBColor
    public var secondary: RGBColor
    /// 0...1
    public var brightness: Double
    /// 0...1，动画速度
    public var speed: Double

    public init(
        isEnabled: Bool = true,
        mode: AuraMode = .solid,
        primary: RGBColor = .sakura,
        secondary: RGBColor = .lilac,
        brightness: Double = 0.7,
        speed: Double = 0.5
    ) {
        self.isEnabled = isEnabled
        self.mode = mode
        self.primary = primary
        self.secondary = secondary
        self.brightness = brightness.clamped01
        self.speed = speed.clamped01
    }

    public static func `default`(for zone: AuraZone) -> ZoneState {
        switch zone {
        case .keyboard:
            return ZoneState(mode: .solid, primary: .sakura, secondary: .lilac, brightness: 0.65, speed: 0.5)
        case .lightBar:
            return ZoneState(mode: .breathe, primary: .rose, secondary: .magenta, brightness: 0.8, speed: 0.45)
        case .logo:
            return ZoneState(mode: .solid, primary: .magenta, secondary: .rose, brightness: 0.75, speed: 0.5)
        }
    }
}

/// 全局灯光状态
public struct LightingState: Codable, Hashable, Sendable {
    /// 总开关，关闭时所有灯区都不输出
    public var isOn: Bool
    public var zones: [AuraZone: ZoneState]
    public var activePresetID: UUID?

    public init(isOn: Bool = true, zones: [AuraZone: ZoneState] = LightingState.defaultZones, activePresetID: UUID? = nil) {
        self.isOn = isOn
        self.zones = zones
        self.activePresetID = activePresetID
    }

    public static var defaultZones: [AuraZone: ZoneState] {
        var result: [AuraZone: ZoneState] = [:]
        for zone in AuraZone.allCases {
            result[zone] = ZoneState.default(for: zone)
        }
        return result
    }

    public subscript(zone: AuraZone) -> ZoneState {
        get { zones[zone] ?? ZoneState.default(for: zone) }
        set { zones[zone] = newValue }
    }

    /// 灯区最终生效的开关（总开关 + 分区开关）
    public func isZoneActive(_ zone: AuraZone) -> Bool {
        isOn && self[zone].isEnabled
    }

    /// 方便给 UI 做摘要，例如 "呼吸 · 玫瑰"
    public func summary(for zone: AuraZone) -> String {
        let state = self[zone]
        guard isOn, state.isEnabled else { return "已关闭" }
        return "\(state.mode.displayName) · \(state.primary.hexString)"
    }

    public mutating func resetToDefaults() {
        zones = LightingState.defaultZones
        isOn = true
        activePresetID = nil
    }
}

/// 一套完整的灯效预设
public struct Preset: Codable, Hashable, Sendable, Identifiable {
    public var id: UUID
    public var name: String
    public var state: LightingState
    public var isBuiltIn: Bool
    public var createdAt: Date

    public init(
        id: UUID = UUID(),
        name: String,
        state: LightingState,
        isBuiltIn: Bool = false,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.state = state
        self.isBuiltIn = isBuiltIn
        self.createdAt = createdAt
    }

    /// 卡片渐变预览用的两色
    public var previewColors: [RGBColor] {
        let keyboard = state[.keyboard]
        let lightBar = state[.lightBar]
        if !state.isOn { return [RGBColor(white: 0.35), RGBColor(white: 0.2)] }
        return [keyboard.primary, lightBar.primary.mixed(with: lightBar.secondary, amount: 0.5)]
    }
}
