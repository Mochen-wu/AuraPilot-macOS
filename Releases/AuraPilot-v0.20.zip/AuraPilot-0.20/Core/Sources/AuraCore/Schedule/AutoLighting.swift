import Foundation

/// 自动开关灯光的触发方式。
public enum AutoLightingTrigger: String, Codable, CaseIterable, Hashable, Sendable {
    /// 只按时间段（默认 18:00 之后亮，早上自动灭）
    case schedule
    /// 只跟随系统深色模式
    case darkMode
    /// 时间段或深色模式，任一满足就点亮
    case scheduleOrDark

    public var displayName: String {
        switch self {
        case .schedule: return "按时间段"
        case .darkMode: return "跟随深色模式"
        case .scheduleOrDark: return "时间段或深色模式"
        }
    }

    public var detail: String {
        switch self {
        case .schedule: return "只在设定的夜间时段点亮，白天完全熄灭"
        case .darkMode: return "系统切到深色就点亮，切回浅色就熄灭"
        case .scheduleOrDark: return "到点或系统变深色，任一条件满足即点亮"
        }
    }
}

/// 自动开关灯光的配置。存在 `AppSettings` 里，随配置一起持久化。
public struct AutoLightingConfig: Codable, Hashable, Sendable {
    /// 默认启用：白天把灯压到 0、18:00 之后自动恢复，正是"白天别亮"的默认预期
    public var isEnabled: Bool
    public var trigger: AutoLightingTrigger
    /// 点亮开始的时刻（小时 0...23）
    public var startHour: Int
    /// 点亮开始的时刻（分钟 0...59）
    public var startMinute: Int
    /// 熄灭的时刻（小时 0...23）；小于开始时刻表示跨到次日
    public var endHour: Int
    public var endMinute: Int
    /// 非点亮时段的亮度系数：0 = 完全熄灭，0.2 = 保留微光
    public var daytimeLevel: Double

    public init(
        isEnabled: Bool = true,
        trigger: AutoLightingTrigger = .schedule,
        startHour: Int = 18,
        startMinute: Int = 0,
        endHour: Int = 7,
        endMinute: Int = 0,
        daytimeLevel: Double = 0
    ) {
        self.isEnabled = isEnabled
        self.trigger = trigger
        self.startHour = startHour
        self.startMinute = startMinute
        self.endHour = endHour
        self.endMinute = endMinute
        self.daytimeLevel = daytimeLevel
    }

    // 新增字段一律给默认值，保证旧配置文件平滑升级
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isEnabled = try container.decodeIfPresent(Bool.self, forKey: .isEnabled) ?? true
        trigger = try container.decodeIfPresent(AutoLightingTrigger.self, forKey: .trigger) ?? .schedule
        startHour = try container.decodeIfPresent(Int.self, forKey: .startHour) ?? 18
        startMinute = try container.decodeIfPresent(Int.self, forKey: .startMinute) ?? 0
        endHour = try container.decodeIfPresent(Int.self, forKey: .endHour) ?? 7
        endMinute = try container.decodeIfPresent(Int.self, forKey: .endMinute) ?? 0
        daytimeLevel = try container.decodeIfPresent(Double.self, forKey: .daytimeLevel) ?? 0
    }

    /// 开始时刻距零点的分钟数
    public var startMinutesOfDay: Int {
        min(max(startHour, 0), 23) * 60 + min(max(startMinute, 0), 59)
    }

    public var endMinutesOfDay: Int {
        min(max(endHour, 0), 23) * 60 + min(max(endMinute, 0), 59)
    }

    /// 开始与结束同一时刻时视为全天点亮
    public var isAllDay: Bool { startMinutesOfDay == endMinutesOfDay }

    /// 是否跨午夜（例如 18:00 → 07:00）
    public var crossesMidnight: Bool { startMinutesOfDay > endMinutesOfDay }

    /// "18:00 – 次日 07:00" 这类可读描述
    public var windowDescription: String {
        let start = String(format: "%02d:%02d", startHour, startMinute)
        let end = String(format: "%02d:%02d", endHour, endMinute)
        if isAllDay { return "全天" }
        return crossesMidnight ? "\(start) – 次日 \(end)" : "\(start) – \(end)"
    }
}

/// 自动开关的判定结果。
public struct AutoLightingDecision: Hashable, Sendable {
    /// 策略是否在接管亮度（关闭时为 false，亮度维持用户设定）
    public var isActive: Bool
    /// 亮度系数 0...1，乘到用户设定的亮度上
    public var level: Double
    /// 当前是否属于"点亮时段"
    public var isLit: Bool
    /// 面向用户的一句话说明（会写进运行日志）
    public var reason: String

    public init(isActive: Bool, level: Double, isLit: Bool, reason: String) {
        self.isActive = isActive
        self.level = level
        self.isLit = isLit
        self.reason = reason
    }
}

/// 纯函数式的自动开关判定，不依赖任何 AppKit 状态，便于单测。
public enum AutoLighting {
    /// 当前是否落在配置的点亮时间窗内（支持跨午夜、全天）。
    public static func isWithinWindow(
        _ config: AutoLightingConfig,
        at date: Date = Date(),
        calendar: Calendar = .current
    ) -> Bool {
        if config.isAllDay { return true }
        let parts = calendar.dateComponents([.hour, .minute], from: date)
        let now = (parts.hour ?? 0) * 60 + (parts.minute ?? 0)
        let start = config.startMinutesOfDay
        let end = config.endMinutesOfDay
        if start < end { return now >= start && now < end }
        // 跨午夜：晚上的一段 + 凌晨的一段
        return now >= start || now < end
    }

    /// 综合时间与系统外观给出最终亮度系数。
    public static func decide(
        _ config: AutoLightingConfig,
        at date: Date = Date(),
        isDarkMode: Bool = false,
        calendar: Calendar = .current
    ) -> AutoLightingDecision {
        guard config.isEnabled else {
            return AutoLightingDecision(isActive: false, level: 1, isLit: true, reason: "自动开关已关闭")
        }

        let inWindow = isWithinWindow(config, at: date, calendar: calendar)
        let usesSchedule = config.trigger != .darkMode
        let usesDarkMode = config.trigger != .schedule
        let litBySchedule = usesSchedule && inWindow
        let litByDarkMode = usesDarkMode && isDarkMode
        let isLit = litBySchedule || litByDarkMode

        let level = isLit ? 1 : config.daytimeLevel.clamped01
        let reason: String
        switch config.trigger {
        case .schedule:
            reason = inWindow
                ? "点亮时段内（\(config.windowDescription)）→ 正常亮度"
                : "当前不在点亮时段（\(config.windowDescription)）→ 亮度 \(percentText(level))"
        case .darkMode:
            reason = isDarkMode
                ? "系统深色模式 → 正常亮度"
                : "系统浅色模式 → 亮度 \(percentText(level))"
        case .scheduleOrDark:
            if litBySchedule && litByDarkMode {
                reason = "点亮时段 + 深色模式 → 正常亮度"
            } else if litBySchedule {
                reason = "点亮时段内（\(config.windowDescription)）→ 正常亮度"
            } else if litByDarkMode {
                reason = "系统深色模式 → 正常亮度"
            } else {
                reason = "不在点亮时段且是浅色模式 → 亮度 \(percentText(level))"
            }
        }
        return AutoLightingDecision(isActive: true, level: level, isLit: isLit, reason: reason)
    }

    /// 下一次亮度会发生变化的时间点（用于界面提示"下次 18:00 点亮"）。
    public static func nextTransition(
        _ config: AutoLightingConfig,
        after date: Date = Date(),
        calendar: Calendar = .current
    ) -> Date? {
        guard config.isEnabled, config.trigger != .darkMode, !config.isAllDay else { return nil }
        let dayStart = calendar.startOfDay(for: date)
        var candidates: [Date] = []
        for dayOffset in 0...1 {
            guard let day = calendar.date(byAdding: .day, value: dayOffset, to: dayStart) else { continue }
            for minutes in [config.startMinutesOfDay, config.endMinutesOfDay] {
                if let moment = calendar.date(byAdding: .minute, value: minutes, to: day), moment > date {
                    candidates.append(moment)
                }
            }
        }
        return candidates.min()
    }

    private static func percentText(_ level: Double) -> String {
        let percent = Int((level * 100).rounded())
        return percent == 0 ? "0%（熄灭）" : "\(percent)%"
    }
}

/// 手动接管策略。
///
/// 为什么需要：v0.17 及以前，自动开关在白天把 `autoLevel` 压成 0，
/// 用户改颜色 / 模式 / 预设 / 亮度时配置确实写进去了，但渲染亮度仍是 0，
/// 键盘一点反应都没有 —— 表现就是「灯效界面所有按钮都不可用」。
///
/// 规则：**任何一次显式灯效操作都让自动开关暂时让位**，直到下一个
/// 自动切换时间点（18:00 点亮 / 07:00 熄灭）再重新接管。这样白天调试
/// 也能立刻看到效果，而「白天灭、晚上亮、早上灭」的原有需求不变。
public enum ManualOverridePolicy {
    /// 这次手动操作后，自动开关应该在什么时刻重新接管。
    /// - 自动开关未启用：返回 nil（无需接管，也无需让位）
    /// - 有明确时间边界：返回下一次边界（由 `AutoLighting.nextTransition` 给出）
    /// - 只跟随深色模式 / 全天：没有固定边界，给一个兜底时长
    public static func expiry(
        for config: AutoLightingConfig,
        at date: Date = Date(),
        calendar: Calendar = .current,
        fallbackHours: Double = 2
    ) -> Date? {
        guard config.isEnabled else { return nil }
        if let transition = AutoLighting.nextTransition(config, after: date, calendar: calendar) {
            return transition
        }
        return date.addingTimeInterval(max(0.1, fallbackHours) * 3600)
    }

    /// 给定时刻，手动接管是否仍然有效（过期后自动开关重新说了算）
    public static func isActive(until expiry: Date?, at date: Date = Date()) -> Bool {
        guard let expiry else { return false }
        return date < expiry
    }
}
