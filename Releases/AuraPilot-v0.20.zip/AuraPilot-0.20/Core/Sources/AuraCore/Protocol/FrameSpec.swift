import Foundation

/// 数据往哪里送。
public struct AuraChannel: Codable, Hashable, Sendable {
    public enum Kind: String, Codable, Sendable {
        /// HID Feature Report（macOS 原生可用）
        case hidFeature
        /// HID Output Report（部分设备只吃输出报告）
        case hidOutput
        /// ASUS WMI DeviceSet(DeviceID, params)，只有远程桥 agent 能执行
        case asusDeviceSet
    }

    public var kind: Kind
    public var reportID: UInt8
    public var deviceID: UInt32

    public init(kind: Kind, reportID: UInt8 = 0, deviceID: UInt32 = 0) {
        self.kind = kind
        self.reportID = reportID
        self.deviceID = deviceID
    }

    public static func feature(_ reportID: UInt8 = 0) -> AuraChannel {
        AuraChannel(kind: .hidFeature, reportID: reportID)
    }

    public static func output(_ reportID: UInt8 = 0) -> AuraChannel {
        AuraChannel(kind: .hidOutput, reportID: reportID)
    }

    public static func deviceSet(_ deviceID: UInt32) -> AuraChannel {
        AuraChannel(kind: .asusDeviceSet, deviceID: deviceID)
    }
}

/// 一个灯区的封包规则。
///
/// template 里每一项要么是字面字节（"0xB4"、"180"、"B4"），要么是占位符：
/// `$mode` `$r` `$g` `$b` `$r2` `$g2` `$b2` `$brightness` `$brightnessAsus` `$speed` `$zone` `$sum8`
/// `$sum8` 只能出现在最后一项，表示前面所有字节之和的低 8 位。
public struct AuraFrameSpec: Codable, Hashable, Sendable {
    public var name: String
    public var channel: AuraChannel
    /// 补零到的总长度（不含 report ID）。0 表示按 template 实际长度。
    public var length: Int
    public var template: [String]
    /// AuraMode.protocolKey -> 设备模式码
    public var modeCodes: [String: UInt8]
    /// AuraZone.rawValue -> 设备分区码
    public var zoneCodes: [String: UInt8]
    /// 亮度档位数，0 表示 0...255 连续
    public var brightnessLevels: Int
    /// 速度档位数，0 表示 0...255 连续
    public var speedLevels: Int
    /// 速度档位查表：speedLevels > 0 且 speedValues 非空时，
    /// 第 i 档直接取 speedValues[i]（rogauracore 的 {0xE1,0xEB,0xF5} 就是非线性的例子）。
    public var speedValues: [UInt8]?
    /// 每次下发本帧后附带发送的帧（例如 rogauracore 的独立亮度报告）
    public var attached: [AuraFrameSpec]?
    /// 是否把缓冲区补齐到设备的 `MaxFeatureReportLength` 再发。
    /// G-Helper 的 `AsusHid.WriteInput` / `SetFeatureAura` 都是先 new byte[maxFeatureReportLength]
    /// 再拷入数据，长度不足设备会直接丢弃报文。
    public var padToMaxReportLength: Bool

    public init(
        name: String,
        channel: AuraChannel,
        length: Int = 0,
        template: [String],
        modeCodes: [String: UInt8] = [:],
        zoneCodes: [String: UInt8] = [:],
        brightnessLevels: Int = 0,
        speedLevels: Int = 0,
        speedValues: [UInt8]? = nil,
        attached: [AuraFrameSpec]? = nil,
        padToMaxReportLength: Bool = false
    ) {
        self.name = name
        self.channel = channel
        self.length = length
        self.template = template
        self.modeCodes = modeCodes
        self.zoneCodes = zoneCodes
        self.brightnessLevels = brightnessLevels
        self.speedLevels = speedLevels
        self.speedValues = speedValues
        self.attached = attached
        self.padToMaxReportLength = padToMaxReportLength
    }

    private enum CodingKeys: String, CodingKey {
        case name, channel, length, template, modeCodes, zoneCodes
        case brightnessLevels, speedLevels, speedValues, attached, padToMaxReportLength
    }

    // 新增字段给默认值，保证旧的协议包 JSON 还能解析
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        name = try c.decode(String.self, forKey: .name)
        channel = try c.decode(AuraChannel.self, forKey: .channel)
        length = try c.decodeIfPresent(Int.self, forKey: .length) ?? 0
        template = try c.decodeIfPresent([String].self, forKey: .template) ?? []
        modeCodes = try c.decodeIfPresent([String: UInt8].self, forKey: .modeCodes) ?? [:]
        zoneCodes = try c.decodeIfPresent([String: UInt8].self, forKey: .zoneCodes) ?? [:]
        brightnessLevels = try c.decodeIfPresent(Int.self, forKey: .brightnessLevels) ?? 0
        speedLevels = try c.decodeIfPresent(Int.self, forKey: .speedLevels) ?? 0
        speedValues = try c.decodeIfPresent([UInt8].self, forKey: .speedValues)
        attached = try c.decodeIfPresent([AuraFrameSpec].self, forKey: .attached)
        padToMaxReportLength = try c.decodeIfPresent(Bool.self, forKey: .padToMaxReportLength) ?? false
    }
}

/// 一台设备的完整协议包，可来自内置库或用户 JSON。
public struct ProtocolProfile: Codable, Hashable, Sendable, Identifiable {
    public var id: String
    public var displayName: String
    /// 匹配用 USB VID
    public var vendorIDs: [Int]
    /// 匹配用 USB PID，空数组表示匹配该 VID 下全部
    public var productIDs: [Int]
    /// 设备支持哪些灯区（决定 UI 显示）
    public var zones: [AuraZone]
    /// 每个灯区一套封包规则
    public var frames: [String: AuraFrameSpec]
    /// 下发一批帧后是否需要提交指令（单条）
    public var commit: AuraFrameSpec?
    /// 下发一批帧后的提交指令序列（rogauracore 需要 SET 0x5D 0xB5 + APPLY 0x5D 0xB4 两条）
    public var commitFrames: [AuraFrameSpec]?
    /// 传输通道打开后立刻下发一次的初始化帧（rogauracore 的 "ASUS Tech.Inc." 握手）
    public var initFrames: [AuraFrameSpec]?
    /// 关闭某个灯区时专用帧（可选）
    public var offFrames: [String: AuraFrameSpec]?
    /// 未经真机校准的协议包要在 UI 上明确标注
    public var isExperimental: Bool
    public var notes: String?

    public init(
        id: String,
        displayName: String,
        vendorIDs: [Int] = [0x0B05],
        productIDs: [Int] = [],
        zones: [AuraZone] = AuraZone.allCases,
        frames: [String: AuraFrameSpec],
        commit: AuraFrameSpec? = nil,
        commitFrames: [AuraFrameSpec]? = nil,
        initFrames: [AuraFrameSpec]? = nil,
        offFrames: [String: AuraFrameSpec]? = nil,
        isExperimental: Bool = false,
        notes: String? = nil
    ) {
        self.id = id
        self.displayName = displayName
        self.vendorIDs = vendorIDs
        self.productIDs = productIDs
        self.zones = zones
        self.frames = frames
        self.commit = commit
        self.commitFrames = commitFrames
        self.initFrames = initFrames
        self.offFrames = offFrames
        self.isExperimental = isExperimental
        self.notes = notes
    }

    public func frame(for zone: AuraZone) -> AuraFrameSpec? {
        frames[zone.rawValue]
    }

    /// 本协议包要求的最小报告长度（含 report ID 与 attached/commit/init 帧），
    /// 用于在多接口设备中挑接口。IOHIDDeviceSetReport 的缓冲区长度包含首字节 report ID。
    public var minimumReportLength: Int {
        func wireLength(of spec: AuraFrameSpec) -> Int {
            let payload = spec.length > 0 ? spec.length : spec.template.count
            let withID = payload + (spec.channel.reportID != 0 ? 1 : 0)
            let extra = (spec.attached ?? []).map(wireLength).max() ?? 0
            return max(withID, extra)
        }
        let all = Array(frames.values) + (commitFrames ?? []) + (initFrames ?? []) + (commit.map { [$0] } ?? [])
        return all.map(wireLength).max() ?? 0
    }

    /// 这台设备是否落在本协议包的匹配范围
    public func matches(vendorID: Int, productID: Int) -> Bool {
        guard vendorIDs.contains(vendorID) else { return false }
        return productIDs.isEmpty || productIDs.contains(productID)
    }

    public var capabilities: AuraCapabilities {
        var modes: Set<AuraMode> = []
        var brightnessSteps = 0
        var speedSteps = 0
        for spec in frames.values {
            for mode in AuraMode.allCases where spec.modeCodes[mode.protocolKey] != nil {
                modes.insert(mode)
            }
            brightnessSteps = max(brightnessSteps, spec.brightnessLevels)
            speedSteps = max(speedSteps, spec.speedLevels)
            // rogauracore 的亮度是 0x5A 独立报告，挂在 `attached` 上而不是主帧里。
            // 只读 frames.values.first 会恒得 0 → UI 误判为「无全局亮度」，
            // 拖灯条滑杆就只改单灯区，看起来像「亮度控件没用」。
            for attached in spec.attached ?? [] {
                brightnessSteps = max(brightnessSteps, attached.brightnessLevels)
                speedSteps = max(speedSteps, attached.speedLevels)
            }
        }
        return AuraCapabilities(
            zones: Set(zones),
            hardwareEffects: !modes.isEmpty,
            brightnessControl: true,
            speedControl: true,
            perKey: false,
            softwareAnimation: true,
            modes: modes.isEmpty ? Set(AuraMode.allCases) : modes,
            brightnessSteps: brightnessSteps,
            speedSteps: speedSteps
        )
    }
}
