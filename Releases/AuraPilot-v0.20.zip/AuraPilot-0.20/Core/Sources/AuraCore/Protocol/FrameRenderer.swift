import Foundation

/// 把一帧渲染成字节。纯函数，方便单测与离线校验协议包。
public enum FrameRenderer {

    public static func render(_ frame: ZoneFrame, spec: AuraFrameSpec) throws -> [UInt8] {
        var bytes: [UInt8] = []
        bytes.reserveCapacity(max(spec.length, spec.template.count))

        for (index, token) in spec.template.enumerated() {
            if token == "$sum8" {
                guard index == spec.template.count - 1 else {
                    throw AuraError.protocolError("$sum8 必须是模板最后一项")
                }
                bytes.append(checksum8(bytes))
                continue
            }
            bytes.append(try resolve(token, frame: frame, spec: spec))
        }

        if spec.length > 0 {
            if bytes.count > spec.length {
                throw AuraError.protocolError("模板长度 \(bytes.count) 超过声明的 \(spec.length)")
            }
            bytes.append(contentsOf: Array(repeating: 0, count: spec.length - bytes.count))
        }
        return bytes
    }

    public static func checksum8(_ bytes: [UInt8]) -> UInt8 {
        bytes.reduce(UInt8(0)) { $0 &+ $1 }
    }

    // MARK: - Token

    private static func resolve(_ token: String, frame: ZoneFrame, spec: AuraFrameSpec) throws -> UInt8 {
        switch token {
        case "$mode":
            let code = spec.modeCodes[frame.mode.protocolKey]
            // 设备没有这个模式时退化为静态色，避免把设备推到未定义状态
            let fallback = spec.modeCodes[AuraMode.solid.protocolKey] ?? 0
            return code ?? fallback

        case "$r": return frame.primary.bytes.0
        case "$g": return frame.primary.bytes.1
        case "$b": return frame.primary.bytes.2
        case "$r2": return frame.secondary.bytes.0
        case "$g2": return frame.secondary.bytes.1
        case "$b2": return frame.secondary.bytes.2

        case "$brightness":
            return quantize(frame.brightness, levels: spec.brightnessLevels)

        case "$brightnessPercent":
            // 0...100 百分比（外设键盘协议，如 Falchion 的 51 2C 包）
            return UInt8((frame.brightness.clamped01 * 100).rounded())

        case "$brightnessAsus":
            // ASUS 键盘背光：0x80 | level，level 0...3
            let levels = spec.brightnessLevels > 0 ? spec.brightnessLevels : 4
            let level = Int((frame.brightness.clamped01 * Double(levels - 1)).rounded())
            return 0x80 | UInt8(level & 0x7F)

        case "$speed":
            // 有查表时按档位索引取设备速度码，否则按档位/连续量化
            if let table = spec.speedValues, !table.isEmpty {
                let index = Int(FrameRenderer.quantize(frame.speed, levels: table.count))
                return table[min(index, table.count - 1)]
            }
            return quantize(frame.speed, levels: spec.speedLevels)

        case "$speedAnimated":
            // 该字节为 0 的三种情况（macRogAuraCore 的 single_static 就是 0）：
            //   1) 静态  2) 关闭
            //   3) 协议包**没有这个模式码**、$mode 会回落成静态码
            // 第 3 种最容易被忽略：彩虹/星光/流星雨等模式在 rogauracore 协议里没有
            // 对应模式码，旧代码仍写入速度码，发出「mode=0x00 静态 + speed≠0」的组合，
            // 部分固件判为非法帧直接丢弃 —— 表现就是日志 ✅ 事务完成、键盘却毫无反应。
            guard frame.mode != .solid,
                  frame.mode != .off,
                  spec.modeCodes[frame.mode.protocolKey] != nil else { return 0 }
            if let table = spec.speedValues, !table.isEmpty {
                let index = Int(FrameRenderer.quantize(frame.speed, levels: table.count))
                return table[min(index, table.count - 1)]
            }
            return quantize(frame.speed, levels: spec.speedLevels)

        case "$dualFlag":
            // 对齐 G-Helper Aura.cs AuraMessage()：
            //   主色为全黑（关灯）-> 0xFF（random color flag）
            //   呼吸模式 -> 0x01；其余 -> 0x00
            let rgb = frame.primary.bytes
            if rgb.0 == 0, rgb.1 == 0, rgb.2 == 0 { return 0xFF }
            return frame.mode == .breathe ? 1 : 0

        // 副色只在呼吸灯效里有效，其余模式必须为 0
        case "$r2Animated": return frame.mode == .breathe ? frame.secondary.bytes.0 : 0
        case "$g2Animated": return frame.mode == .breathe ? frame.secondary.bytes.1 : 0
        case "$b2Animated": return frame.mode == .breathe ? frame.secondary.bytes.2 : 0

        case "$zone":
            return spec.zoneCodes[frame.zone.rawValue] ?? 0

        default:
            if let value = parseByte(token) { return value }
            throw AuraError.protocolError("无法识别的模板项 \(token)")
        }
    }

    /// levels == 0 时映射到 0...255，否则映射到 0...(levels-1)
    static func quantize(_ value: Double, levels: Int) -> UInt8 {
        let clamped = value.clamped01
        if levels <= 0 {
            return UInt8((clamped * 255).rounded())
        }
        let index = Int((clamped * Double(levels - 1)).rounded())
        return UInt8(max(0, min(levels - 1, index)))
    }

    static func parseByte(_ token: String) -> UInt8? {
        var text = token.trimmingCharacters(in: .whitespaces)
        if text.lowercased().hasPrefix("0x") {
            text = String(text.dropFirst(2))
            return UInt8(text, radix: 16)
        }
        if text.count <= 2, let value = UInt8(text, radix: 16) {
            return value
        }
        return UInt8(text)
    }
}
