import XCTest
@testable import AuraCore

/// 自动开关灯光（时间窗 / 深色模式）的判定逻辑。
/// 全部用固定时区与固定日期，避免跑测试时受本地时间影响。
final class AutoLightingTests: XCTestCase {
    private var calendar: Calendar = {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        return cal
    }()

    private func date(_ hour: Int, _ minute: Int, day: Int = 15) -> Date {
        var parts = DateComponents()
        parts.year = 2025
        parts.month = 11
        parts.day = day
        parts.hour = hour
        parts.minute = minute
        return calendar.date(from: parts)!
    }

    private func config(
        enabled: Bool = true,
        trigger: AutoLightingTrigger = .schedule,
        start: (Int, Int) = (18, 0),
        end: (Int, Int) = (7, 0),
        daytime: Double = 0
    ) -> AutoLightingConfig {
        AutoLightingConfig(
            isEnabled: enabled,
            trigger: trigger,
            startHour: start.0,
            startMinute: start.1,
            endHour: end.0,
            endMinute: end.1,
            daytimeLevel: daytime
        )
    }

    // MARK: - 时间窗

    /// 18:00 → 次日 07:00：晚上点亮、白天熄灭
    func testCrossMidnightWindow() {
        let cfg = config()
        XCTAssertTrue(cfg.crossesMidnight)

        let evening = AutoLighting.decide(cfg, at: date(19, 30), calendar: calendar)
        XCTAssertTrue(evening.isLit)
        XCTAssertEqual(evening.level, 1, accuracy: 0.0001)

        let midnight = AutoLighting.decide(cfg, at: date(23, 59), calendar: calendar)
        XCTAssertTrue(midnight.isLit)

        let dawn = AutoLighting.decide(cfg, at: date(6, 59), calendar: calendar)
        XCTAssertTrue(dawn.isLit)

        let morning = AutoLighting.decide(cfg, at: date(7, 0), calendar: calendar)
        XCTAssertFalse(morning.isLit)
        XCTAssertEqual(morning.level, 0, accuracy: 0.0001)

        let noon = AutoLighting.decide(cfg, at: date(12, 0), calendar: calendar)
        XCTAssertFalse(noon.isLit)
        XCTAssertEqual(noon.level, 0, accuracy: 0.0001)
    }

    /// 边界：起点含、终点不含
    func testWindowBoundaries() {
        let cfg = config(start: (18, 0), end: (7, 0))
        XCTAssertTrue(AutoLighting.isWithinWindow(cfg, at: date(18, 0), calendar: calendar))
        XCTAssertFalse(AutoLighting.isWithinWindow(cfg, at: date(17, 59), calendar: calendar))
        XCTAssertFalse(AutoLighting.isWithinWindow(cfg, at: date(7, 0), calendar: calendar))
        XCTAssertTrue(AutoLighting.isWithinWindow(cfg, at: date(6, 59), calendar: calendar))
    }

    /// 不跨午夜的窗口（例如 09:00–17:00 上班时间点亮）
    func testSameDayWindow() {
        let cfg = config(start: (9, 0), end: (17, 0))
        XCTAssertFalse(cfg.crossesMidnight)
        XCTAssertTrue(AutoLighting.isWithinWindow(cfg, at: date(10, 0), calendar: calendar))
        XCTAssertTrue(AutoLighting.isWithinWindow(cfg, at: date(16, 59), calendar: calendar))
        XCTAssertFalse(AutoLighting.isWithinWindow(cfg, at: date(17, 0), calendar: calendar))
        XCTAssertFalse(AutoLighting.isWithinWindow(cfg, at: date(2, 0), calendar: calendar))
    }

    /// 起止同一时刻视为全天点亮
    func testAllDayWindow() {
        let cfg = config(start: (8, 0), end: (8, 0))
        XCTAssertTrue(cfg.isAllDay)
        XCTAssertEqual(cfg.windowDescription, "全天")
        XCTAssertTrue(AutoLighting.isWithinWindow(cfg, at: date(3, 0), calendar: calendar))
        XCTAssertTrue(AutoLighting.isWithinWindow(cfg, at: date(15, 0), calendar: calendar))
        XCTAssertEqual(AutoLighting.decide(cfg, at: date(3, 0), calendar: calendar).level, 1, accuracy: 0.0001)
    }

    // MARK: - 深色模式

    func testDarkModeTrigger() {
        let cfg = config(trigger: .darkMode, start: (18, 0), end: (7, 0))

        let dark = AutoLighting.decide(cfg, at: date(12, 0), isDarkMode: true, calendar: calendar)
        XCTAssertTrue(dark.isLit)
        XCTAssertEqual(dark.level, 1, accuracy: 0.0001)

        // 时间窗对它无效：即便在夜间时段，浅色模式也要熄灭
        let lightAtNight = AutoLighting.decide(cfg, at: date(22, 0), isDarkMode: false, calendar: calendar)
        XCTAssertFalse(lightAtNight.isLit)
        XCTAssertEqual(lightAtNight.level, 0, accuracy: 0.0001)
    }

    func testScheduleOrDarkTrigger() {
        let cfg = config(trigger: .scheduleOrDark)

        // 夜间 + 浅色：靠时间窗点亮
        XCTAssertTrue(AutoLighting.decide(cfg, at: date(21, 0), isDarkMode: false, calendar: calendar).isLit)
        // 白天 + 深色：靠深色模式点亮
        XCTAssertTrue(AutoLighting.decide(cfg, at: date(14, 0), isDarkMode: true, calendar: calendar).isLit)
        // 白天 + 浅色：熄灭
        let day = AutoLighting.decide(cfg, at: date(14, 0), isDarkMode: false, calendar: calendar)
        XCTAssertFalse(day.isLit)
        XCTAssertEqual(day.level, 0, accuracy: 0.0001)
    }

    // MARK: - 亮度系数

    /// 白天可以留一点微光，而不是必须全灭
    func testDaytimeLevelIsHonored() {
        let cfg = config(daytime: 0.2)
        let day = AutoLighting.decide(cfg, at: date(12, 0), calendar: calendar)
        XCTAssertFalse(day.isLit)
        XCTAssertEqual(day.level, 0.2, accuracy: 0.0001)
        XCTAssertEqual(AutoLighting.decide(cfg, at: date(20, 0), calendar: calendar).level, 1, accuracy: 0.0001)
    }

    /// 关闭自动开关时不做任何干预
    func testDisabledKeepsFullBrightness() {
        let cfg = config(enabled: false, daytime: 0)
        let decision = AutoLighting.decide(cfg, at: date(12, 0), calendar: calendar)
        XCTAssertFalse(decision.isActive)
        XCTAssertEqual(decision.level, 1, accuracy: 0.0001)
        XCTAssertEqual(decision.reason, "自动开关已关闭")
    }

    // MARK: - 提示文案与下次切换

    func testWindowDescription() {
        XCTAssertEqual(config(start: (18, 0), end: (7, 0)).windowDescription, "18:00 – 次日 07:00")
        XCTAssertEqual(config(start: (9, 0), end: (17, 30)).windowDescription, "09:00 – 17:30")
        XCTAssertEqual(config(start: (8, 0), end: (8, 0)).windowDescription, "全天")
    }

    func testNextTransition() {
        let cfg = config(start: (18, 0), end: (7, 0))

        // 上午 10 点：下一次变化是当天 18:00
        let noonNext = AutoLighting.nextTransition(cfg, after: date(10, 0), calendar: calendar)
        XCTAssertNotNil(noonNext)
        XCTAssertEqual(calendar.component(.hour, from: noonNext!), 18)
        XCTAssertEqual(calendar.component(.day, from: noonNext!), 15)

        // 晚上 20 点：下一次变化是次日 07:00
        let eveningNext = AutoLighting.nextTransition(cfg, after: date(20, 0), calendar: calendar)
        XCTAssertNotNil(eveningNext)
        XCTAssertEqual(calendar.component(.hour, from: eveningNext!), 7)
        XCTAssertEqual(calendar.component(.day, from: eveningNext!), 16)

        // 深色模式触发没有固定时间点
        XCTAssertNil(AutoLighting.nextTransition(
            config(trigger: .darkMode), after: date(10, 0), calendar: calendar))
    }

    // MARK: - 持久化

    /// 旧版 config.json 没有 autoLighting 字段，必须能平滑升级为"未启用"
    func testLegacySettingsDecodeWithoutAutoLighting() throws {
        let legacy = """
        {"showTemperatureInMenuBar":true,"engineFPS":30,"launchAtLogin":false,
         "turnOffOnSleep":true,"restoreOnWake":true,"appearance":"system","themeID":"pink"}
        """
        let settings = try JSONDecoder().decode(AppSettings.self, from: Data(legacy.utf8))
        // 旧配置升级后直接采用默认值（默认启用，白天熄灭）
        XCTAssertTrue(settings.autoLighting.isEnabled)
        XCTAssertEqual(settings.autoLighting.startHour, 18)
        XCTAssertEqual(settings.autoLighting.endHour, 7)
        XCTAssertEqual(settings.autoLighting.daytimeLevel, 0, accuracy: 0.0001)
    }

    func testConfigRoundTrip() throws {
        var cfg = config(trigger: .scheduleOrDark, start: (20, 15), end: (6, 30), daytime: 0.15)
        cfg.isEnabled = true
        let data = try JSONEncoder().encode(cfg)
        let decoded = try JSONDecoder().decode(AutoLightingConfig.self, from: data)
        XCTAssertEqual(decoded, cfg)
    }

    // MARK: - 手动接管（v0.18：白天调灯效不能被自动压暗吞掉）

    func testManualOverrideExpiresAtNextTransition() {
        let cfg = config()
        let now = date(10, 0)
        let expiry = ManualOverridePolicy.expiry(for: cfg, at: now, calendar: calendar)
        XCTAssertNotNil(expiry)
        XCTAssertEqual(calendar.component(.hour, from: expiry!), 18)
        XCTAssertEqual(calendar.component(.day, from: expiry!), 15)
        // 有效期内自动开关不能压暗，过期后重新接管
        XCTAssertTrue(ManualOverridePolicy.isActive(until: expiry, at: date(17, 59)))
        XCTAssertFalse(ManualOverridePolicy.isActive(until: expiry, at: date(18, 1)))
    }

    func testManualOverrideDisabledDoesNotApply() {
        XCTAssertNil(ManualOverridePolicy.expiry(
            for: config(enabled: false), at: date(10, 0), calendar: calendar))
        XCTAssertFalse(ManualOverridePolicy.isActive(until: nil, at: date(10, 0)))
    }

    func testManualOverrideFallbackWithoutFixedTransition() {
        // 只跟随深色模式没有固定时间点，用兜底时长
        let cfg = config(trigger: .darkMode)
        let now = date(10, 0)
        let expiry = ManualOverridePolicy.expiry(
            for: cfg, at: now, calendar: calendar, fallbackHours: 2)
        XCTAssertNotNil(expiry)
        XCTAssertEqual(expiry!.timeIntervalSince(now), 7200, accuracy: 0.001)
    }

    func testRogAuraCoreReportsGlobalBrightnessSteps() {
        // 亮度帧挂在 attached（0x5A，4 档）而不是主灯效帧里。
        // 只读 frames.values.first 会得 0 → UI 误判为无全局亮度 → 亮度控件像失灵。
        let caps = ProtocolLibrary.rogAuraCore().capabilities
        XCTAssertEqual(caps.brightnessSteps, 4)
        XCTAssertEqual(caps.speedSteps, 3)
        XCTAssertEqual(caps.zones.count, 3)
    }
}
