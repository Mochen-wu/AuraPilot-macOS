import XCTest
@testable import AuraCore

final class FramePolicyTests: XCTestCase {

    private func animatedFrame(_ primary: RGBColor = RGBColor(red: 0.9, green: 0.1, blue: 0.1)) -> ZoneFrame {
        ZoneFrame(zone: .keyboard, mode: .breathe, primary: primary,
                  secondary: .lilac, brightness: 0.7, speed: 0.5, elapsed: 12)
    }

    /// 固件自带灯效：动画帧主色固定为基色，两个不同时刻的帧 dedupeKey 相同
    /// → 整个事务只发一次，不会逐帧 APPLY 造成 HID 反复掉线闪烁。
    func testHardwareEffectsFreezesAnimatedColor() {
        let base = RGBColor(red: 1, green: 0, blue: 0)
        let first = FramePolicy.normalize(animatedFrame(), baseColor: base, hardwareEffects: true)
        let later = FramePolicy.normalize(
            animatedFrame(RGBColor(red: 0, green: 0.8, blue: 0.2)),
            baseColor: base, hardwareEffects: true
        )

        XCTAssertEqual(first.primary, base)
        XCTAssertEqual(later.primary, base)
        XCTAssertEqual(first.dedupeKey, later.dedupeKey)
        // 模式码必须保留，固件才知道要跑呼吸而不是静态
        XCTAssertEqual(first.mode, .breathe)
    }

    func testSoftwareAnimationStillVariesPerFrame() {
        let base = RGBColor(red: 1, green: 0, blue: 0)
        let first = FramePolicy.normalize(animatedFrame(), baseColor: base, hardwareEffects: false)
        let later = FramePolicy.normalize(
            animatedFrame(RGBColor(red: 0, green: 0.8, blue: 0.2)),
            baseColor: base, hardwareEffects: false
        )
        XCTAssertNotEqual(first.dedupeKey, later.dedupeKey)
    }

    func testStaticFramesNeverTouched() {
        let staticFrame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .sakura,
                                    secondary: .lilac, brightness: 0.5, speed: 0.5, elapsed: 9)
        let result = FramePolicy.normalize(staticFrame,
                                           baseColor: RGBColor(red: 0, green: 0, blue: 0),
                                           hardwareEffects: true)
        XCTAssertEqual(result, staticFrame)
    }

    /// rogauracore 的 modeCodes 非空 → hardwareEffects = true，动画应当交给固件
    func testRogAuraCoreHasHardwareEffects() {
        XCTAssertTrue(ProtocolLibrary.rogAuraCore().capabilities.hardwareEffects)
    }
}
