import XCTest
@testable import AuraCore

final class EffectsTests: XCTestCase {
    func testOffIsBlack() {
        let color = Effects.color(mode: .off, primary: .rose, secondary: .lilac, speed: 0.5, phase: 0, time: 1)
        XCTAssertEqual(color, RGBColor(white: 0))
    }

    func testSolidIsPrimary() {
        let color = Effects.color(mode: .solid, primary: .rose, secondary: .lilac, speed: 0.5, phase: 0, time: 3)
        XCTAssertEqual(color, .rose)
    }

    func testBreatheStaysInRange() {
        for step in 0..<200 {
            let t = Double(step) * 0.05
            let color = Effects.color(mode: .breathe, primary: .sakura, secondary: .lilac, speed: 0.6, phase: 0, time: t)
            XCTAssertGreaterThanOrEqual(color.red, 0)
            XCTAssertLessThanOrEqual(color.red, 1)
            XCTAssertGreaterThanOrEqual(color.value, 0)
            XCTAssertLessThanOrEqual(color.value, 1)
        }
    }

    func testDeterministic() {
        let a = Effects.color(mode: .star, primary: .rose, secondary: .gold, speed: 0.4, phase: 0.2, time: 5.5)
        let b = Effects.color(mode: .star, primary: .rose, secondary: .gold, speed: 0.4, phase: 0.2, time: 5.5)
        XCTAssertEqual(a, b)
    }

    func testAnimationActuallyChanges() {
        let a = Effects.color(mode: .rainbow, primary: .rose, secondary: .lilac, speed: 0.5, phase: 0, time: 0.0)
        let b = Effects.color(mode: .rainbow, primary: .rose, secondary: .lilac, speed: 0.5, phase: 0, time: 1.0)
        XCTAssertNotEqual(a.hexString, b.hexString)
    }
}

final class LightingEngineTests: XCTestCase {
    func testDisabledZoneProducesOffFrame() {
        var state = LightingState()
        state[.lightBar].isEnabled = false
        let engine = LightingEngine(state: state)
        let frame = engine.frame(for: .lightBar, at: Date().timeIntervalSinceReferenceDate + 1)
        XCTAssertEqual(frame.mode, .off)
        XCTAssertEqual(frame.brightness, 0)
    }

    func testGlobalOffOverridesZones() {
        var state = LightingState()
        state.isOn = false
        let engine = LightingEngine(state: state)
        for frame in engine.frames(at: Date().timeIntervalSinceReferenceDate + 1) {
            XCTAssertEqual(frame.mode, .off)
        }
    }

    func testContinuousUpdateDetection() {
        var state = LightingState(zones: LightingState.defaultZones)
        state[.keyboard].mode = .solid
        state[.lightBar].mode = .solid
        state[.logo].mode = .solid
        let engine = LightingEngine(state: state)
        XCTAssertFalse(engine.needsContinuousUpdates)

        state[.logo].mode = .breathe
        engine.state = state
        XCTAssertTrue(engine.needsContinuousUpdates)
    }

    func testDedupeKeyIgnoresTime() {
        let a = ZoneFrame(zone: .keyboard, mode: .solid, primary: .rose, secondary: .lilac, brightness: 0.5, speed: 0.5, elapsed: 1)
        let b = ZoneFrame(zone: .keyboard, mode: .solid, primary: .rose, secondary: .lilac, brightness: 0.5, speed: 0.5, elapsed: 9)
        XCTAssertEqual(a.dedupeKey, b.dedupeKey)
    }
}

final class ConfigStoreTests: XCTestCase {
    func testRoundTrip() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let store = ConfigStore(directory: directory)
        var config = StoredConfig()
        config.state[.keyboard].primary = RGBColor(hex: "#123456")!
        config.settings.engineFPS = 60
        config.presets.append(Preset(name: "测试", state: config.state))
        store.save(config)

        let loaded = store.load()
        XCTAssertEqual(loaded.state[.keyboard].primary.hexString, "#123456")
        XCTAssertEqual(loaded.settings.engineFPS, 60)
        XCTAssertTrue(loaded.presets.contains { $0.name == "测试" })
        try? FileManager.default.removeItem(at: directory)
    }

    func testCorruptFileFallsBackToDefaults() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try Data("not json".utf8).write(to: directory.appendingPathComponent("config.json"))

        let store = ConfigStore(directory: directory)
        let loaded = store.load()
        XCTAssertEqual(loaded.version, 1)
        XCTAssertFalse(loaded.presets.isEmpty)
        try? FileManager.default.removeItem(at: directory)
    }

    func testBuiltInPresetsAreMarked() {
        XCTAssertTrue(StoredConfig.builtInPresets.allSatisfy { $0.isBuiltIn })
        XCTAssertGreaterThanOrEqual(StoredConfig.builtInPresets.count, 3)
    }
}

final class ProtocolLibraryTests: XCTestCase {
    func testBuiltInProfilesExist() {
        let profiles = ProtocolLibrary.builtInProfiles()
        XCTAssertFalse(profiles.isEmpty)
        XCTAssertNotNil(profiles.first { $0.id == "asus-wmi-tuf-keyboard" })
    }

    func testCapabilitiesFromProfile() {
        let profile = ProtocolLibrary.wmiTUFKeyboard()
        let capabilities = profile.capabilities
        XCTAssertTrue(capabilities.zones.contains(.keyboard))
        XCTAssertTrue(capabilities.modes.contains(.rainbow))
    }

    func testProfileCodableRoundTrip() throws {
        let profile = ProtocolLibrary.genericHID()
        let data = try JSONEncoder().encode(profile)
        let decoded = try JSONDecoder().decode(ProtocolProfile.self, from: data)
        XCTAssertEqual(decoded.id, profile.id)
        XCTAssertEqual(decoded.frames.count, profile.frames.count)
    }
}
