import XCTest
@testable import AuraCore

final class ColorTests: XCTestCase {
    func testHexRoundTrip() {
        let color = RGBColor(hex: "#FF7FA8")
        XCTAssertNotNil(color)
        XCTAssertEqual(color?.hexString, "#FF7FA8")
        XCTAssertEqual(color?.bytes.0, 255)
        XCTAssertEqual(color?.bytes.1, 127)
        XCTAssertEqual(color?.bytes.2, 168)
    }

    func testShortHex() {
        XCTAssertEqual(RGBColor(hex: "f0a")?.hexString, "#FF00AA")
    }

    func testHSBRoundTrip() {
        let original = RGBColor(hex: "#4D8BFF")!
        let restored = RGBColor(hue: original.hue, saturation: original.saturation, brightness: original.value)
        XCTAssertEqual(Int(restored.bytes.0), Int(original.bytes.0), accuracy: 1)
        XCTAssertEqual(Int(restored.bytes.1), Int(original.bytes.1), accuracy: 1)
        XCTAssertEqual(Int(restored.bytes.2), Int(original.bytes.2), accuracy: 1)
    }

    func testClamping() {
        let color = RGBColor(red: 2, green: -1, blue: 0.5)
        XCTAssertEqual(color.red, 1)
        XCTAssertEqual(color.green, 0)
    }

    func testPackedRGB() {
        XCTAssertEqual(RGBColor(hex: "#FF0000")!.packedRGB, 0xFF0000)
    }
}

final class FrameRendererTests: XCTestCase {
    func testTUFKeyboardFrame() throws {
        let spec = ProtocolLibrary.wmiTUFKeyboard().frame(for: .keyboard)!
        let frame = ZoneFrame(
            zone: .keyboard,
            mode: .breathe,
            primary: RGBColor(hex: "#FF7FA8")!,
            secondary: .lilac,
            brightness: 0.7,
            speed: 0.5,
            elapsed: 0
        )
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes, [0xB4, 0x01, 255, 127, 168, 128])
    }

    func testChecksum() throws {
        let spec = AuraFrameSpec(
            name: "checksum",
            channel: .feature(0),
            length: 3,
            template: ["0x01", "0x02", "$sum8"]
        )
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .white, secondary: .white, brightness: 1, speed: 0, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes, [1, 2, 3])
    }

    func testPaddingToDeclaredLength() throws {
        let spec = AuraFrameSpec(name: "pad", channel: .feature(0), length: 8, template: ["0xEC"])
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .rose, secondary: .rose, brightness: 1, speed: 0, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes.count, 8)
        XCTAssertEqual(bytes[0], 0xEC)
        XCTAssertEqual(Array(bytes.suffix(7)), [UInt8](repeating: 0, count: 7))
    }

    func testQuantizeLevels() {
        XCTAssertEqual(FrameRenderer.quantize(0.0, levels: 4), 0)
        XCTAssertEqual(FrameRenderer.quantize(0.5, levels: 4), 2)
        XCTAssertEqual(FrameRenderer.quantize(1.0, levels: 4), 3)
    }

    func testAsusBrightnessToken() throws {
        let spec = AuraFrameSpec(
            name: "asus-brightness",
            channel: .deviceSet(0x0005_0021),
            length: 1,
            template: ["$brightnessAsus"],
            brightnessLevels: 4
        )
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .white, secondary: .white, brightness: 1.0, speed: 0, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes, [0x83])
    }

    func testBadTokenThrows() {
        let spec = AuraFrameSpec(name: "bad", channel: .feature(0), template: ["$nope"])
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .white, secondary: .white, brightness: 1, speed: 0, elapsed: 0)
        XCTAssertThrowsError(try FrameRenderer.render(frame, spec: spec))
    }

    // MARK: - rogauracore（macRogAuraCore 逐字节核对）

    /// 对照 main.c single_static：initMessage 后 [4][5][6] = R G B，其余 0，长度 17
    func testRogAuraCoreStaticFrame() throws {
        let profile = ProtocolLibrary.rogAuraCore()
        let spec = profile.frame(for: .keyboard)!
        let frame = ZoneFrame(
            zone: .keyboard,
            mode: .solid,
            primary: RGBColor(hex: "#FF00FF")!,
            secondary: .off,
            brightness: 1,
            speed: 0.5,
            elapsed: 0
        )
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes.count, 16)         // 17 字节含 report ID，payload 16
        XCTAssertEqual(bytes[0], 0xB3)          // 0x5D 由传输层拼回首字节
        XCTAssertEqual(bytes[1], 0x00)          // 单灯效 zone 字节为 0
        XCTAssertEqual(bytes[2], 0x00)          // static
        XCTAssertEqual([bytes[3], bytes[4], bytes[5]], [0xFF, 0x00, 0xFF])
        XCTAssertEqual(bytes[6], 0x00)          // 静态模式速度字节必须为 0（上游 single_static）
        XCTAssertEqual(Array(bytes.dropFirst(7)), [UInt8](repeating: 0, count: 9))
    }

    /// 对照 main.c single_breathing：mode=1，[9..11] 为第二色，speed 查表
    func testRogAuraCoreBreathingFrame() throws {
        let spec = ProtocolLibrary.rogAuraCore().frame(for: .keyboard)!
        let frame = ZoneFrame(
            zone: .keyboard,
            mode: .breathe,
            primary: RGBColor(hex: "#102030")!,
            secondary: RGBColor(hex: "#FFFFFF")!,
            brightness: 0,
            speed: 1,
            elapsed: 0
        )
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes[2], 0x01)
        XCTAssertEqual(bytes[6], 0xF5)          // UI 速度满档 -> 查表第 3 档 0xF5（上游 speed=3）
        XCTAssertEqual(bytes[8], 0x01)          // 双色标志：上游 single_breathing 置 1
        XCTAssertEqual([bytes[9], bytes[10], bytes[11]], [0xFF, 0xFF, 0xFF])
    }

    /// 速度查表：三档 {0xE1, 0xEB, 0xF5}
    func testSpeedLookupTable() throws {
        let spec = ProtocolLibrary.rogAuraCore().frame(for: .keyboard)!
        func speedByte(_ value: Double) throws -> UInt8 {
            // 只有动画档才写速度码；静态档该字节固定 0
            let frame = ZoneFrame(zone: .keyboard, mode: .breathe, primary: .white, secondary: .off,
                                  brightness: 0, speed: value, elapsed: 0)
            return try FrameRenderer.render(frame, spec: spec)[6]
        }
        XCTAssertEqual(try speedByte(0.0), 0xE1)
        XCTAssertEqual(try speedByte(0.5), 0xEB)
        XCTAssertEqual(try speedByte(1.0), 0xF5)
    }

    /// 协议包没有该模式码时，$mode 回落成静态（0x00），速度字节也必须为 0。
    /// 旧版仍写入速度码，发出「mode=0x00 + speed≠0」的非法帧被固件直接丢弃 ——
    /// 表现就是日志 ✅ 事务完成、键盘却毫无反应。
    func testUnsupportedModeDoesNotEmitIllegalFrame() throws {
        let spec = ProtocolLibrary.rogAuraCore().frame(for: .keyboard)!
        let frame = ZoneFrame(zone: .keyboard, mode: .rainbow, primary: .white, secondary: .off,
                              brightness: 0.7, speed: 1.0, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes[2], 0x00, "彩虹没有模式码，应回落为静态码")
        XCTAssertEqual(bytes[6], 0x00, "回落为静态时速度必须为 0，否则固件丢弃整帧")
    }

    /// 支持的动画模式仍要正常写模式码与速度码，别把修复做过头
    func testSupportedAnimatedModeStillWritesSpeed() throws {
        let spec = ProtocolLibrary.rogAuraCore().frame(for: .keyboard)!
        let frame = ZoneFrame(zone: .keyboard, mode: .breathe, primary: .white, secondary: .off,
                              brightness: 0.7, speed: 1.0, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes[2], 0x01)
        XCTAssertEqual(bytes[6], 0xF5)
    }

    /// 亮度帧独立：`5A BA C5 C4 [0..3]`，0..3 线性四档
    func testRogAuraCoreBrightnessAttachment() throws {
        let profile = ProtocolLibrary.rogAuraCore()
        let spec = profile.frame(for: .keyboard)!
        let attached = try XCTUnwrap(spec.attached?.first)
        func brightnessByte(_ value: Double) throws -> UInt8 {
            let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .white, secondary: .off,
                                  brightness: value, speed: 0, elapsed: 0)
            return try FrameRenderer.render(frame, spec: attached)[3]
        }
        XCTAssertEqual(try brightnessByte(0.0), 0)
        XCTAssertEqual(try brightnessByte(0.34), 1)
        XCTAssertEqual(try brightnessByte(1.0), 3)
    }

    /// 初始化握手（真机验证必须先发：不发它 0x5D 颜色帧会被忽略）。
    /// macRogAuraCore 的 initialize_keyboard 命令发的就是这条：
    /// 5A + "ASUS Tech.Inc." + 00 00（17B Feature）。
    func testRogAuraCoreInitFrame() throws {
        let profile = ProtocolLibrary.rogAuraCore()
        let initFrames = try XCTUnwrap(profile.initFrames)
        XCTAssertEqual(initFrames.count, 1)
        let spec = initFrames[0]
        XCTAssertEqual(spec.channel.kind, .hidFeature)
        XCTAssertEqual(spec.channel.reportID, 0x5A)
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .off, secondary: .off,
                              brightness: 0, speed: 0, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes.count, 16)
        XCTAssertEqual(Array(bytes.prefix(14)), Array("ASUS Tech.Inc.".utf8))
        XCTAssertEqual(bytes[14], 0x00)
        XCTAssertEqual(bytes[15], 0x00)
    }

    /// 提交序列：SET(0xB5) → APPLY(0xB4)，都是 17 字节 Feature（B5/B4 + 15 个 0）
    func testRogAuraCoreCommitSequence() throws {
        let profile = ProtocolLibrary.rogAuraCore()
        let commits = try XCTUnwrap(profile.commitFrames)
        XCTAssertEqual(commits.count, 2)
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .off, secondary: .off,
                              brightness: 0, speed: 0, elapsed: 0)
        // macRogAuraCore: MESSAGE_SET / MESSAGE_APPLY 均为 17B（含 report ID）
        XCTAssertEqual(try FrameRenderer.render(frame, spec: commits[0]), [0xB5] + [UInt8](repeating: 0, count: 15))
        XCTAssertEqual(try FrameRenderer.render(frame, spec: commits[1]), [0xB4] + [UInt8](repeating: 0, count: 15))
    }

    // MARK: - Falchion 外设协议（G-Helper AsusKeyboard.cs 逐字节核对）

    /// `51 2C [mode] 00 [speed] [亮度%] [colorMode] 00 02 R G B R2 G2 B2 R3 G3 B3`，补 0 到 64
    func testFalchionStaticFrame() throws {
        let profile = ProtocolLibrary.falchionFamily()
        let spec = profile.frame(for: .keyboard)!
        let frame = ZoneFrame(
            zone: .keyboard,
            mode: .solid,
            primary: RGBColor(hex: "#FF4080")!,
            secondary: .off,
            brightness: 0.5,
            speed: 0.5,
            elapsed: 0
        )
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes.count, 64)                 // payload，不含 report ID 0x00
        XCTAssertEqual([bytes[0], bytes[1]], [0x51, 0x2C])
        XCTAssertEqual(bytes[2], 0x00)                  // static
        XCTAssertEqual(bytes[3], 0x00)                  // chunk tag
        XCTAssertEqual(bytes[4], 30)                    // speed 0.5 -> 正常档 30
        XCTAssertEqual(bytes[5], 50)                    // 亮度 50%
        XCTAssertEqual(bytes[6], 0)                     // 单色模式
        XCTAssertEqual(bytes[8], 0x02)
        XCTAssertEqual([bytes[9], bytes[10], bytes[11]], [0xFF, 0x40, 0x80])
        XCTAssertEqual(Array(bytes.dropFirst(18)), [UInt8](repeating: 0, count: 46))
    }

    func testFalchionModeMapping() throws {
        let spec = ProtocolLibrary.falchionFamily().frame(for: .keyboard)!
        func modeByte(_ mode: AuraMode) throws -> UInt8 {
            let frame = ZoneFrame(zone: .keyboard, mode: mode, primary: .rose, secondary: .off,
                                  brightness: 1, speed: 0, elapsed: 0)
            return try FrameRenderer.render(frame, spec: spec)[2]
        }
        XCTAssertEqual(try modeByte(.breathe), 0x01)
        XCTAssertEqual(try modeByte(.cycle), 0x02)
        XCTAssertEqual(try modeByte(.rainbow), 0x04)    // 硬件波浪
        XCTAssertEqual(try modeByte(.star), 0x06)
        XCTAssertEqual(try modeByte(.rain), 0x09)
        XCTAssertEqual(try modeByte(.laser), 0x00)      // 不支持时退化静态
    }

    /// OMNI 矮轴：report ID 0x02、payload 63 字节
    func testFalchionOmniFrame() throws {
        let profile = ProtocolLibrary.falchionOmni()
        XCTAssertEqual(profile.productIDs, [0x1ACE])
        let spec = profile.frame(for: .keyboard)!
        let frame = ZoneFrame(zone: .keyboard, mode: .solid, primary: .white, secondary: .off,
                              brightness: 1, speed: 1, elapsed: 0)
        let bytes = try FrameRenderer.render(frame, spec: spec)
        XCTAssertEqual(bytes.count, 63)
        XCTAssertEqual(spec.channel.kind, .hidOutput)
        XCTAssertEqual(spec.channel.reportID, 0x02)
        XCTAssertEqual(bytes[4], 10)                    // 速度满档 -> 10（越快字节越小）
    }

    /// 内置键盘 PID 0x19B6 必须落在 rogauracore 包里
    func testProfileMatchingByPID() {
        let profile = ProtocolLibrary.rogAuraCore()
        XCTAssertTrue(profile.matches(vendorID: 0x0B05, productID: 0x19B6))
        XCTAssertFalse(profile.matches(vendorID: 0x0B05, productID: 0x1ACE))
        XCTAssertEqual(profile.minimumReportLength, 17)
    }

    /// 与真机可用的 macRogAuraCore 逐字节一致：Feature 通道、17 字节、不补齐、无 primers。
    /// （描述符里声明 63B，但 17 字节短包实测可被接受并生效；关键是不要 IOHIDDeviceOpen。）
    func testRogAuraCoreChannelKinds() throws {
        let profile = ProtocolLibrary.rogAuraCore()
        let spec = try XCTUnwrap(profile.frame(for: .keyboard))
        XCTAssertEqual(spec.channel.kind, .hidFeature)
        XCTAssertEqual(spec.channel.reportID, 0x5D)
        XCTAssertFalse(spec.padToMaxReportLength, "17 字节短包已验证有效，不做补齐")

        let brightness = try XCTUnwrap(spec.attached?.first)
        XCTAssertEqual(brightness.channel.kind, .hidFeature)
        XCTAssertEqual(brightness.channel.reportID, 0x5A)
        XCTAssertFalse(brightness.padToMaxReportLength)

        let commits = try XCTUnwrap(profile.commitFrames)
        XCTAssertTrue(commits.allSatisfy { $0.channel.kind == .hidFeature && $0.channel.reportID == 0x5D })
        XCTAssertFalse(commits.contains { $0.padToMaxReportLength })
        XCTAssertTrue((profile.initFrames?.count ?? 0) == 1, "必须先发 0x5A 握手帧（ASUS Tech.Inc.）")
    }

    /// 关灯（主色全黑）时双色标志应为 0xFF
    func testRogAuraCoreOffFlag() throws {
        let spec = try XCTUnwrap(ProtocolLibrary.rogAuraCore().frame(for: .keyboard))
        let frame = ZoneFrame(zone: .keyboard, mode: .off, primary: .off, secondary: .off,
                              brightness: 0, speed: 0, elapsed: 0)
        XCTAssertEqual(try FrameRenderer.render(frame, spec: spec)[8], 0xFF)
    }

    /// 灯条 / Logo 灯区：区码必须是 0x01 / 0x02，键盘保持 0x00。
    /// 这三个灯区会一起进同一批事务，区码写错就会互相覆盖（v0.15 的坑）。
    func testRogAuraCoreZoneCodes() throws {
        let profile = ProtocolLibrary.rogAuraCore()
        XCTAssertEqual(Set(profile.zones), Set([.keyboard, .lightBar, .logo]))

        let keyboard = try XCTUnwrap(profile.frame(for: .keyboard))
        let lightBar = try XCTUnwrap(profile.frame(for: .lightBar))
        let logo = try XCTUnwrap(profile.frame(for: .logo))

        XCTAssertEqual(keyboard.zoneCodes[AuraZone.keyboard.rawValue], 0x00)
        XCTAssertEqual(lightBar.zoneCodes[AuraZone.lightBar.rawValue], 0x01)
        XCTAssertEqual(logo.zoneCodes[AuraZone.logo.rawValue], 0x02)

        // 三个灯区共用同一套模板与模式码，只是 $zone 不同
        XCTAssertEqual(keyboard.template, lightBar.template)
        XCTAssertEqual(keyboard.template, logo.template)
        XCTAssertEqual(keyboard.channel, lightBar.channel)
        // 亮度帧只挂在键盘帧上，避免三个灯区各发一条互相覆盖
        XCTAssertNotNil(keyboard.attached)
        XCTAssertNil(lightBar.attached)
        XCTAssertNil(logo.attached)
    }

    /// 多灯区必须一次提交：默认实现按帧循环，HID 侧覆盖成单次 SET/APPLY。
    func testApplyBatchVisitsEveryFrame() throws {
        final class Recorder: AuraTransport {
            let kind: TransportKind = .simulated
            var logHandler: ((String) -> Void)?
            var seen: [AuraZone] = []
            func probe() throws -> DeviceInfo { .none }
            func apply(_ frame: ZoneFrame) throws {
                seen.append(frame.zone)
            }
            func close() {}
        }
        let recorder = Recorder()
        let frames = AuraZone.allCases.map {
            ZoneFrame(zone: $0, mode: .solid, primary: .sakura, secondary: .lilac,
                      brightness: 0.6, speed: 0.5, elapsed: 0)
        }
        try recorder.applyBatch(frames)
        XCTAssertEqual(recorder.seen, AuraZone.allCases)
    }
}
