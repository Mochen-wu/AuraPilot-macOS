// swift-tools-version:5.9
import PackageDescription

// AuraCore 是纯逻辑层：模型 / 灯效引擎 / 协议渲染 / 传输抽象 / 配置。
// 它不依赖 AppKit、SwiftUI，便于单测（swift test）。
// macOS App 目标在 project.yml（XcodeGen）里定义，依赖本包。
let package = Package(
    name: "AuraPilot",
    platforms: [.macOS(.v13)],
    products: [
        .library(name: "AuraCore", targets: ["AuraCore"]),
        .executable(name: "aura-probe", targets: ["AuraProbe"])
    ],
    targets: [
        .target(
            name: "AuraCore",
            path: "Sources/AuraCore",
            swiftSettings: [.define("AURACORE_SPM")]
        ),
        .executableTarget(
            name: "AuraProbe",
            dependencies: ["AuraCore"],
            path: "Sources/AuraProbe"
        ),
        .testTarget(
            name: "AuraCoreTests",
            dependencies: ["AuraCore"],
            path: "Tests/AuraCoreTests"
        )
    ],
    swiftLanguageVersions: [.v5]
)
