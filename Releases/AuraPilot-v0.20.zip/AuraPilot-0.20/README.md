# AuraPilot · 极光领航

macOS 原生的 ASUS 灯光控制台。粉色系界面，菜单栏常驻，后台是一套可替换传输层的灯效引擎。

> **先说结论**：G-Helper 无法"移植"到 macOS。它是 C#/WinForms，笔记本灯光全部走 ACPI-WMI，
> 而 XNU 没有这条栈。本项目的做法是**重写后台**，并把传输层做成可替换的：
> USB HID（原生可用）/ 远程桥（另一台机器代理 ACPI）/ 演示模式。
> 详细论证见 [`docs/01-可行性报告.md`](docs/01-可行性报告.md)。

---

## 当前状态

后台已完成，前台是可用的第一版。

| 模块 | 状态 | 说明 |
|---|---|---|
| 灯效引擎 | ✅ | 9 种模式（静态/呼吸/循环/彩虹/星光/流星雨/高光/激光/涟漪），30fps 软件渲染，确定性可测 |
| 协议包系统 | ✅ | JSON DSL（`$mode/$r/$g/$b/$brightness/$speed/$sum8`），改机型不用改代码 |
| HID 传输 | ✅ | IOHIDDevice 枚举 + Feature/Output 报告写入，支持裸报文校准 |
| 远程桥传输 | ✅ | HTTP JSON 客户端，供"Mac 控制另一台 ASUS 机器"使用 |
| 演示传输 | ✅ | 无硬件时全速跑通 UI 与引擎 |
| 传感器 | ✅ | AppleSMC 只读：CPU/GPU 温度、风扇转速；缺测显示"—" |
| 配置与预设 | ✅ | JSON 原子写入、损坏自愈、内置 5 套预设 + 自定义 |
| 状态栏 | ✅ | 实时温度、总开关、模式、颜色轮换、右键菜单 |
| 主窗口 | ✅ | 概览 / 灯效 / 预设 / 诊断 四页 |
| 界面主题 | ✅ | 跟随系统自动切换深色；日常色五套主题：樱花粉 / 浅粉 / 极简白 / 天青蓝 / 五彩缤纷，可持久化 |
| 风扇曲线 / 功耗模式 | ❌ | macOS 不可达，明确不做（见报告第 3 节） |
| AniMe Matrix | ❌ | 暂不支持 |

### 验证状态

| 部分 | 状态 |
|---|---|
| `AuraCore` 全模块 | 已用 Swift 5.10 编译通过 |
| 单元测试 | 56 个全部通过（渲染器 / 灯效 / 引擎 / 配置 / 协议库 / rogauracore / Falchion 报文） |
| `HIDTransport` / `SMCSensorReader` | 已用 IOKit 桩做类型检查通过（真机行为需实测） |
| 内置键盘协议包 | 已按 G-Helper `app/USB/Aura.cs` + macRogAuraCore 双向核对：灯效 Output / 亮度 Feature 补齐 64B / primers，报文布局有单测锁定 |
| App 层（SwiftUI / AppKit） | 语法解析通过，未在本机构建；需在 Xcode 里首次编译确认 |
| 真实硬件 | **未实测**，协议包常量需按机型校准 |

---

## 解压与确认版本

压缩包内顶层目录**带版本号**（`AuraPilot-0.20/`），解压后文件夹名就是版本号。

以前每版都叫 `AuraPilot/`，桌面上已有一份时 Finder 会另存为 `AuraPilot 2`、
`AuraPilot-0.6`，看着像两个工程，其实分不清哪个新。现在不会了。

```bash
# 顺手清掉桌面上所有旧副本（AuraPilot / AuraPilot 2 / AuraPilot-0.x 全删）
rm -rf ~/Desktop/AuraPilot ~/Desktop/"AuraPilot 2" ~/Desktop/AuraPilot-*

# 解压，得到 ~/Desktop/AuraPilot-0.20
# 用 ditto（macOS 自带）：参数少、命令行短，窄窗口下不容易折行
ditto -x -k ~/Downloads/AuraPilot-v0.20.zip ~/Desktop
# 备选（写成一整行）：unzip -o ~/Downloads/AuraPilot-v0.20.zip -d ~/Desktop
# 注意：终端窗口窄时 "-d ~/Desktop" 会折到下一行显示，那是屏幕折行，命令并没错。

cd ~/Desktop/AuraPilot-0.20/Core
swift build -c release
.build/release/aura-probe schedule    # 第一行应打印 aura-probe v0.20
```

三条版本确认：文件夹名带 `0.20` / `cat VERSION` 顶部 `v0.20` /
**前台启动日志第一行** `===== AuraPilot v0.20 (build 20) 启动 =====`。
`build-app.sh` 还会做源码指纹校验，跑错旧目录会直接报「源码指纹校验失败」而不是编译出一个假新版。

## 装不上 Homebrew 怎么办

两条都不用 brew 的路，任选：

**A. 直接编译出 .app（最快，不需要 Xcode 工程）**

```bash
cd ~/Desktop/AuraPilot-0.20
./scripts/build-app.sh          # 编译 + 组装 build/AuraPilot.app + 打开
```

根目录的 `Package.swift` 把 App 定义成 SwiftPM 可执行目标，只用系统自带的 `swift` 工具链。

**B. 用 Xcode 打开（XcodeGen 官方二进制，不走 brew）**

```bash
curl -L -o ~/Downloads/xcodegen.zip https://github.com/yonaskolb/XcodeGen/releases/latest/download/xcodegen.zip
unzip -q -o ~/Downloads/xcodegen.zip -d ~/bin
xattr -dr com.apple.quarantine ~/bin/xcodegen
export PATH="$HOME/bin/xcodegen/bin:$PATH"      # 想永久生效就写进 ~/.zshrc

cd ~/Desktop/AuraPilot-0.20 && xcodegen generate && open AuraPilot.xcodeproj
```

## 快速开始

```bash
# 0. 依赖
brew install xcodegen          # 生成 Xcode 工程
# Xcode 15+ / macOS 13+

# 1. 生成工程并打开
make project
open AuraPilot.xcodeproj

# 2. 直接跑单测（不依赖 Xcode 工程）
make test

# 3. 看看系统里有没有 ASUS HID 设备（会标注匹配的协议包）
make probe                  # 等价于 aura-probe devices
.build/release/aura-probe profiles   # 列出内置协议包

# 4. 读一次温度/风扇
make sensors

# 5. 内置键盘没反应时：穷举 5 种报文写法，看哪种能让灯变色
.build/release/aura-probe verify

# 6. 直接给内置键盘下发一帧（真机验证）
cd Core && swift build -c release
.build/release/aura-probe frame --profile mac-rogauracore-keyboard \
    --mode solid --color "#FF5C88" --bright 0.8
```

已实测：ROG 幻14（GA503）内置键盘的 Aura 控制接口为 `0x0B05:0x19B6`，产品名 `N-KEY Device`，
`aura-probe` 会自动选中该接口并匹配 `mac-rogauracore-keyboard` 协议包。

第一次启动会进**演示模式**（状态栏图标 + 粉色主界面），因为默认没有可用硬件。
这不会改动任何硬件，纯预览。

### 打包

```bash
make build      # xcodebuild Debug
make run        # 编译并启动
```

---

界面设计稿：

![界面设计稿](docs/ui-preview.png)

浏览器可直接打开 [`docs/ui-preview.html`](docs/ui-preview.html) 看交互细节。

## 目录

```
AuraPilot/
├─ Core/                  AuraCore Swift Package（Foundation + IOKit，无 UI）
│  ├─ Sources/AuraCore/   模型 / 引擎 / 协议 / 传输 / 传感器 / 控制器
│  ├─ Sources/AuraProbe/  命令行诊断与协议校准工具
│  └─ Tests/              渲染器、灯效、配置、协议库单测
├─ App/                   SwiftUI + AppKit 应用层
│  ├─ StatusBar/          状态栏项、弹出面板、右键菜单
│  ├─ UI/                 设计系统与四个页面
│  └─ Store/              Controller → SwiftUI 的桥
├─ Bundle/                Info.plist / entitlements
├─ docs/                  可行性报告、架构、硬件协议笔记、UI 设计稿
├─ project.yml            XcodeGen 工程定义
├─ scripts/               fetch-upstream.sh（拉取上游源码做协议对照）
└─ Makefile
```

---

## 灯效模式

| 模式 | 效果 | 用次色 |
|---|---|---|
| 静态 | 单色常亮 | |
| 呼吸 | smoothstep 缓动呼吸 | |
| 色彩循环 | 主色相沿色环推进 | |
| 彩虹 | 全区色相流动 | |
| 星光 | 随机点亮 + 衰减 | ✓ |
| 流星雨 | 亮度波扫过 | ✓ |
| 高光扫过 | 窄亮带 + 底色 | ✓ |
| 激光 | 极窄光束快速往返 | ✓ |
| 涟漪 | 双脉冲扩散 | ✓ |

所有模式都是纯函数 `(mode, 颜色, 速度, 相位, 时间) → RGB`，
所以能做实时预览、能单测、也不依赖设备固件能力。

---

## 白天调灯效「没反应」？先看自动开关

自动开关默认 **18:00 点亮 / 次日 07:00 熄灭**，白天把亮度压到 **0%**。
v0.17 及以前，这时改颜色 / 模式 / 预设其实都写进配置了，只是灯始终不亮，
看起来就像「灯效界面所有按钮都不可用」——按钮并没坏。

v0.18 起规则改为**手动优先**：

| 你做的事 | 结果 |
|---|---|
| 改颜色 / 模式 / 亮度 / 预设 / 总开关 | 自动开关暂时让位，灯立刻按你的设置变化 |
| 点灯效页顶部橙色横幅的「立即点亮」 | 一步到位开灯（总开关 + 灯区 + 亮度） |
| 点「恢复自动」 | 立刻交回自动开关并重新判定 |
| 什么都不做 | 到下一个时间点（18:00 / 07:00）自动开关重新接管 |

诊断页「自动开关灯光」卡片里可随时关掉这个策略、改时间段或改成跟随深色模式。
手动接管期间，灯效页与状态栏都会显示「手动控制中 · HH:mm 后重新接管」。

---

## 接真机

### 外置 ROG 键盘 / 鼠标（USB HID）

```bash
make probe
# • ROG STRIX SCOPE II [0x0B05:0x1A1B] usage=0xFF00/0x02 feature=64B
```

拿到接口后，按 `docs/03-硬件协议笔记.md` 第 2 节校准报文，
把协议包丢进 `~/Library/Application Support/AuraPilot/protocols/` 即可，不用重新编译。

### 笔记本内置键盘（rogauracore 协议，已内置）

部分 ROG 笔记本把内置键盘的 Aura 控制器暴露成 USB HID 接口，
macOS 可以直接驱动——已按 [`macRogAuraCore`](https://github.com/black-dragon74/macRogAuraCore)
源码逐字节核对并内置为协议包 `mac-rogauracore-keyboard`（17 字节 feature report，
支持 静态 / 双色呼吸 / 色彩循环 + 4 档亮度）。

已知可用 PID：`0x1854`(GL553/GL753)、`0x1869`(GL503/FX503/GL703)、`0x1866`(GL504/GL703/GX501/GM501)、
`0x19B6`(GA503)。**先跑 `make probe`**：

- 列表里出现上述 PID → 直接可用，软件动态灯效（彩虹/涟漪等）由引擎逐帧下发；
- 出现其它 `0x0B05:xxxx` 接口 → 把 PID 加进协议包 `productIDs` 试一次（JSON 在
  `~/Library/Application Support/AuraPilot/protocols/`，不用重编译）；
- 什么都没有 → 该机型内置灯走 ACPI-WMI，回退到下面的远程桥方案。

### 笔记本灯条 / Logo 灯（远程桥）

需要一台能跑 ACPI-WMI 的机器做 agent（Windows 或 Linux），
Mac 端在 `config.json` 里打开 `settings.bridge`：

```json
"bridge": { "isEnabled": true, "baseURL": "http://192.168.1.20:8712", "token": null, "timeout": 2.0 }
```

接口只有两个：`GET /v1/aura/info`、`POST /v1/aura/frame`，详见协议笔记第 4 节。

---

## 设计取舍

- **不仿 Windows 界面**：状态栏是主入口，主窗口是单页四标签，符合 macOS 习惯；
- **粉色是品牌色，不是满屏粉**：`#FF4F87` 做主色，浅色底 `#FFF8FA`，深色自动降饱和；
- **不确定就不显示**：传感器读不到就显示"—"，不会编造数字；
- **假功能不如没有**：风扇曲线、功耗模式直接标注不支持，不做"点了没反应"的按钮；
- **协议包外置**：真机适配是数据问题，不是代码问题。

---

## 路线图

1. **协议校准**：接入一台真实 ROG 键盘，把 `generic-hid-aura` 的偏移量落成可用包；
2. **逐键渲染**：`perKey` 能力已预留，需要键盘布局表 + 批量帧；
3. **远程桥 agent**：Windows 侧 30 行 C# 封装 `AsusACPI.DeviceSet`；
4. **AniMe Matrix**：USB 协议 + 帧缓冲，工作量大，单独立项；
5. **开机自启**：`SMAppService` 注册登录项。

---

## 免责声明

"ASUS"、"ROG"、"TUF"、"Armoury Crate" 均为华硕电脑股份有限公司的商标。
本项目为个人非官方工具，与华硕无任何关联，仅出于互操作目的使用公开协议信息。
修改灯光/风扇设置存在影响硬件的风险，请自行评估。
