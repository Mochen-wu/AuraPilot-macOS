import AppKit

@main
enum AuraPilotApp {
    /// NSApplication.delegate 是弱引用，这里必须强持有
    private static var appDelegate: AppDelegate?

    static func main() {
        // stdout 非 TTY 时是全缓冲，[AuraPilot] 诊断日志会滞留看不到；
        // 改成行缓冲，重定向到文件也能逐行实时刷出
        setvbuf(stdout, nil, _IOLBF, 8192)

        let application = NSApplication.shared
        let delegate = AppDelegate()
        appDelegate = delegate
        application.delegate = delegate
        // 菜单栏常驻，不占 Dock；打开主窗口时会临时切回 .regular
        application.setActivationPolicy(.accessory)
        application.run()
    }
}
