import AppKit
import SwiftUI
import IOKit.ps
import AuraCore

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    /// 编译进二进制的版本号。贴日志时第一行就能确认跑的是哪个包，
    /// 不再靠目录名 / VERSION 文件去猜（之前多次踩「解压没成功、跑的是残留目录」）。
    private static let buildVersion = "0.20"

    private var store: AuraStore!
    private var statusBar: StatusBarController?
    private var window: NSWindow?
    private var workspaceTokens: [NSObjectProtocol] = []
    private var batteryTimer: Timer?

    func applicationDidFinishLaunching(_ notification: Notification) {
        print("[AuraPilot] ===== AuraPilot v\(Self.buildVersion) (build 20) 启动 =====")
        store = AuraStore()
        let s = store.snapshot
        print("[AuraPilot] store 就绪")
        print("[AuraPilot] 配置：自动开关=\(s.settings.autoLighting.isEnabled ? "开" : "关") 触发=\(s.settings.autoLighting.trigger.displayName)"
              + " | 设备=\(s.device.name) 灯区=\(s.device.capabilities.zones.count) 亮度档=\(s.device.capabilities.brightnessSteps)"
              + " | 总开关=\(s.state.isOn ? "开" : "关")")

        statusBar = StatusBarController(
            store: store,
            onOpenWindow: { [weak self] in
                self?.showMainWindow()
            },
            onQuit: {
                NSApp.terminate(nil)
            }
        )

        // 顺序很关键：先判定"现在该不该亮"，再启动引擎。
        // 这样开机第一帧就是正确亮度，不会先亮一下再被熄灭。
        store.autoLightingScheduler.start()
        print("[AuraPilot] 自动开关判定完成")

        store.controller.start()
        print("[AuraPilot] 灯效引擎已启动")
        observeSleepWake()
        startBatteryMonitoring()
        print("[AuraPilot] 启动完成")
    }

    func applicationWillTerminate(_ notification: Notification) {
        batteryTimer?.invalidate()
        store?.autoLightingScheduler.stop()
        store?.controller.stop(turnOffLights: false)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag {
            showMainWindow()
        }
        return true
    }

    // MARK: - 主窗口

    func showMainWindow() {
        if window == nil {
            let hosting = NSHostingController(rootView: MainWindowView(store: store))
            let created = NSWindow(contentViewController: hosting)
            created.title = "AuraPilot"
            created.titleVisibility = .hidden
            created.titlebarAppearsTransparent = true
            created.styleMask = [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView]
            created.setContentSize(NSSize(width: 1060, height: 720))
            created.minSize = NSSize(width: 960, height: 660)
            created.center()
            created.isReleasedWhenClosed = false
            created.delegate = self
            created.backgroundColor = NSColor(hex: "#FFF8FA")
            window = created
        }

        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
        window?.makeKeyAndOrderFront(nil)
    }

    func windowWillClose(_ notification: Notification) {
        // 关掉主窗口就回到"纯状态栏"形态
        NSApp.setActivationPolicy(.accessory)
    }

    // MARK: - 系统事件

    private func observeSleepWake() {
        let center = NSWorkspace.shared.notificationCenter
        workspaceTokens.append(
            center.addObserver(forName: NSWorkspace.willSleepNotification, object: nil, queue: .main) { [weak self] _ in
                // 关闭灯光但不改用户配置；WMI 机型的睡眠灭灯由 EC 固件负责，
                // 这里只处理 HID 键盘（rogauracore 等）。
                self?.store?.controller.handleSystemSleep()
            }
        )
        workspaceTokens.append(
            center.addObserver(forName: NSWorkspace.didWakeNotification, object: nil, queue: .main) { [weak self] _ in
                self?.store?.controller.handleSystemWake()
                self?.applyBatteryPolicy()
                self?.store?.controller.refreshSensors()
                // 睡眠期间可能跨过了 18:00 / 07:00，唤醒后重新判定
                self?.store?.autoLightingScheduler.evaluate(force: true)
            }
        )
        // 用户显式注销/关机时也把灯关掉，下次开机由 initFrames 握手恢复
        workspaceTokens.append(
            center.addObserver(forName: NSWorkspace.sessionDidResignActiveNotification, object: nil, queue: .main) { [weak self] _ in
                self?.store?.controller.handleSystemSleep()
            }
        )
    }

    /// 60 秒检查一次电源状态，落实"电池供电时暂停动画"
    private func startBatteryMonitoring() {
        batteryTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            self?.applyBatteryPolicy()
        }
        applyBatteryPolicy()
    }

    private func applyBatteryPolicy() {
        guard let store else { return }
        let shouldPause = store.settings.pauseAnimationOnBattery && isRunningOnBattery()
        store.controller.setPaused(shouldPause)
    }

    private func isRunningOnBattery() -> Bool {
        guard let info = IOPSCopyPowerSourcesInfo()?.takeRetainedValue() else { return false }
        guard let list = IOPSCopyPowerSourcesList(info)?.takeRetainedValue() as? [AnyObject] else { return false }
        for source in list {
            guard let raw = IOPSGetPowerSourceDescription(info, source) else { continue }
            guard let description = raw.takeUnretainedValue() as? [String: Any] else { continue }
            // "Power Source State" / "Battery Power" 即 kIOPSPowerSourceStateKey / kIOPSBatteryPowerValue 的字符串值
            if let state = description["Power Source State"] as? String, state == "Battery Power" {
                return true
            }
        }
        return false
    }
}
