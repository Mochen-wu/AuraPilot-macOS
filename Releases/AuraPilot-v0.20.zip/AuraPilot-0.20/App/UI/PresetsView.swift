import SwiftUI
import AuraCore

struct PresetsView: View {
    @ObservedObject var store: AuraStore
    @State private var isNamingPreset = false
    @State private var draftName = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), spacing: 14)], spacing: 14) {
                    ForEach(store.presets) { preset in
                        presetCard(preset)
                    }
                }
            }
            .padding(26)
        }
        .sheet(isPresented: $isNamingPreset) {
            namingSheet
        }
    }

    private var header: some View {
        HStack(alignment: .top) {
            SectionHeader(title: "灯效预设", subtitle: "内置预设 + 你自己的配色方案，一键整套切换")
            Spacer()
            Button {
                draftName = "我的配色"
                isNamingPreset = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "plus")
                        .font(.system(size: 11, weight: .bold))
                    Text("保存当前配置")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(Capsule().fill(Palette.accent))
            }
            .buttonStyle(.plain)
        }
    }

    private func presetCard(_ preset: Preset) -> some View {
        let colors = preset.previewColors
        let isActive = store.state.activePresetID == preset.id

        return VStack(alignment: .leading, spacing: 11) {
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: colors.map { $0.swiftUI },
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(height: 84)

                HStack(spacing: 4) {
                    ForEach(0..<6, id: \.self) { index in
                        RoundedRectangle(cornerRadius: 2)
                            .fill(Color.white.opacity(0.14 + Double(index % 3) * 0.08))
                            .frame(width: 12, height: 16)
                    }
                }
                .padding(12)

                if isActive {
                    Chip(text: "使用中", tint: .white, filled: true)
                        .padding(9)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
            }

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(preset.name)
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(Palette.ink)
                    if preset.isBuiltIn {
                        Chip(text: "内置", tint: Palette.muted)
                    }
                }
                Text(summary(preset))
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.muted)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(spacing: 8) {
                Button {
                    store.applyPreset(preset)
                } label: {
                    Text("应用")
                        .font(.system(size: 11.5, weight: .semibold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 7)
                        .background(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(isActive ? Palette.accentSoft : Palette.surfaceAlt)
                        )
                        .foregroundStyle(isActive ? Palette.accentDeep : Palette.ink.opacity(0.75))
                }
                .buttonStyle(.plain)

                if !preset.isBuiltIn {
                    Button {
                        store.deletePreset(preset)
                    } label: {
                        Image(systemName: "trash")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(Palette.muted)
                            .frame(width: 28, height: 26)
                            .background(
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(Palette.surfaceAlt)
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .card(padding: 13, radius: 16)
    }

    private func summary(_ preset: Preset) -> String {
        let keyboard = preset.state[.keyboard]
        let lightBar = preset.state[.lightBar]
        return "键盘 \(keyboard.mode.displayName) · 灯条 \(lightBar.mode.displayName)"
    }

    private var namingSheet: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("保存为预设")
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .foregroundStyle(Palette.ink)

            TextField("预设名称", text: $draftName)
                .textFieldStyle(.plain)
                .font(.system(size: 13))
                .padding(10)
                .background(
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(Palette.surfaceAlt)
                )

            HStack {
                Spacer()
                Button("取消") { isNamingPreset = false }
                    .buttonStyle(.plain)
                    .font(.system(size: 12))
                    .foregroundStyle(Palette.muted)
                Button {
                    store.savePreset(named: draftName.trimmingCharacters(in: .whitespacesAndNewlines))
                    isNamingPreset = false
                } label: {
                    Text("保存")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 7)
                        .background(Capsule().fill(Palette.accent))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(22)
        .frame(width: 340)
        .background(Palette.surface)
    }
}
