import SwiftUI
import AuraCore

struct DiagnosticsView: View {
    @ObservedObject var store: AuraStore

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                deviceCard
                devicePickerCard
                transportCard
                autoLightingCard
                powerBehaviorCard
                sensorCard
                logCard
            }
            .padding(26)
        }
    }

    /// 按时间 / 深色模式自动开关灯光。
    /// 实现方式是给亮度乘一个系数（0 = 熄灭），不改用户保存的灯效配置，
    /// 所以晚上到点后能原样恢复，不会把配色改乱。
    private var autoLightingCard: some View {
        let config = store.autoLighting
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "自动开关灯光", subtitle: "时间 / 深色模式")
                Spacer()
                Chip(
                    text: config.isEnabled ? (store.isAutoDimmed ? "当前已熄灭" : "当前点亮") : "未启用",
                    tint: config.isEnabled
                        ? (store.isAutoDimmed ? Palette.warning : Palette.positive)
                        : Palette.muted
                )
            }

            Toggle(
                isOn: Binding(
                    get: { config.isEnabled },
                    set: { on in store.updateAutoLighting { $0.isEnabled = on } }
                )
            ) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("启用自动开关").font(.system(size: 12.5, weight: .medium))
                    Text("白天自动把亮度压到设定值，晚上自动恢复；每次启动都重新判定")
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                }
            }
            .toggleStyle(.switch)
            .tint(Palette.accent)

            if config.isEnabled {
                Picker(
                    "",
                    selection: Binding(
                        get: { config.trigger },
                        set: { value in store.updateAutoLighting { $0.trigger = value } }
                    )
                ) {
                    ForEach(AutoLightingTrigger.allCases, id: \.self) { trigger in
                        Text(trigger.displayName).tag(trigger)
                    }
                }
                .pickerStyle(.segmented)
                .labelsHidden()

                Text(config.trigger.detail)
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.muted)

                if config.trigger != .darkMode {
                    HStack(spacing: 16) {
                        timeField(title: "点亮", hour: config.startHour, minute: config.startMinute) { h, m in
                            store.updateAutoLighting {
                                $0.startHour = h
                                $0.startMinute = m
                            }
                        }
                        timeField(title: "熄灭", hour: config.endHour, minute: config.endMinute) { h, m in
                            store.updateAutoLighting {
                                $0.endHour = h
                                $0.endMinute = m
                            }
                        }
                        Spacer()
                        Text(config.windowDescription)
                            .font(.system(size: 10.5, design: .monospaced))
                            .foregroundStyle(Palette.muted)
                    }
                }

                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("非点亮时段亮度")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(Palette.muted)
                        Spacer()
                        Text(levelText(config.daytimeLevel))
                            .font(.system(size: 11, weight: .semibold, design: .rounded))
                            .foregroundStyle(Palette.accentDeep)
                    }
                    Slider(
                        value: Binding(
                            get: { config.daytimeLevel },
                            set: { value in store.updateAutoLighting { $0.daytimeLevel = value } }
                        ),
                        in: 0...1
                    )
                    .tint(Palette.accent)
                    Text("0% = 完全熄灭（推荐，白天键盘灯本来也看不出效果）")
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.muted)
                }

                HStack(spacing: 6) {
                    Circle()
                        .fill(store.isAutoDimmed ? Palette.warning : Palette.positive)
                        .frame(width: 6, height: 6)
                    Text(store.autoNote ?? "等待判定…")
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            if store.isManualOverride {
                HStack(spacing: 8) {
                    Image(systemName: "hand.tap.fill")
                        .font(.system(size: 10))
                        .foregroundStyle(Palette.positive)
                    Text(store.manualOverrideText)
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer()
                    Button("恢复自动") { store.resumeAutoLighting() }
                        .buttonStyle(.plain)
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundStyle(Palette.accentDeep)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Capsule().fill(Palette.accentSoft))
                }
                .padding(10)
                .background(
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(Palette.positive.opacity(0.08))
                )
            }

            Text("手动调节任意灯效（颜色 / 模式 / 亮度 / 预设）后，自动开关会暂时让位，到下一个时间点自动恢复；也可以点「恢复自动」立刻交回。开机时先判定再点亮，白天启动不会闪一下。系统睡眠唤醒、跨过时间点、切换深色模式时都会重新判定。")
                .font(.system(size: 10.5))
                .foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .card()
    }

    private func timeField(
        title: String,
        hour: Int,
        minute: Int,
        onChange: @escaping (Int, Int) -> Void
    ) -> some View {
        let binding = Binding<Date>(
            get: {
                Calendar.current.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) ?? Date()
            },
            set: { newValue in
                let parts = Calendar.current.dateComponents([.hour, .minute], from: newValue)
                onChange(parts.hour ?? hour, parts.minute ?? minute)
            }
        )
        return HStack(spacing: 6) {
            Text(title)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(Palette.muted)
            DatePicker("", selection: binding, displayedComponents: .hourAndMinute)
                .labelsHidden()
                .datePickerStyle(.stepperField)
        }
    }

    private func levelText(_ level: Double) -> String {
        let percent = Int((level * 100).rounded())
        return percent == 0 ? "熄灭" : "\(percent)%"
    }

    /// 对应 G-Helper 的"灯光在 唤醒/睡眠/电池时"行为。
    /// 注意：WMI 机型的 开机/关机/睡眠 行为写在 EC 固件里（TUF_KB_STATE 0x00100057），
    /// 由固件执行，本页只控制 macOS 侧（HID 键盘）的行为。
    private var powerBehaviorCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "电源行为", subtitle: "睡眠 / 唤醒 / 电池")

            Toggle(
                isOn: Binding(
                    get: { store.settings.turnOffOnSleep },
                    set: { value in store.updateSettings { $0.turnOffOnSleep = value } }
                )
            ) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("睡眠时关闭灯光").font(.system(size: 12.5, weight: .medium))
                    Text("合盖或系统睡眠时下发熄灯帧，不改保存的灯效配置")
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                }
            }
            .toggleStyle(.switch)
            .tint(Palette.accent)

            Toggle(
                isOn: Binding(
                    get: { store.settings.restoreOnWake },
                    set: { value in store.updateSettings { $0.restoreOnWake = value } }
                )
            ) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("唤醒后恢复灯光").font(.system(size: 12.5, weight: .medium))
                    Text("重新下发睡眠前的灯效状态")
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                }
            }
            .toggleStyle(.switch)
            .tint(Palette.accent)

            Toggle(
                isOn: Binding(
                    get: { store.settings.pauseAnimationOnBattery },
                    set: { value in store.updateSettings { $0.pauseAnimationOnBattery = value } }
                )
            ) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("电池供电时暂停动态灯效").font(.system(size: 12.5, weight: .medium))
                    Text("静态颜色保持不变，停止逐帧动画以省电")
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                }
            }
            .toggleStyle(.switch)
            .tint(Palette.accent)

            Text("开机/关机时的灯光行为在 WMI 机型上由 EC 固件管理（Windows 下用 G-Helper 设置一次即可，跨系统生效）；HID 键盘在连接时会发送初始化握手帧。")
                .font(.system(size: 10.5))
                .foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .card()
    }

    /// 设备选择：一台机器上可能同时挂着内置键盘与外接 ROG 键盘，
    /// 自动打分偶尔会挑到外接那只的键盘输入口（发帧不报错但灯不动），
    /// 这里让用户手动锁定到真正能控灯的接口。
    private var devicePickerCard: some View {
        let current = store.preferredDeviceID
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "输出设备", subtitle: "多只 ROG 设备时手动锁定")
                Spacer()
                if store.isSwitchingDevice || store.isScanningDevices {
                    ProgressView().controlSize(.small)
                }
                Button("重新扫描") {
                    store.refreshDeviceCandidates()
                }
                .buttonStyle(.plain)
                .disabled(store.isScanningDevices)
            }

            Picker(
                "",
                selection: Binding(
                    get: { current ?? "" },
                    set: { value in store.selectDevice(value.isEmpty ? nil : value) }
                )
            ) {
                Text("自动选择（推荐）").tag("")
                ForEach(store.deviceCandidates) { candidate in
                    Text(candidate.menuTitle).tag(candidate.id)
                }
            }
            .pickerStyle(.menu)
            .labelsHidden()
            .disabled(store.isSwitchingDevice)

            if store.deviceCandidates.isEmpty {
                Text(store.isScanningDevices ? "扫描中…" : "没有扫描到 ASUS HID 接口，点「重新扫描」")
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.muted)
            } else if let candidate = store.deviceCandidates.first(where: { $0.id == current }) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(candidate.subtitle)
                        .font(.system(size: 10.5, design: .monospaced))
                        .foregroundStyle(Palette.muted)
                    if let note = candidate.note {
                        Text(note)
                            .font(.system(size: 10.5))
                            .foregroundStyle(candidate.canControl ? Palette.muted : Palette.warning)
                    }
                }
            } else if current != nil {
                Text("你选定的接口当前不在线（可能拔掉了或被休眠重置），已回退自动选择。")
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.warning)
            }

            HStack(spacing: 6) {
                Text("当前：")
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.muted)
                Text(store.device.name)
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(Palette.ink.opacity(0.85))
                Text("· \(store.device.kind.displayName)")
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.muted)
                Spacer()
            }
        }
        .card()
        .onAppear {
            if store.deviceCandidates.isEmpty {
                store.refreshDeviceCandidates()
            }
        }
    }

    private var deviceCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "设备", subtitle: store.device.vendor)
                Spacer()
                Chip(text: store.device.kind.displayName, tint: store.isConnected ? Palette.positive : Palette.warning)
            }

            VStack(spacing: 0) {
                row("名称", store.device.name)
                row("通道", store.device.kind.displayName)
                row("标识", store.device.id)
                row("序列号", store.device.serial ?? "—")
                row("灯区", store.device.capabilities.zones.map { $0.displayName }.sorted().joined(separator: " / "))
                row("支持模式", "\(store.device.capabilities.modes.count) 种")
                row("逐键寻址", store.device.capabilities.perKey ? "支持" : "不支持")
                if let note = store.device.note {
                    row("备注", note)
                }
            }
        }
        .card()
    }

    private var transportCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "连接探测记录", subtitle: "按 HID → 远程桥 → 演示的顺序尝试")
            VStack(alignment: .leading, spacing: 6) {
                ForEach(store.snapshot.attempts.indices, id: \.self) { index in
                    HStack(alignment: .top, spacing: 6) {
                        Text("•").foregroundStyle(Palette.accent)
                        Text(store.snapshot.attempts[index])
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(Palette.ink.opacity(0.8))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                if store.snapshot.attempts.isEmpty {
                    Text("—").font(.system(size: 11)).foregroundStyle(Palette.muted)
                }
            }

            if let error = store.snapshot.lastError {
                Text(error)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(Palette.danger)
                    .padding(9)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Palette.danger.opacity(0.08))
                    )
            }
        }
        .card()
    }

    private var sensorCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "传感器", subtitle: store.sensors.source)
                Spacer()
                Button("刷新") {
                    store.refreshSensors()
                }
                .buttonStyle(.plain)
                .font(.system(size: 11.5, weight: .semibold))
                .foregroundStyle(Palette.accentDeep)
            }

            VStack(spacing: 0) {
                row("CPU", store.sensors.cpuTemperature.map { String(format: "%.1f ℃", $0) } ?? "不可用")
                row("GPU", store.sensors.gpuTemperature.map { String(format: "%.1f ℃", $0) } ?? "不可用")
                row("风扇", store.sensors.fans.isEmpty
                    ? "不可用（macOS 未暴露）"
                    : store.sensors.fans.map { "\($0.name) \($0.rpm) rpm" }.joined(separator: " · "))
                row("命中键", store.sensors.probedKeys.isEmpty ? "—" : store.sensors.probedKeys.joined(separator: ", "))
            }

            Text("风扇转速为只读。写入风扇曲线需要 root 与 EC 直通，ASUS 笔记本在 macOS 下不可达，因此本项目不提供该功能。")
                .font(.system(size: 10.5))
                .foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .card()
    }

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "运行日志", subtitle: "最近 \(min(store.snapshot.log.count, 60)) 条")
            VStack(alignment: .leading, spacing: 4) {
                ForEach(store.snapshot.log.suffix(60).reversed()) { entry in
                    HStack(alignment: .top, spacing: 8) {
                        Text(entry.date, format: .dateTime.hour().minute().second())
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundStyle(Palette.muted)
                        Text(entry.message)
                            .font(.system(size: 10.5, design: .monospaced))
                            .foregroundStyle(color(for: entry.level))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                if store.snapshot.log.isEmpty {
                    Text("暂无日志").font(.system(size: 11)).foregroundStyle(Palette.muted)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .card()
    }

    private func color(for level: LogEntry.Level) -> Color {
        switch level {
        case .info: return Palette.ink.opacity(0.8)
        case .warning: return Palette.warning
        case .error: return Palette.danger
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(Palette.muted)
                .frame(width: 64, alignment: .leading)
            Text(value)
                .font(.system(size: 11.5))
                .foregroundStyle(Palette.ink.opacity(0.85))
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(.vertical, 6)
    }
}
