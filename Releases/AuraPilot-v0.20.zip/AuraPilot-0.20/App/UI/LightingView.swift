import SwiftUI
import AuraCore

struct LightingView: View {
    @ObservedObject var store: AuraStore
    @State private var origin = Date()

    private var zone: AuraZone { store.selectedZone }
    private var zoneState: ZoneState { store.zone(zone) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                autoLightingBanner
                zonePicker
                preview
                modeGrid
                colorSection
                sliderSection
            }
            .padding(26)
        }
    }

    // MARK: - 自动开关状态横幅
    //
    // v0.17 的痛点：自动开关白天把亮度压到 0，用户改颜色/模式/预设时配置确实
    // 写进去了，但灯一点不亮，看起来像「所有按钮都不可用」。这里把状态明说，
    // 并给两个一键出口：立即点亮（手动接管）/ 恢复自动。

    @ViewBuilder
    private var autoLightingBanner: some View {
        if store.isAutoDimmed {
            banner(
                symbol: "moon.zzz.fill",
                title: "自动开关当前把灯熄灭了",
                detail: "白天 / 浅色模式下亮度被压到 0%，所以改颜色、模式、预设都看不到效果。这不是按钮坏了。点「立即点亮」就能手动控制，到下一个时间点自动开关会重新接管。",
                tint: Palette.warning,
                showRestore: true
            )
        } else if store.isManualOverride {
            banner(
                symbol: "hand.tap.fill",
                title: "手动控制中",
                detail: store.manualOverrideText + "。现在改任何颜色 / 模式 / 亮度都会立刻作用到键盘。",
                tint: Palette.positive,
                showRestore: true
            )
        }
    }

    private func banner(
        symbol: String,
        title: String,
        detail: String,
        tint: Color,
        showRestore: Bool
    ) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: 22)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 12.5, weight: .semibold, design: .rounded))
                    .foregroundStyle(Palette.ink)
                Text(detail)
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 8)

            VStack(spacing: 6) {
                Button("立即点亮") { store.turnOnNow() }
                    .buttonStyle(.plain)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Palette.accent))
                if showRestore {
                    Button("恢复自动") { store.resumeAutoLighting() }
                        .buttonStyle(.plain)
                        .font(.system(size: 10.5))
                        .foregroundStyle(Palette.muted)
                }
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(tint.opacity(0.09))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(tint.opacity(0.32), lineWidth: 1)
        )
    }

    // MARK: - 分区选择

    private var zonePicker: some View {
        HStack(spacing: 10) {
            ForEach(AuraZone.allCases) { item in
                let supported = store.device.capabilities.supports(item)
                Button {
                    withAnimation(.easeInOut(duration: 0.15)) { store.selectedZone = item }
                } label: {
                    HStack(spacing: 7) {
                        Circle()
                            .fill(store.zone(item).primary.swiftUI)
                            .frame(width: 7, height: 7)
                        Text(item.displayName)
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(store.selectedZone == item ? Color.white : Palette.ink.opacity(0.75))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(
                        Capsule().fill(store.selectedZone == item ? Palette.accent : Palette.surface)
                    )
                    .overlay(
                        Capsule().strokeBorder(store.selectedZone == item ? Color.clear : Palette.hairline, lineWidth: 1)
                    )
                }
                .buttonStyle(.plain)
                .disabled(!supported)
                .opacity(supported ? 1 : 0.4)
            }
            Spacer()
            if !store.device.capabilities.supports(zone) {
                Chip(text: "该设备无此灯区", tint: Palette.warning)
            }
        }
    }

    // MARK: - 实时预览

    private var preview: some View {
        // 自动熄灭时预览也跟着暗下来，避免"界面看着亮、键盘却是灭的"这种误导
        let isOn = store.state.isOn
            && !store.isAutoDimmed
            && zoneState.isEnabled
            && zoneState.mode != .off

        return Group {
            if isOn && zoneState.mode.isAnimated {
                // 只有动画模式才跑时间轴。静态模式若也挂 30fps TimelineView，
                // 整页会持续重绘，点按反馈变迟钝，看起来像"按钮没反应"。
                TimelineView(.animation(minimumInterval: 1.0 / 15.0)) { timeline in
                    previewBox(isOn: true, elapsed: timeline.date.timeIntervalSince(origin))
                }
            } else {
                previewBox(isOn: isOn, elapsed: 0)
            }
        }
    }

    private func previewBox(isOn: Bool, elapsed: TimeInterval) -> some View {
        let color = Effects.color(
            mode: zoneState.mode,
            primary: zoneState.primary,
            secondary: zoneState.secondary,
            speed: zoneState.speed,
            phase: LightingEngine.phase(for: zone),
            time: elapsed
        )

        return ZStack {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(Color(light: "#1C1218", dark: "#0B0709"))

            if isOn {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(color.swiftUI)
                    .opacity(0.5 * zoneState.brightness + 0.12)
                    .blur(radius: 26)
                    .padding(10)
            }

            HStack(spacing: 5) {
                ForEach(0..<14, id: \.self) { index in
                    let keyColor = isOn
                        ? Effects.color(
                            mode: zoneState.mode,
                            primary: zoneState.primary,
                            secondary: zoneState.secondary,
                            speed: zoneState.speed,
                            phase: LightingEngine.phase(for: zone) + Double(index) * 0.045,
                            time: elapsed
                        )
                        : AuraCore.RGBColor(white: 0.14)
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(keyColor.swiftUI.opacity(isOn ? 0.25 + 0.75 * zoneState.brightness : 1))
                        .frame(width: 26, height: 34)
                        .overlay(
                            RoundedRectangle(cornerRadius: 4, style: .continuous)
                                .strokeBorder(Color.white.opacity(0.08), lineWidth: 0.8)
                        )
                }
            }
            .padding(.horizontal, 18)

            VStack {
                HStack {
                    Chip(text: isOn ? zoneState.mode.displayName : "关闭", tint: .white, filled: true)
                    Spacer()
                    Text(zoneState.primary.hexString.uppercased())
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.55))
                }
                Spacer()
            }
            .padding(14)
        }
        .frame(height: 132)
    }

    // MARK: - 模式

    private var modeGrid: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(
                title: "灯效模式",
                subtitle: store.device.capabilities.hardwareEffects
                    ? "动画由设备固件运行，App 只下发一次模式与颜色"
                    : "动画在 App 内逐帧计算，设备只负责显示颜色"
            )
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 10)], spacing: 10) {
                ForEach(AuraMode.allCases) { mode in
                    modeChip(mode)
                }
            }
            // 把固件能力边界写在界面上，避免把「点了没反应」误判成 App 坏了
            Text(modeNote)
                .font(.system(size: 10.5))
                .foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .card()
    }

    private var modeNote: String {
        let names = AuraMode.allCases
            .filter { store.device.capabilities.modes.contains($0) }
            .map { $0.displayName }
            .joined(separator: " / ")
        return "本机协议包只定义了：\(names)。其余模式没有对应模式码，已禁用。"
            + "N-KEY（0x19B6）固件实测通常只有「静态」真正生效；"
            + "呼吸 / 色彩循环若点了不变化，是固件未实现，不是 App 故障。"
    }

    private func modeChip(_ mode: AuraMode) -> some View {
        let isSelected = zoneState.mode == mode
        let available = store.device.capabilities.modes.contains(mode)
        return Button {
            withAnimation(.easeInOut(duration: 0.15)) {
                store.setMode(mode, zone: zone)
            }
        } label: {
            VStack(spacing: 6) {
                Image(systemName: symbol(for: mode))
                    .font(.system(size: 15, weight: .medium))
                Text(mode.displayName)
                    .font(.system(size: 10.5, weight: isSelected ? .semibold : .regular))
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 11)
            .foregroundStyle(isSelected ? Palette.accentDeep : Palette.ink.opacity(0.7))
            .background(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(isSelected ? Palette.accentSoft : Palette.surfaceAlt)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(isSelected ? Palette.accent.opacity(0.5) : Color.clear, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        // 不支持的模式必须真正禁用：旧版只降透明度，仍能点击，
        // 于是发一帧「静态码 + 非零速度」被固件丢弃，看起来就是「点了没反应」。
        .disabled(!available)
        .opacity(available ? 1 : 0.35)
        .help(available ? mode.displayName : "本协议包没有该模式码，已禁用")
    }

    private func symbol(for mode: AuraMode) -> String {
        switch mode {
        case .off: return "power"
        case .solid: return "circle.fill"
        case .breathe: return "wind"
        case .cycle: return "arrow.triangle.2.circlepath"
        case .rainbow: return "rainbow"
        case .star: return "sparkles"
        case .rain: return "cloud.rain"
        case .highlight: return "sun.max"
        case .laser: return "bolt.fill"
        case .ripple: return "water.waves"
        }
    }

    // MARK: - 颜色

    private var colorSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                SectionHeader(title: "颜色", subtitle: "自定义配色会随预设一起保存")
                Spacer()
                ColorPicker(
                    "",
                    selection: Binding(
                        get: { zoneState.primary.swiftUI },
                        set: { store.setPrimary(AuraCore.RGBColor($0), zone: zone) }
                    ),
                    supportsOpacity: false
                )
                .labelsHidden()
                .frame(width: 44)
            }

            HStack(spacing: 9) {
                ForEach(AuraCore.RGBColor.palette, id: \.hexString) { color in
                    Button {
                        store.setPrimary(color, zone: zone)
                    } label: {
                        Circle()
                            .fill(color.swiftUI)
                            .frame(width: 26, height: 26)
                            .overlay(
                                Circle().strokeBorder(
                                    zoneState.primary.hexString == color.hexString ? Palette.ink : Color.white.opacity(0.6),
                                    lineWidth: zoneState.primary.hexString == color.hexString ? 2 : 1
                                )
                            )
                            .shadow(color: color.swiftUI.opacity(0.35), radius: 4, x: 0, y: 2)
                    }
                    .buttonStyle(.plain)
                }
                Spacer()
            }

            if zoneState.mode.usesSecondaryColor {
                HStack(spacing: 10) {
                    Text("第二颜色")
                        .font(.system(size: 11.5, weight: .medium))
                        .foregroundStyle(Palette.muted)
                    Circle()
                        .fill(zoneState.secondary.swiftUI)
                        .frame(width: 20, height: 20)
                    ColorPicker(
                        "",
                        selection: Binding(
                            get: { zoneState.secondary.swiftUI },
                            set: { store.setSecondary(AuraCore.RGBColor($0), zone: zone) }
                        ),
                        supportsOpacity: false
                    )
                    .labelsHidden()
                    .frame(width: 40)
                    Spacer()
                }
            }
        }
        .card()
    }

    // MARK: - 亮度 / 速度

    private var sliderSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeader(title: "亮度与速度", subtitle: brightnessHint)

            if store.isAutoDimmed {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 10))
                    Text("自动开关已把实际亮度压到 0%。拖动下面任意亮度滑杆，或点上方「立即点亮」，就会自动解除熄灭并立刻生效。")
                        .font(.system(size: 10.5))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .foregroundStyle(Palette.warning)
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(Palette.warning.opacity(0.08))
                )
            }

            PinkSlider(
                title: "亮度",
                value: Binding(
                    get: { zoneState.brightness },
                    set: { store.setBrightness($0, zone: zone) }
                ),
                valueText: "\(Int(zoneState.brightness * 100))%"
            )

            PinkSlider(
                title: "动画速度",
                value: Binding(
                    get: { zoneState.speed },
                    set: { store.setSpeed($0, zone: zone) }
                ),
                valueText: "\(Int(zoneState.speed * 100))%"
            )
            .disabled(!zoneState.mode.isAnimated)
            .opacity(zoneState.mode.isAnimated ? 1 : 0.45)
        }
        .card()
    }

    private var brightnessHint: String {
        let steps = store.device.capabilities.brightnessSteps
        if store.hasGlobalBrightness {
            return "亮度由设备固件统一控制（\(steps) 档），整机共用；调节任一灯区都会同步到所有灯区"
        }
        return "亮度直接作用在发光颜色上，不改变系统背光"
    }
}
