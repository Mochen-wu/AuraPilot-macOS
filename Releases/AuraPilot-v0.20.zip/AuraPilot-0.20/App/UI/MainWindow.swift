import SwiftUI
import AuraCore

struct MainWindowView: View {
    @ObservedObject var store: AuraStore

    var body: some View {
        HStack(spacing: 0) {
            SidebarView(store: store)
            Rectangle()
                .fill(Palette.hairline)
                .frame(width: 1)
            content
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Palette.bg)
        }
        .frame(minWidth: 960, idealWidth: 1060, minHeight: 660, idealHeight: 730)
        .background(Palette.bg)
        .modifier(ThemeSync(store: store))
    }

    @ViewBuilder
    private var content: some View {
        switch store.section {
        case .overview:
            OverviewView(store: store)
        case .lighting:
            LightingView(store: store)
        case .presets:
            PresetsView(store: store)
        case .diagnostics:
            DiagnosticsView(store: store)
        }
    }
}

// MARK: - 侧边栏

private struct SidebarView: View {
    @ObservedObject var store: AuraStore

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            brand
                .padding(.horizontal, 20)
                .padding(.top, 26)
                .padding(.bottom, 22)

            VStack(spacing: 3) {
                ForEach(AppSection.allCases) { section in
                    SidebarItem(
                        section: section,
                        isSelected: store.section == section
                    ) {
                        withAnimation(.easeInOut(duration: 0.16)) {
                            store.section = section
                        }
                    }
                }
            }
            .padding(.horizontal, 10)

            Spacer(minLength: 12)

            deviceCard
                .padding(.horizontal, 14)
                .padding(.bottom, 16)
        }
        .frame(width: 232)
        .background(Palette.surfaceAlt)
    }

    private var brand: some View {
        HStack(spacing: 11) {
            ZStack {
                Circle()
                    .fill(Palette.heroGradient)
                    .frame(width: 34, height: 34)
                Image(systemName: "sparkles")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text("AuraPilot")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(Palette.ink)
                Text("极光领航")
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(Palette.muted)
            }
        }
    }

    private var deviceCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 6) {
                Circle()
                    .fill(store.isConnected ? Palette.positive : Palette.warning)
                    .frame(width: 6, height: 6)
                Text(store.isConnected ? "已连接" : "演示模式")
                    .font(.system(size: 10.5, weight: .semibold))
                    .foregroundStyle(Palette.muted)
                Spacer()
            }
            Text(store.device.name)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(Palette.ink)
                .lineLimit(1)
            Text(store.deviceSubtitle)
                .font(.system(size: 10.5))
                .foregroundStyle(Palette.muted)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
        }
        .card(padding: 13, radius: 14)
    }
}

private struct SidebarItem: View {
    var section: AppSection
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: section.symbol)
                    .font(.system(size: 12.5, weight: .semibold))
                    .frame(width: 18)
                Text(section.title)
                    .font(.system(size: 13, weight: isSelected ? .semibold : .medium, design: .rounded))
                Spacer(minLength: 0)
            }
            .foregroundStyle(isSelected ? Palette.accentDeep : Palette.ink.opacity(0.7))
            .padding(.vertical, 9)
            .padding(.horizontal, 12)
            .background(
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(isSelected ? Palette.surface : Color.clear)
            )
            .overlay(alignment: .leading) {
                if isSelected {
                    Capsule()
                        .fill(Palette.accent)
                        .frame(width: 3, height: 15)
                        .offset(x: 4)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
