import SwiftUI
import AuraCore

enum AppSection: String, CaseIterable, Identifiable {
    case overview
    case lighting
    case presets
    case diagnostics

    var id: String { rawValue }

    var title: String {
        switch self {
        case .overview: return "概览"
        case .lighting: return "灯效"
        case .presets: return "预设"
        case .diagnostics: return "诊断"
        }
    }

    var symbol: String {
        switch self {
        case .overview: return "square.grid.2x2"
        case .lighting: return "lightbulb.max"
        case .presets: return "swatchpalette"
        case .diagnostics: return "stethoscope"
        }
    }
}

/// SwiftUI 与 AuraController 之间的桥。控制器在后台队列，这里统一在主线程刷新。
final class AuraStore: ObservableObject {
    @Published private(set) var snapshot: AuraController.Snapshot
    @Published var section: AppSection = .overview
    @Published var selectedZone: AuraZone = .keyboard
    /// 当前机器上所有 ASUS HID 接口（诊断页设备下拉框的数据源）
    @Published private(set) var deviceCandidates: [DeviceCandidate] = []
    @Published private(set) var isScanningDevices = false
    @Published private(set) var isSwitchingDevice = false

    let controller: AuraController
    private var token: UUID?
    /// 按时间 / 深色模式自动开关灯光，由 AppDelegate 启动
    private(set) lazy var autoLightingScheduler = AutoLightingScheduler(store: self)

    init(controller: AuraController = AuraController.makeDefault()) {
        self.controller = controller
        self.snapshot = controller.snapshot
        // 启动即落地主题，状态栏弹层在主窗口打开前也能用对配色
        Palette.apply(appearance: snapshot.settings.appearance, themeID: snapshot.settings.themeID)
        token = controller.observe { [weak self] snapshot in
            self?.snapshot = snapshot
        }
    }

    deinit {
        if let token {
            controller.removeObserver(token)
        }
    }

    // MARK: - 便捷访问

    var state: LightingState { snapshot.state }
    var device: DeviceInfo { snapshot.device }
    var sensors: SensorSnapshot { snapshot.sensors }
    var presets: [Preset] { snapshot.presets }
    var settings: AppSettings { snapshot.settings }

    func zone(_ zone: AuraZone) -> ZoneState { snapshot.state[zone] }

    var isConnected: Bool { snapshot.device.kind.isRealHardware }

    /// 亮度是整机共用还是按灯区独立。
    /// rogauracore 只有一条 0x5A 亮度报告（4 档），作用于整台设备；
    /// 按灯区独立亮度的协议包把亮度写进灯效帧里，brightnessSteps 为 0。
    var hasGlobalBrightness: Bool { device.capabilities.brightnessSteps > 1 }

    var deviceSubtitle: String {
        if snapshot.isSimulated {
            return "演示模式 · 未连接 ASUS 硬件"
        }
        return "\(snapshot.device.kind.displayName) · \(snapshot.device.capabilities.zones.count) 个灯区"
    }

    // MARK: - 操作
    //
    // 每个显式灯效操作都要先 markManualControl()。
    // 否则白天自动开关把 autoLevel 压成 0，配置明明写进去了、灯却一点不亮，
    // 用户看到的就是「灯效界面所有按钮都不可用」（v0.17 实测反馈）。

    func toggleGlobal() { markManualControl(); controller.toggleGlobal() }
    func setGlobalOn(_ on: Bool) { markManualControl(); controller.setGlobalOn(on) }
    func setMode(_ mode: AuraMode, zone: AuraZone) { markManualControl(); controller.setMode(mode, zone: zone) }
    func setPrimary(_ color: AuraCore.RGBColor, zone: AuraZone) { markManualControl(); controller.setPrimary(color, zone: zone) }
    func setSecondary(_ color: AuraCore.RGBColor, zone: AuraZone) { markManualControl(); controller.setSecondary(color, zone: zone) }
    func setBrightness(_ value: Double, zone: AuraZone) {
        // 有独立亮度报告（0x5A，4 档）的设备是**整机共用**亮度，
        // 没有按灯区之分。同步写入所有灯区，避免"拖灯条滑杆没反应"。
        markManualControl()
        if hasGlobalBrightness {
            controller.setGlobalBrightness(value)
        } else {
            controller.setBrightness(value, zone: zone)
        }
    }
    func setSpeed(_ value: Double, zone: AuraZone) { markManualControl(); controller.setSpeed(value, zone: zone) }
    func setZoneEnabled(_ enabled: Bool, zone: AuraZone) { markManualControl(); controller.setZoneEnabled(enabled, zone: zone) }
    func applyPreset(_ preset: Preset) { markManualControl(); controller.applyPreset(id: preset.id) }
    func deletePreset(_ preset: Preset) { controller.deletePreset(id: preset.id) }
    func cycleColor(zone: AuraZone? = nil) { markManualControl(); controller.cycleQuickColor(zone: zone) }
    func setAllOff() { markManualControl(); controller.setAllOff() }
    func refreshSensors() { controller.refreshSensors() }

    func savePreset(named name: String) {
        controller.savePreset(named: name)
    }

    func updateSettings(_ change: @escaping (inout AppSettings) -> Void) {
        controller.updateSettings(change)
    }

    // MARK: - 自动开关灯光

    var autoLighting: AutoLightingConfig { settings.autoLighting }
    var autoLevel: Double { snapshot.autoLevel }
    var autoNote: String? { snapshot.autoNote }
    var isAutoDimmed: Bool { snapshot.isAutoDimmed }
    var isManualOverride: Bool { snapshot.isManualOverride }
    var manualOverrideUntil: Date? { snapshot.manualOverrideUntil }

    var manualOverrideText: String {
        guard isManualOverride else { return "" }
        guard let until = manualOverrideUntil else { return "手动控制中，自动开关暂让位" }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return "手动控制中 · \(formatter.string(from: until)) 后自动开关重新接管"
    }

    /// 任何一次显式灯效操作：解除自动压暗，并让自动开关暂时让位到下一个时间点。
    /// controller 落盘是异步的，这里只读已发布快照里的配置，够用。
    private func markManualControl() {
        let config = settings.autoLighting
        let expiry = ManualOverridePolicy.expiry(for: config)
        let note: String? = config.isEnabled
            ? "手动控制中：自动开关暂让位，稍后自动接管"
            : nil
        controller.setManualOverride(until: expiry, note: note)
    }

    /// 界面上的「恢复自动」：立刻把控制权交回自动开关并重新判定。
    func resumeAutoLighting() {
        controller.clearManualOverride()
        autoLightingScheduler.evaluate(force: true)
    }

    /// 界面上的「立即点亮」：先解除自动熄灭，再一步到位把灯打开。
    func turnOnNow() {
        markManualControl()
        controller.turnOnNow()
    }

    func updateAutoLighting(_ change: (inout AutoLightingConfig) -> Void) {
        var updated = settings.autoLighting
        change(&updated)
        controller.updateSettings { settings in
            settings.autoLighting = updated
        }
        // 用户明确改了自动开关配置 = 让自动策略立刻重新接管
        controller.clearManualOverride()
        // controller 落盘是异步的，直接读 snapshot 会拿到旧配置，所以把新值传进去判定
        autoLightingScheduler.evaluate(force: true, config: updated)
    }

    func setAutoLevel(_ level: Double, note: String?) {
        controller.setAutoLevel(level, note: note)
    }

    // MARK: - 设备选择

    var preferredDeviceID: String? { settings.preferredDeviceID }

    /// 枚举所有 ASUS 接口。要 open IOHIDManager，会有几百毫秒，放后台跑。
    func refreshDeviceCandidates() {
        guard !isScanningDevices else { return }
        isScanningDevices = true
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let list = DeviceCatalog.list()
            DispatchQueue.main.async {
                guard let self else { return }
                self.deviceCandidates = list
                self.isScanningDevices = false
            }
        }
    }

    /// 切换目标设备。nil = 自动选择。
    func selectDevice(_ id: String?) {
        guard !isSwitchingDevice else { return }
        isSwitchingDevice = true
        updateSettings { $0.preferredDeviceID = id }
        controller.switchDevice(preferredDeviceID: id) { [weak self] _ in
            guard let self else { return }
            self.isSwitchingDevice = false
            self.refreshDeviceCandidates()
        }
    }

    var preferredDeviceTitle: String {
        guard let id = preferredDeviceID else { return "自动选择" }
        return deviceCandidates.first { $0.id == id }?.title ?? id
    }

    // MARK: - 主题

    /// 外观 + 主题组合键，变化时触发整树重建
    var themeKey: String { "\(settings.appearance.rawValue)|\(settings.themeID.rawValue)" }

    func setAppearance(_ appearance: AppAppearance) {
        updateSettings { $0.appearance = appearance }
    }

    func setTheme(_ theme: AppThemeID) {
        updateSettings { $0.themeID = theme }
    }
}
