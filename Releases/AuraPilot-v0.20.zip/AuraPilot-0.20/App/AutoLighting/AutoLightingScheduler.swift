import AppKit
import AuraCore

/// 按时间段 / 系统深色模式自动开关键盘灯。
///
/// 判定时机：
/// - App 启动时（"每次开机检测，是白天就直接降到 0"）
/// - 每 30 秒轮询一次，用来跨过 18:00 / 07:00 的时间边界
/// - 系统在深浅色之间切换时（`AppleInterfaceThemeChangedNotification`）
/// - 系统从睡眠唤醒时（由 AppDelegate 触发）
///
/// 判定本身是 `AutoLighting.decide` 的纯函数，这里只负责"什么时候算一次"和"读系统外观"。
final class AutoLightingScheduler {
    private weak var store: AuraStore?
    private var timer: Timer?
    private var appearanceObserver: NSObjectProtocol?

    init(store: AuraStore) {
        self.store = store
    }

    deinit {
        stop()
    }

    func start() {
        // 先把当前状态推给引擎，再启动控制器：这样开机第一帧就是正确亮度，不会先亮一下再灭
        evaluate(force: true)

        let polling = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            self?.evaluate()
        }
        polling.tolerance = 5
        timer = polling

        appearanceObserver = DistributedNotificationCenter.default.addObserver(
            forName: NSNotification.Name("AppleInterfaceThemeChangedNotification"),
            object: nil,
            queue: .main
        ) { [weak self] _ in
            // 通知到达时 effectiveAppearance 可能还没刷新，等下一个 runloop
            DispatchQueue.main.async {
                self?.evaluate(force: true)
            }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        if let appearanceObserver {
            DistributedNotificationCenter.default.removeObserver(appearanceObserver)
            self.appearanceObserver = nil
        }
    }

    /// 系统当前是否处于深色模式。
    ///
    /// 读 `AppleInterfaceStyle` 而不是 `NSApp.effectiveAppearance`：前者不依赖主线程隔离，
    /// 也不会在 App 还没启动完成时拿到过期值；系统切换深浅色时会同步更新。
    static var isSystemDark: Bool {
        guard let style = UserDefaults.standard.string(forKey: "AppleInterfaceStyle") else {
            return false   // 浅色模式下这个 key 不存在
        }
        return style.caseInsensitiveCompare("dark") == .orderedSame
    }

    /// 立刻按当前时间与系统外观重新判定一次。
    /// `force = false` 时若配置未启用则什么都不做（避免覆盖用户手动调好的亮度）。
    /// `config` 用于「刚改完设置、controller 还没异步落盘」这一瞬，直接传新值判定。
    ///
    /// 注意：判定结果是否真的生效由 `AuraController.setAutoLevel` 决定——
    /// 用户手动调过灯效后，自动开关暂时让位，不会把亮度压回 0。
    func evaluate(force: Bool = false, config: AutoLightingConfig? = nil) {
        guard let store else { return }
        let cfg = config ?? store.autoLighting
        guard cfg.isEnabled || force else { return }
        let decision = AutoLighting.decide(cfg, at: Date(), isDarkMode: Self.isSystemDark)
        store.setAutoLevel(decision.level, note: decision.reason)
    }

    /// 供界面展示的预览：当前配置在"现在"会怎么判
    func preview(_ config: AutoLightingConfig) -> AutoLightingDecision {
        AutoLighting.decide(config, at: Date(), isDarkMode: Self.isSystemDark)
    }
}
