import SwiftUI
import AuraCore

/// 状态栏弹出面板：只放最高频的四件事——温度、总开关、模式、颜色。
struct StatusPopoverView: View {
    @ObservedObject var store: AuraStore
    var onOpenWindow: () -> Void
    var onQuit: () -> Void

    private var zone: AuraZone { store.selectedZone }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            header
            powerRow
            autoLightingHint
            Divider().overlay(Palette.hairline)
            zoneRow
            modeRow
            colorRow
            themeRow
            Divider().overlay(Palette.hairline)
            footer
        }
        .padding(16)
        .frame(width: 320)
        .background(Palette.bg)
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                Circle().fill(Palette.heroGradient).frame(width: 36, height: 36)
                Image(systemName: "sparkles")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(store.device.name)
                    .font(.system(size: 12.5, weight: .semibold, design: .rounded))
                    .foregroundStyle(Palette.ink)
                    .lineLimit(1)
                Text(store.deviceSubtitle)
                    .font(.system(size: 10))
                    .foregroundStyle(Palette.muted)
                    .lineLimit(1)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 0) {
                Text(store.sensors.cpuTemperature.map { String(format: "%.0f°", $0) } ?? "—")
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .foregroundStyle(Palette.accentDeep)
                Text(store.sensors.fans.first.map { "\($0.rpm) rpm" } ?? "无风扇数据")
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(Palette.muted)
            }
        }
    }

    private var powerRow: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("灯光总开关")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(Palette.ink)
                Text(store.isAutoDimmed
                     ? "自动开关：当前已熄灭"
                     : (store.state.isOn ? "正在输出到所有灯区" : "全部灯区已熄灭"))
                    .font(.system(size: 10))
                    .foregroundStyle(store.isAutoDimmed ? Palette.warning : Palette.muted)
            }
            Spacer()
            Toggle(
                "",
                isOn: Binding(
                    get: { store.state.isOn },
                    set: { store.setGlobalOn($0) }
                )
            )
            .labelsHidden()
            .toggleStyle(.switch)
            .controlSize(.small)
            .tint(Palette.accent)
        }
    }

    /// 自动熄灭时给一个一键出口，避免用户在状态栏里点半天没反应
    @ViewBuilder
    private var autoLightingHint: some View {
        if store.isAutoDimmed {
            HStack(spacing: 8) {
                Image(systemName: "moon.zzz.fill")
                    .font(.system(size: 10))
                    .foregroundStyle(Palette.warning)
                Text("自动开关已把灯熄灭")
                    .font(.system(size: 10.5))
                    .foregroundStyle(Palette.muted)
                Spacer()
                Button("点亮") { store.turnOnNow() }
                    .buttonStyle(.plain)
                    .font(.system(size: 10.5, weight: .semibold))
                    .foregroundStyle(Palette.accentDeep)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(Palette.accentSoft))
            }
            .padding(9)
            .background(
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(Palette.warning.opacity(0.09))
            )
        }
    }

    private var zoneRow: some View {
        HStack(spacing: 6) {
            ForEach(AuraZone.allCases) { item in
                let supported = store.device.capabilities.supports(item)
                Button {
                    store.selectedZone = item
                } label: {
                    HStack(spacing: 5) {
                        Circle().fill(store.zone(item).primary.swiftUI).frame(width: 6, height: 6)
                        Text(item.shortName)
                            .font(.system(size: 10.5, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(store.selectedZone == item ? Color.white : Palette.ink.opacity(0.7))
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(
                        Capsule().fill(store.selectedZone == item ? Palette.accent : Palette.surfaceAlt)
                    )
                }
                .buttonStyle(.plain)
                .disabled(!supported)
                .opacity(supported ? 1 : 0.4)
            }
            Spacer()
            Button {
                store.cycleColor(zone: zone)
            } label: {
                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(Palette.accentDeep)
                    .frame(width: 24, height: 20)
                    .background(Capsule().fill(Palette.accentSoft))
            }
            .buttonStyle(.plain)
            .help("切换下一个颜色")
        }
    }

    private var modeRow: some View {
        HStack(spacing: 6) {
            ForEach([AuraMode.solid, .breathe, .cycle, .rainbow, .star]) { mode in
                Button {
                    store.setMode(mode, zone: zone)
                } label: {
                    Text(mode.displayName)
                        .font(.system(size: 10, weight: .medium))
                        .lineLimit(1)
                        .foregroundStyle(store.zone(zone).mode == mode ? Palette.accentDeep : Palette.muted)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 5)
                        .background(
                            RoundedRectangle(cornerRadius: 7, style: .continuous)
                                .fill(store.zone(zone).mode == mode ? Palette.accentSoft : Palette.surfaceAlt)
                        )
                }
                .buttonStyle(.plain)
            }
            Spacer()
        }
    }

    private var colorRow: some View {
        HStack(spacing: 7) {
            ForEach(store.settings.quickColors, id: \.hexString) { color in
                Button {
                    store.setPrimary(color, zone: zone)
                } label: {
                    Circle()
                        .fill(color.swiftUI)
                        .frame(width: 20, height: 20)
                        .overlay(
                            Circle().strokeBorder(
                                store.zone(zone).primary.hexString == color.hexString ? Palette.ink : Color.white.opacity(0.7),
                                lineWidth: store.zone(zone).primary.hexString == color.hexString ? 1.6 : 0.8
                            )
                        )
                }
                .buttonStyle(.plain)
            }
            Spacer()
            Text(store.zone(zone).primary.hexString.uppercased())
                .font(.system(size: 9.5, weight: .medium, design: .monospaced))
                .foregroundStyle(Palette.muted)
        }
    }

    /// 主题快捷行：五个主题色点 + 外观模式轮换
    private var themeRow: some View {
        HStack(spacing: 7) {
            Image(systemName: "paintbrush.pointed")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(Palette.muted)

            ForEach(AppThemeID.allCases, id: \.self) { id in
                let theme = ThemeRegistry.theme(for: id)
                Button {
                    store.setTheme(id)
                } label: {
                    Circle()
                        .fill(Color(hex: theme.swatch[0]))
                        .frame(width: 18, height: 18)
                        .overlay(
                            Circle().strokeBorder(
                                store.settings.themeID == id ? Palette.ink : Color.white.opacity(0.7),
                                lineWidth: store.settings.themeID == id ? 1.6 : 0.8
                            )
                        )
                }
                .buttonStyle(.plain)
                .help("主题：\(id.displayName)")
            }

            Spacer()

            Button {
                let all = AppAppearance.allCases
                let next = all[(all.firstIndex(of: store.settings.appearance).map { all.index(after: $0) } ?? 0) % all.count]
                store.setAppearance(next)
            } label: {
                Text(store.settings.appearance.displayName)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(Palette.accentDeep)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(Palette.accentSoft))
            }
            .buttonStyle(.plain)
            .help("切换外观：跟随系统 → 浅色 → 深色")
        }
    }

    private var footer: some View {
        HStack {
            Button {
                onOpenWindow()
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "macwindow")
                        .font(.system(size: 10, weight: .semibold))
                    Text("主界面")
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Capsule().fill(Palette.accent))
            }
            .buttonStyle(.plain)

            Spacer()

            Button("退出") { onQuit() }
                .buttonStyle(.plain)
                .font(.system(size: 11))
                .foregroundStyle(Palette.muted)
        }
    }
}
