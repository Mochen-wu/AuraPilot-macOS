import AppKit
import SwiftUI
import Combine
import AuraCore

/// 状态栏常驻入口。左键弹面板，右键出菜单。
final class StatusBarController: NSObject {
    private let statusItem: NSStatusItem
    private let popover = NSPopover()
    private let store: AuraStore
    private let onOpenWindow: () -> Void
    private let onQuit: () -> Void
    private var cancellables = Set<AnyCancellable>()

    init(store: AuraStore, onOpenWindow: @escaping () -> Void, onQuit: @escaping () -> Void) {
        self.store = store
        self.onOpenWindow = onOpenWindow
        self.onQuit = onQuit
        self.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        super.init()

        configureButton()
        configurePopover()

        store.$snapshot
            .receive(on: RunLoop.main)
            .sink { [weak self] snapshot in
                self?.updateTitle(with: snapshot)
            }
            .store(in: &cancellables)
    }

    private func configureButton() {
        guard let button = statusItem.button else { return }
        let image = NSImage(systemSymbolName: "sparkles", accessibilityDescription: "AuraPilot")
        image?.isTemplate = true
        button.image = image
        button.imagePosition = .imageLeading
        button.font = NSFont.monospacedDigitSystemFont(ofSize: 11, weight: .medium)
        button.target = self
        button.action = #selector(handleClick)
        button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        button.toolTip = "AuraPilot"
    }

    private func configurePopover() {
        popover.behavior = .transient
        popover.animates = true
        popover.contentSize = NSSize(width: 320, height: 380)
        popover.contentViewController = NSHostingController(
            rootView: StatusPopoverView(
                store: store,
                onOpenWindow: { [weak self] in
                    self?.closePopover()
                    self?.onOpenWindow()
                },
                onQuit: { [weak self] in
                    self?.onQuit()
                }
            )
        )
    }

    private func updateTitle(with snapshot: AuraController.Snapshot) {
        guard let button = statusItem.button else { return }
        if snapshot.settings.showTemperatureInMenuBar, let temperature = snapshot.sensors.cpuTemperature {
            button.title = " \(Int(temperature.rounded()))°"
        } else {
            button.title = ""
        }
    }

    @objc private func handleClick() {
        let eventDesc = NSApp.currentEvent.map { "type=\($0.type.rawValue)" } ?? "currentEvent=nil"
        print("[AuraPilot] 状态栏点击，\(eventDesc)")
        let isRightClick = NSApp.currentEvent?.type == .rightMouseUp
        if isRightClick {
            showContextMenu()
        } else {
            togglePopover()
        }
    }

    private func togglePopover() {
        print("[AuraPilot] togglePopover，当前已显示=\(popover.isShown)")
        if popover.isShown {
            closePopover()
            return
        }
        guard let button = statusItem.button else {
            print("[AuraPilot] 拿不到状态栏按钮")
            return
        }
        // 先激活再弹出：顺序反了会让 transient popover 在显示瞬间被焦点变化关掉
        NSApp.activate(ignoringOtherApps: true)
        popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        print("[AuraPilot] popover 已弹出 isShown=\(popover.isShown)")
    }

    private func closePopover() {
        popover.performClose(nil)
    }

    // MARK: - 右键菜单

    private func showContextMenu() {
        let menu = NSMenu()

        let status = NSMenuItem(
            title: store.sensors.cpuTemperature.map { String(format: "CPU %.1f℃", $0) } ?? "CPU 温度不可用",
            action: nil,
            keyEquivalent: ""
        )
        status.isEnabled = false
        menu.addItem(status)

        if let fan = store.sensors.fans.first {
            let fanItem = NSMenuItem(title: "风扇 \(fan.rpm) RPM", action: nil, keyEquivalent: "")
            fanItem.isEnabled = false
            menu.addItem(fanItem)
        }

        menu.addItem(.separator())

        let power = NSMenuItem(
            title: store.state.isOn ? "关闭灯光" : "开启灯光",
            action: #selector(toggleLights),
            keyEquivalent: "l"
        )
        power.target = self
        menu.addItem(power)

        let modeMenu = NSMenu()
        for mode in AuraMode.allCases {
            let item = NSMenuItem(title: mode.displayName, action: #selector(selectMode(_:)), keyEquivalent: "")
            item.target = self
            item.representedObject = mode.rawValue
            item.state = store.zone(store.selectedZone).mode == mode ? .on : .off
            modeMenu.addItem(item)
        }
        let modeItem = NSMenuItem(title: "灯效模式", action: nil, keyEquivalent: "")
        modeItem.submenu = modeMenu
        menu.addItem(modeItem)

        let brightnessMenu = NSMenu()
        for percent in [20, 40, 60, 80, 100] {
            let item = NSMenuItem(title: "\(percent)%", action: #selector(selectBrightness(_:)), keyEquivalent: "")
            item.target = self
            item.tag = percent
            brightnessMenu.addItem(item)
        }
        let brightnessItem = NSMenuItem(title: "亮度", action: nil, keyEquivalent: "")
        brightnessItem.submenu = brightnessMenu
        menu.addItem(brightnessItem)

        let colorItem = NSMenuItem(title: "切换颜色", action: #selector(cycleColor), keyEquivalent: "c")
        colorItem.target = self
        menu.addItem(colorItem)

        menu.addItem(.separator())

        let openItem = NSMenuItem(title: "打开主界面…", action: #selector(openMainWindow), keyEquivalent: "o")
        openItem.target = self
        menu.addItem(openItem)

        let quitItem = NSMenuItem(title: "退出 AuraPilot", action: #selector(quitApp), keyEquivalent: "q")
        quitItem.target = self
        menu.addItem(quitItem)

        statusItem.menu = menu
        statusItem.button?.performClick(nil)
        statusItem.menu = nil
    }

    @objc private func toggleLights() {
        store.toggleGlobal()
    }

    @objc private func selectMode(_ sender: NSMenuItem) {
        guard let raw = sender.representedObject as? Int, let mode = AuraMode(rawValue: raw) else { return }
        store.setMode(mode, zone: store.selectedZone)
    }

    @objc private func selectBrightness(_ sender: NSMenuItem) {
        store.setBrightness(Double(sender.tag) / 100.0, zone: store.selectedZone)
    }

    @objc private func cycleColor() {
        store.cycleColor(zone: store.selectedZone)
    }

    @objc private func openMainWindow() {
        onOpenWindow()
    }

    @objc private func quitApp() {
        onQuit()
    }
}
