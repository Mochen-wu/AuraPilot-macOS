// swift-tools-version:5.9
import PackageDescription

// 这个 Package.swift 的作用：**不需要 XcodeGen / Xcode 工程，也能编译出 App**。
//
// 场景：机器上装不上 Homebrew（自然也就装不上 xcodegen），只想跑起来看看效果。
//      在仓库根目录执行：
//          swift build -c release --product AuraPilot
//          ./scripts/build-app.sh          # 编译 + 组装 .app + 打开
//
// 想用 Xcode 调试，仍然走 XcodeGen：
//          xcodegen generate && open AuraPilot.xcodeproj
//
// 说明：根包名故意叫 AuraPilotApp，避免和 Core/ 里那个名为 AuraPilot 的包重名。
let package = Package(
    name: "AuraPilotApp",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "AuraPilot", targets: ["AuraPilot"])
    ],
    dependencies: [
        .package(path: "Core")
    ],
    targets: [
        .executableTarget(
            name: "AuraPilot",
            dependencies: [
                // 包身份按目录名（Core）推导，不能写包 manifest 里的 name（AuraPilot）
                .product(name: "AuraCore", package: "Core")
            ],
            path: "App"
        )
    ]
)
